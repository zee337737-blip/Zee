SEO Hacker Browser

Requirements
- JDK 17
- Gradle 8.7
- Android SDK platform 34 and build tools installed by the CI runner
- A Firebase Android app configured for package com.seohacker.browser

GitHub Actions
The included .github/workflows/build.yml installs Temurin JDK 17, configures Gradle 8.7, and builds app-debug.apk.

Firebase setup
1. Create an Android app in Firebase with package name com.seohacker.browser.
2. Enable Firebase Authentication -> Email/Password.
3. Download google-services.json.
4. Put it at:
   app/google-services.json
5. Commit that file only if you are comfortable keeping Firebase configuration in the repository. The file is intentionally not included in this project ZIP.

Cohere setup
Open Planning Hub -> Settings and enter your Cohere API key. It is stored locally in SharedPreferences and is not hard-coded into the project. The default model is command-r-plus-08-2024.

Manual steps
1. Add app/google-services.json.
2. Enter your Cohere API key inside the app's Planning Hub settings.

The app is designed to work without a backend for browser data, bookmarks, history, reports, and settings. Firebase is used only for the requested app-account authentication.


--- Notes (after review) ---
* Put your Firebase file at app/google-services.json (it is NOT inside this zip).
* Build: the GitHub workflow in .github/workflows/build.yml builds app-debug.apk.
* Downloads, search (all keyboards), file upload, tabs, ad blocker and Planning Hub were reviewed and fixed.
