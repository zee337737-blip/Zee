SEO HACKER BROWSER
==================
Dark hacker-style Android browser + web companion for SEO work.

ANDROID BUILD
-------------
1. Push this repo to GitHub.
2. Actions tab builds app-debug.apk automatically.
3. Download artifact, install on phone.
4. Open app -> Planning Hub -> paste your Cohere API key.

WEB BUILD
---------
1. Open web/index.html in any browser.
2. No server needed.

NO PAID APIs. NO HARD-CODED KEYS.
