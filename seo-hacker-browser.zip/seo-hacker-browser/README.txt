SEO Hacker Browser

Requirements
- JDK 17
- Gradle 8.7
- Android SDK platform 34 and build tools installed by the CI runner
- A Firebase Android app configured for package com.seohacker.browser

GitHub Actions
The included .github/workflows/build.yml installs Temurin JDK 17, configures Gradle 8.7, and builds app-debug.apk.

Firebase setup
1. Create an Android app in Firebase with package name com.seohacker.browser.
2. Enable Firebase Authentication -> Email/Password.
3. Download google-services.json.
4. Put it at:
   app/google-services.json
5. Commit that file only if you are comfortable keeping Firebase configuration in the repository. The file is intentionally not included in this project ZIP.

Cohere setup
Open Planning Hub -> Settings and enter your Cohere API key. It is stored locally in SharedPreferences and is not hard-coded into the project. The default model is command-r-plus-08-2024.

Manual steps
1. Add app/google-services.json.
2. Enter your Cohere API key inside the app's Planning Hub settings.

The app is designed to work without a backend for browser data, bookmarks, history, reports, and settings. Firebase is used only for the requested app-account authentication.


--- Notes (after review) ---
* Put your Firebase file at app/google-services.json (it is NOT inside this zip).
* Build: the GitHub workflow in .github/workflows/build.yml builds app-debug.apk.
* Downloads, search (all keyboards), file upload, tabs, ad blocker and Planning Hub were reviewed and fixed.


--- Update: vault password, AI chat, PDF reports ---
* Password boxes (set / unlock / change / reset) have a new dark rounded UI with Show/Hide.
  Change password now asks for the OLD password first, then the new one twice.
* Planning Hub has 3 tabs: AI Chat, Reports, Final reports.
  - AI Chat: talk to the AI about your saved reports, find weak points, get fixes, improve the plan by chatting.
  - Every AI reply has Copy and Save PDF. Writing "pdf" in the chat (or the "Final PDF report" chip) builds the final report.
  - History button: all past chats are saved; open, delete or start a new chat.
* All report downloads are PDF now (CSV removed). PDFs are spreadsheet-style tables (landscape, header row,
  grid, coloured Good/Warning/Issue cells): weak points with "why it matters" and "how to fix", then the full audit.
* Final report (AI): score, every weak point with its solution, action plan, keyword opportunities, improved strategy.
* Lists (History, Downloads, Bookmarks, Reports) use the same card style. App is forced to dark theme.


--- Update: full video downloader + WordPress fix ---
* Video downloader rewritten: supports HLS streams (.m3u8, AES-128 encrypted, fMP4, separate audio) and direct video files.
  All parts are downloaded and joined (previous version saved only a short clip); result is converted to .mp4 when possible,
  otherwise saved as .ts (play with VLC / MX Player).
* Blue download button floats over the page whenever a video/stream is detected, and also over fullscreen video.
  The chooser shows the length of every candidate so ads/previews (short) are easy to skip; the longest is marked Recommended.
* Sidebar > "Video downloads (progress)": live list with percent, parts, size, Cancel / Retry / Open / Remove. Also "Paste link".
* Downloads run in a foreground service with a progress notification, so they continue when the app is in the background.
* DRM protected streams (Netflix style) cannot be saved. Some sites expire/protect links: play the video again and retry.
* WordPress: meta description / robots / canonical are now found case-insensitively, from name/property/itemprop,
  and from the raw page HTML as a fallback (caching/optimizer plugins can hide tags from the live page).


--- Update: address bar, page fit, AI attachments, boxed AI replies ---
* Address bar works like Chrome: tapping it hides the other toolbar buttons so the whole address is visible, and shows
  recent history. While typing it shows matching history first (title + link), then search suggestions. Back closes it.
* Pages: wide-viewport + overview mode + pinch zoom, and WebView forced-dark is switched off so sites like PageSpeed
  Insights render normally. Menu > "Full screen" hides the status and navigation bars. Planning Hub has a "Full" button too.
* Planning Hub AI chat: "+" attaches images/screenshots, PDF (first 6 pages are sent as images), Word .docx, and text/CSV/JSON/HTML.
  Images go to the vision model (Settings > Vision model, default command-a-vision-07-2025). Attachments are kept in the chat history.
* AI replies are shown as boxes: one card per section, Warning/Fix labels coloured, code in dark code boxes with Copy.
