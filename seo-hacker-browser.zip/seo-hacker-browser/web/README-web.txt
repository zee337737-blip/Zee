SEO HACKER BROWSER - WEB VERSION
================================
Open web/index.html in any browser.

Uses a free CORS proxy (https://api.allorigins.win) to fetch pages.
If it stops working, swap PROXY in seo-tools.js.

Cohere API key is stored in localStorage only.
