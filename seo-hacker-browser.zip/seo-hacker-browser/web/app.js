(function(){
  "use strict";
  const $ = s => document.querySelector(s);
  const $$ = s => Array.from(document.querySelectorAll(s));
  const state = {
    history: JSON.parse(localStorage.getItem("hs") || "[]"),
    histIndex: 0,
    searchEngine: localStorage.getItem("se") || "google",
    bookmarks: JSON.parse(localStorage.getItem("bm") || "[]"),
    reports: JSON.parse(localStorage.getItem("rp") || "[]")
  };
  state.histIndex = state.history.length ? state.history.length - 1 : -1;

  function isUrl(t){
    const x = t.trim();
    if(!x) return false;
    if(/^https?:\/\//i.test(x)) return true;
    if(x.includes(" ")) return false;
    return x.includes(".");
  }
  function searchUrl(q){
    const e = encodeURIComponent(q);
    if(state.searchEngine === "bing") return "https://www.bing.com/search?q=" + e;
    if(state.searchEngine === "duckduckgo") return "https://duckduckgo.com/?q=" + e;
    return "https://www.google.com/search?q=" + e;
  }
  function normalize(t){
    const x = t.trim();
    if(isUrl(x)) return /^https?:/i.test(x) ? x : "https://" + x;
    return searchUrl(x);
  }

  function toast(msg){
    const t = document.createElement("div");
    t.textContent = msg;
    t.style.cssText = "position:fixed;bottom:20px;left:50%;transform:translateX(-50%);background:#00FF9C;color:#000;padding:8px 16px;font-family:monospace;z-index:999";
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 1800);
  }

  function showReport(text){
    const r = $("#report");
    $("#welcome").style.display = "none";
    r.style.display = "block";
    r.textContent = text;
  }

  function go(text){
    if(!text) return;
    const url = normalize(text);
    $("#omnibox").value = url;
    state.history = state.history.slice(0, state.histIndex + 1);
    state.history.push(url);
    state.histIndex = state.history.length - 1;
    localStorage.setItem("hs", JSON.stringify(state.history.slice(-200)));
    runAnalyze(url);
  }

  async function runAnalyze(url){
    showReport("Loading " + url + " ...");
    try {
      const r = await SeoTools.run("analyze", url);
      showReport(r);
      state.reports.push({ title: "analyze " + url, content: r.slice(0, 20000), time: Date.now() });
      localStorage.setItem("rp", JSON.stringify(state.reports.slice(-50)));
    } catch(e){
      showReport("[!] " + e.message);
    }
  }

  const omnibox = $("#omnibox");
  omnibox.addEventListener("keydown", e => {
    if(e.key === "Enter"){ hideSuggestions(); go(omnibox.value); omnibox.blur(); }
  });
  omnibox.addEventListener("input", async () => {
    const q = omnibox.value.trim();
    if(q.length < 2 || isUrl(q)){ hideSuggestions(); return; }
    try {
      const r = await fetch("https://suggestqueries.google.com/complete/search?client=firefox&q=" + encodeURIComponent(q));
      const arr = await r.json();
      showSuggestions(arr[1] || []);
    } catch(_){ hideSuggestions(); }
  });
  function showSuggestions(list){
    const box = $("#suggestions");
    if(!list.length){ box.style.display = "none"; return; }
    box.innerHTML = list.map(s => '<div data-v="' + s.replace(/"/g,"&quot;") + '">' + s + '</div>').join("");
    box.style.display = "block";
    box.querySelectorAll("div").forEach(d => {
      d.onclick = () => { omnibox.value = d.dataset.v; hideSuggestions(); go(d.dataset.v); };
    });
  }
  function hideSuggestions(){ $("#suggestions").style.display = "none"; }

  $("#btnMenu").onclick = () => $("#leftDrawer").classList.toggle("open");
  $("#btnBack").onclick = () => {
    if(state.histIndex > 0){ state.histIndex--; runAnalyze(state.history[state.histIndex]); }
  };
  $("#btnForward").onclick = () => {
    if(state.histIndex < state.history.length - 1){ state.histIndex++; runAnalyze(state.history[state.histIndex]); }
  };
  $("#btnReload").onclick = () => {
    const u = omnibox.value.trim();
    if(u) runAnalyze(u);
  };
  $("#btnBookmark").onclick = () => {
    const url = omnibox.value.trim();
    if(!url) return;
    if(!state.bookmarks.some(b => b.url === url)){
      state.bookmarks.unshift({ title: url, url });
      localStorage.setItem("bm", JSON.stringify(state.bookmarks));
      renderBookmarks();
      toast("Bookmarked");
    }
  };
  $("#btnHub").onclick = openHub;

  $$(".quick button").forEach(b => b.onclick = () => go(b.dataset.url));

  function renderBookmarks(){
    const ul = $("#bookmarksList");
    if(!state.bookmarks.length){ ul.innerHTML = '<li style="opacity:.5;cursor:default">(no bookmarks)</li>'; return; }
    ul.innerHTML = state.bookmarks.map((b,i) =>
      '<li data-i="' + i + '">' + b.title + '</li>'
    ).join("");
    ul.querySelectorAll("li[data-i]").forEach(li => {
      li.onclick = () => { go(state.bookmarks[+li.dataset.i].url); $("#rightDrawer").classList.remove("open"); };
      li.oncontextmenu = e => {
        e.preventDefault();
        state.bookmarks.splice(+li.dataset.i, 1);
        localStorage.setItem("bm", JSON.stringify(state.bookmarks));
        renderBookmarks();
      };
    });
  }
  renderBookmarks();

  const tools = [
    ["Analyze page", "analyze"],
    ["View source", "source"],
    ["Response headers", "headers"],
    ["Redirect chain (info)", "redirects"],
    ["robots.txt", "robots"],
    ["sitemap.xml", "sitemap"],
    ["Page speed & size", "speed"],
    ["Cycle search engine", "searchEngine"],
    ["Bookmarks sidebar", "bookmarks"],
    ["Open hub", "hub"]
  ];
  const tl = $("#toolsList");
  tools.forEach(([label, key]) => {
    const b = document.createElement("button");
    b.textContent = "> " + label;
    b.onclick = () => runTool(key);
    tl.appendChild(b);
  });

  async function runTool(key){
    $("#leftDrawer").classList.remove("open");
    if(key === "searchEngine"){
      const order = ["google","bing","duckduckgo"];
      const i = (order.indexOf(state.searchEngine) + 1) % order.length;
      state.searchEngine = order[i];
      localStorage.setItem("se", state.searchEngine);
      toast("Search: " + state.searchEngine);
      return;
    }
    if(key === "bookmarks"){ $("#rightDrawer").classList.toggle("open"); return; }
    if(key === "hub"){ openHub(); return; }
    const url = omnibox.value.trim();
    if(!url || !isUrl(url)){ toast("Enter a URL first"); return; }
    showReport("Loading " + key + " ...");
    try {
      const r = await SeoTools.run(key, url);
      showReport(r);
      state.reports.push({ title: key + " " + url, content: r.slice(0, 20000), time: Date.now() });
      localStorage.setItem("rp", JSON.stringify(state.reports.slice(-50)));
    } catch(e){
      showReport("[!] " + e.message);
    }
  }

  function openHub(){
    $("#hubKey").value = localStorage.getItem("ck") || "";
    $("#hubModel").value = localStorage.getItem("cm") || "command-r-plus-08-2024";
    renderReports();
    $("#hubModal").classList.add("open");
  }
  function closeHub(){ $("#hubModal").classList.remove("open"); }
  $("#hubClose").onclick = closeHub;
  $("#hubSave").onclick = () => {
    localStorage.setItem("ck", $("#hubKey").value.trim());
    localStorage.setItem("cm", $("#hubModel").value.trim() || "command-r-plus-08-2024");
    toast("Saved");
  };
  $("#hubClear").onclick = () => {
    state.reports = [];
    localStorage.setItem("rp", "[]");
    renderReports();
  };
  $("#hubGen").onclick = generateStrategy;

  function renderReports(){
    const c = $("#hubReports");
    if(!state.reports.length){ c.innerHTML = "(empty)"; return; }
    c.innerHTML = state.reports.map((r,i) =>
      '<div class="r" data-i="' + i + '">[' + (i+1) + '] ' + r.title + '</div>'
    ).join("");
    c.querySelectorAll(".r").forEach(el => el.onclick = () => {
      alert(state.reports[+el.dataset.i].content.slice(0, 3000));
    });
  }

  async function generateStrategy(){
    const key = (localStorage.getItem("ck") || "").trim();
    const model = (localStorage.getItem("cm") || "command-r-plus-08-2024").trim();
    const out = $("#hubOut");
    if(!key){ out.textContent = "[!] No Cohere API key."; return; }
    if(!state.reports.length){ out.textContent = "[!] No reports."; return; }
    out.textContent = "[*] Asking AI...";
    const prompt = "You are an SEO strategist. Provide: 1) PROBLEMS, 2) ACTION PLAN, 3) STRATEGY.\n\n" +
      state.reports.map(r => "=== " + r.title + " ===\n" + r.content).join("\n\n").slice(0, 20000);
    try {
      const r = await fetch("https://api.cohere.com/v2/chat", {
        method: "POST",
        headers: { "Authorization": "Bearer " + key, "Content-Type": "application/json" },
        body: JSON.stringify({ model: model, messages: [{ role: "user", content: prompt }], temperature: 0.4 })
      });
      const j = await r.json();
      if(!r.ok){ out.textContent = "[!] HTTP " + r.status + ": " + JSON.stringify(j); return; }
      const parts = (j.message && j.message.content) || [];
      out.textContent = parts.filter(p => p.type === "text").map(p => p.text).join("\n") || JSON.stringify(j);
    } catch(e){
      out.textContent = "[!] " + e.message;
    }
  }
})();
