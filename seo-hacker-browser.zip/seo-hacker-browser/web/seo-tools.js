window.SeoTools = (function(){
  "use strict";
  const PROXY = "https://api.allorigins.win/raw?url=";

  async function fetchWithProxy(url){
    const r = await fetch(PROXY + encodeURIComponent(url));
    if(!r.ok) throw new Error("Fetch failed: " + r.status);
    return await r.text();
  }

  function parseHtml(text){
    return new DOMParser().parseFromString(text, "text/html");
  }

  function analyzeDocument(doc, url){
    const meta = n => {
      const m = doc.querySelector('meta[name="' + n + '"], meta[property="' + n + '"]');
      return m ? (m.getAttribute("content") || "") : "";
    };
    const title = doc.title || "";
    const desc = meta("description") || meta("og:description");
    const canonical = (doc.querySelector('link[rel="canonical"]') || {}).href || "";
    const robots = meta("robots");
    const heads = {};
    for(let i=1;i<=6;i++) heads["H"+i] = doc.querySelectorAll("h" + i).length;
    const imgs = doc.querySelectorAll("img");
    let noAlt = 0;
    imgs.forEach(i => { if(!i.alt || !i.alt.trim()) noAlt++; });
    const text = (doc.body && doc.body.textContent) || "";
    const words = text.trim().split(/\s+/).filter(w => w.length > 1);
    const freq = {};
    words.forEach(w => {
      w = w.toLowerCase().replace(/[^a-z0-9-]/g, "");
      if(w.length > 2) freq[w] = (freq[w] || 0) + 1;
    });
    const top = Object.entries(freq).sort((a,b) => b[1]-a[1]).slice(0,25);
    const links = Array.from(doc.querySelectorAll("a[href]"));
    let inl=0, ext=0, nf=0;
    const origin = (() => { try { return new URL(url).origin; } catch(_) { return ""; } })();
    links.forEach(a => {
      const h = a.getAttribute("href") || "";
      if(a.rel && /nofollow/i.test(a.rel)) nf++;
      if(h.startsWith(origin)) inl++;
      else if(/^https?:/i.test(h)) ext++;
    });
    const og = Array.from(doc.querySelectorAll('meta[property^="og:"]')).map(m => m.getAttribute("property") + " = " + m.getAttribute("content"));
    const tw = Array.from(doc.querySelectorAll('meta[name^="twitter:"]')).map(m => m.getAttribute("name") + " = " + m.getAttribute("content"));
    const jsonld = Array.from(doc.querySelectorAll('script[type="application/ld+json"]')).map(s => (s.textContent || "").slice(0, 800));
    return { url, title, titleLen: title.length, desc, descLen: desc.length, canonical, robots, heads,
      imgsTotal: imgs.length, imgsNoAlt: noAlt, wordCount: words.length, topWords: top,
      internalLinks: inl, externalLinks: ext, nofollowLinks: nf, og, tw, jsonld };
  }

  function format(o){
    const L = [];
    L.push("=== SEO REPORT ===");
    L.push("URL: " + o.url);
    L.push("");
    L.push("TITLE: " + o.title);
    L.push("  length: " + o.titleLen + " chars " + (o.titleLen >= 30 && o.titleLen <= 65 ? "[OK]" : "[WARN]"));
    L.push("META DESCRIPTION: " + o.desc);
    L.push("  length: " + o.descLen + " chars " + (o.descLen >= 70 && o.descLen <= 165 ? "[OK]" : "[WARN]"));
    L.push("CANONICAL: " + (o.canonical || "(none)"));
    L.push("ROBOTS: " + (o.robots || "(none)"));
    L.push("");
    L.push("HEADINGS:");
    for(const k in o.heads) L.push("  " + k + ": " + o.heads[k]);
    L.push("");
    L.push("IMAGES: " + o.imgsTotal + " total, " + o.imgsNoAlt + " without alt");
    L.push("WORDS: " + o.wordCount);
    L.push("");
    L.push("TOP KEYWORDS:");
    const wc = Math.max(1, o.wordCount);
    o.topWords.slice(0, 15).forEach(([w,c]) => {
      L.push("  " + w.padEnd(18) + " " + String(c).padStart(5) + "  " + ((c*100/wc).toFixed(2)) + "%");
    });
    L.push("");
    L.push("LINKS:");
    L.push("  Internal: " + o.internalLinks);
    L.push("  External: " + o.externalLinks);
    L.push("  Nofollow: " + o.nofollowLinks);
    L.push("");
    L.push("OPEN GRAPH:");
    o.og.length ? o.og.forEach(x => L.push("  " + x)) : L.push("  (none)");
    L.push("");
    L.push("TWITTER CARDS:");
    o.tw.length ? o.tw.forEach(x => L.push("  " + x)) : L.push("  (none)");
    L.push("");
    L.push("JSON-LD BLOCKS: " + o.jsonld.length);
    o.jsonld.forEach((b,i) => { L.push("  [" + (i+1) + "]"); L.push("  " + b.slice(0,200)); });
    return L.join("\n");
  }

  async function run(tool, url){
    if(tool === "analyze"){
      const html = await fetchWithProxy(url);
      return format(analyzeDocument(parseHtml(html), url));
    }
    if(tool === "source"){
      const html = await fetchWithProxy(url);
      return html.slice(0, 200000);
    }
    if(tool === "headers"){
      try {
        const r = await fetch(PROXY + encodeURIComponent(url));
        const h = {};
        r.headers.forEach((v,k) => h[k] = v);
        return "Status: " + r.status + "\n\n" + Object.entries(h).map(([k,v]) => k + ": " + v).join("\n");
      } catch(e){ return "[!] " + e.message; }
    }
    if(tool === "redirects"){
      const html = await fetchWithProxy(url);
      return "Requested: " + url + "\nFetched: " + html.length + " bytes\n(proxy follows redirects; use DevTools for full chain)";
    }
    if(tool === "robots"){
      const base = new URL(url).origin;
      return (await fetchWithProxy(base + "/robots.txt")).slice(0, 100000);
    }
    if(tool === "sitemap"){
      const base = new URL(url).origin;
      return (await fetchWithProxy(base + "/sitemap.xml")).slice(0, 100000);
    }
    if(tool === "speed"){
      const t0 = performance.now();
      const html = await fetchWithProxy(url);
      const ms = Math.round(performance.now() - t0);
      return "URL: " + url + "\nTime: " + ms + " ms\nSize: " + html.length + " bytes (" + (html.length/1024).toFixed(2) + " KB)";
    }
    throw new Error("Unknown tool");
  }

  return { run: run };
})();
