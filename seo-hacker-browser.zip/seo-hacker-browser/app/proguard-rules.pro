# No custom shrinking rules are required for the debug build.
