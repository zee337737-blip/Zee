package com.seohacker.browser

import android.Manifest
import android.app.DownloadManager
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebView
import android.widget.Toast
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

object DownloadHelper {
    private val tokens: MutableSet<String> = java.util.Collections.synchronizedSet(HashSet<String>())

    private fun toast(c: Context, msg: String) {
        Handler(Looper.getMainLooper()).post { Toast.makeText(c, msg, Toast.LENGTH_LONG).show() }
    }

    fun handle(ctx: Context, view: WebView, url: String, ua: String, cd: String?, mime: String?) {
        try {
            val name = URLUtil.guessFileName(url, cd, mime)
            val isVideo = url.startsWith("http") && ((mime ?: "").startsWith("video/") ||
                Regex("\\.(mp4|mkv|webm|avi|mov|m4v|3gp|flv|wmv)$", RegexOption.IGNORE_CASE).containsMatchIn(name))
            when {
                isVideo -> {
                    // Fast multi-connection downloader with progress (sidebar > Video downloads)
                    val h = LinkedHashMap<String, String>()
                    h["User-Agent"] = ua
                    view.url?.takeIf { it.startsWith("http") }?.let { h["Referer"] = it }
                    DlManager.start(ctx, name.substringBeforeLast('.'), url, h, "file", "", "")
                    toast(ctx, "Download started. See progress: menu > Video downloads")
                }
                url.startsWith("blob:") -> fetchBlob(ctx, view, url, name, mime)
                url.startsWith("data:") -> saveDataUrl(ctx, url, name)
                else -> enqueue(ctx, url, ua, view.url, name, mime)
            }
        } catch (e: Exception) {
            toast(ctx, "Download error: " + e.message)
        }
    }

    fun enqueueVideo(ctx: Context, view: WebView, url: String, name: String) {
        val mime = if (name.endsWith(".webm")) "video/webm" else "video/mp4"
        enqueue(ctx, url, view.settings.userAgentString, view.url, name, mime)
    }

    private fun enqueue(ctx: Context, url: String, ua: String, referer: String?, name: String, mime: String?) {
        if (Build.VERSION.SDK_INT <= 28 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            toast(ctx, "Storage permission is required for downloads.")
            return
        }
        val req = DownloadManager.Request(Uri.parse(url))
        req.setTitle(name)
        req.setDescription("SEO Browser download")
        req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
        req.setAllowedOverMetered(true)
        req.setAllowedOverRoaming(true)
        req.addRequestHeader("User-Agent", ua)
        referer?.takeIf { it.isNotBlank() && !it.startsWith("file:") }?.let { req.addRequestHeader("Referer", it) }
        CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
        req.setMimeType(mime ?: "application/octet-stream")
        req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
        (ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
        Toast.makeText(ctx, "Downloading: " + name, Toast.LENGTH_SHORT).show()
    }

    private fun fetchBlob(ctx: Context, view: WebView, url: String, name: String, mime: String?) {
        val token = UUID.randomUUID().toString()
        tokens.add(token)
        val m = JSONObject.quote(mime ?: "application/octet-stream")
        val js = "(function(){var x=new XMLHttpRequest();x.open('GET'," + JSONObject.quote(url) + ");" +
            "x.responseType='blob';" +
            "x.onload=function(){var r=new FileReader();r.onloadend=function(){" +
            "AndroidDownload.saveBase64('" + token + "'," + JSONObject.quote(name) + "," +
            "String(r.result).split(',')[1]||''," + "(x.response&&x.response.type)||" + m + ");};" +
            "r.readAsDataURL(x.response);};" +
            "x.onerror=function(){AndroidDownload.saveError('" + token + "','Blob fetch failed');};" +
            "x.send();})();"
        view.evaluateJavascript(js, null)
        Toast.makeText(ctx, "Saving: " + name, Toast.LENGTH_SHORT).show()
    }

    private fun saveDataUrl(ctx: Context, url: String, name: String) {
        val comma = url.indexOf(',')
        if (comma < 0) { toast(ctx, "Invalid data URL"); return }
        val header = url.substring(5, comma)
        val data = url.substring(comma + 1)
        val bytes = if (header.endsWith(";base64")) Base64.decode(data, Base64.DEFAULT) else Uri.decode(data).toByteArray()
        val mime = header.substringBefore(';').ifBlank { "application/octet-stream" }
        saveBytes(ctx, name, mime, bytes)
    }

    fun saveBase64(ctx: Context, token: String, name: String, b64: String, mime: String) {
        if (!tokens.remove(token)) return
        try {
            saveBytes(ctx, name, mime, Base64.decode(b64, Base64.DEFAULT))
        } catch (e: Exception) {
            toast(ctx, "Blob download error: " + e.message)
        }
    }

    fun saveError(ctx: Context, token: String, msg: String) {
        if (tokens.remove(token)) toast(ctx, msg)
    }

    private fun saveBytes(ctx: Context, name: String, mime: String, bytes: ByteArray) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues().apply {
                    put(android.provider.MediaStore.Downloads.DISPLAY_NAME, name)
                    put(android.provider.MediaStore.Downloads.MIME_TYPE, mime)
                    put(android.provider.MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = ctx.contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                    ?: throw IllegalStateException("MediaStore insert failed")
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                    ?: throw IllegalStateException("Cannot open output stream")
            } else {
                @Suppress("DEPRECATION")
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (!dir.exists() && !dir.mkdirs()) throw IllegalStateException("Cannot create Downloads folder")
                FileOutputStream(File(dir, name)).use { it.write(bytes) }
            }
            toast(ctx, "Saved to Downloads: " + name)
        } catch (e: Exception) {
            toast(ctx, "Save failed: " + e.message)
        }
    }
}
