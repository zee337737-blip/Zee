package com.seohacker.browser

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat

object DlNotify {
    const val CH_RUN = "video_dl_run"
    const val CH_DONE = "video_dl_done"

    fun channels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH_RUN, "Video downloads in progress", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_DONE, "Finished video downloads", NotificationManager.IMPORTANCE_DEFAULT))
    }

    fun open(ctx: Context): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(ctx, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun finished(ctx: Context, t: DlTask) {
        if (t.state != "done" && t.state != "failed") return
        try {
            channels(ctx)
            val ok = t.state == "done"
            val n = NotificationCompat.Builder(ctx, CH_DONE)
                .setSmallIcon(R.drawable.ic_download)
                .setContentTitle(if (ok) "Download complete" else "Download failed")
                .setContentText(if (ok) t.fileName else t.title)
                .setContentIntent(open(ctx))
                .setAutoCancel(true)
                .build()
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(t.id.hashCode(), n)
        } catch (e: Exception) { }
    }
}

/** Keeps the process alive and shows progress while videos download in the background. */
class DownloadService : Service() {
    private var wake: PowerManager.WakeLock? = null
    private val listener: () -> Unit = { update() }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun build(): Notification {
        val act = DlManager.active()
        val avg = if (act.isEmpty()) 0 else act.sumOf { it.percent() } / act.size
        val text = if (act.isEmpty()) "Finishing..." else act.size.toString() + " downloading  -  " + avg + "%"
        return NotificationCompat.Builder(this, DlNotify.CH_RUN)
            .setSmallIcon(R.drawable.ic_download)
            .setContentTitle("SEO Browser video downloads")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, avg, act.isEmpty() || avg == 0)
            .setContentIntent(DlNotify.open(this))
            .build()
    }

    private fun goForeground() {
        val n = build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(77, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(77, n)
    }

    override fun onCreate() {
        super.onCreate()
        DlNotify.channels(this)
        goForeground()
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "seobrowser:video_dl")
            wake?.acquire(6 * 60 * 60 * 1000L)
        } catch (e: Exception) { }
        DlManager.addListener(listener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        update()
        return START_NOT_STICKY
    }

    private fun update() {
        if (DlManager.active().isEmpty()) {
            stopForeground(true)
            stopSelf()
            return
        }
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(77, build())
    }

    override fun onDestroy() {
        DlManager.removeListener(listener)
        try { if (wake?.isHeld == true) wake?.release() } catch (e: Exception) { }
        super.onDestroy()
    }
}
