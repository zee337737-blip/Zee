package com.seohacker.browser

import android.graphics.Color
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Turns on-screen reports into spreadsheet-style PDF documents. */
object ReportSheets {
    fun stamp(): String = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.US).format(Date())

    private fun statusName(s: Status) = when (s) {
        Status.GOOD -> "Good"; Status.WARN -> "Warning"; Status.BAD -> "Issue"; Status.INFO -> "Info"
    }

    fun fromSections(title: String, url: String, sections: List<Section>): PdfDoc {
        val sub = (if (url.isNotBlank()) "$url   |   " else "") + "Generated " + stamp()
        val isAudit = sections.firstOrNull()?.title == "Summary"
        return if (isAudit) audit(title, sub, sections) else generic(title, sub, sections)
    }

    private fun audit(title: String, sub: String, sections: List<Section>): PdfDoc {
        val summary = sections.first().rows
        fun cnt(label: String) = summary.firstOrNull { it.label == label }?.value ?: "0"
        val chips = listOf(
            Chip("PASSED", cnt("Passed"), Color.parseColor("#16A34A")),
            Chip("WARNINGS", cnt("Warnings"), Color.parseColor("#D97706")),
            Chip("ISSUES", cnt("Issues"), Color.parseColor("#DC2626"))
        )
        val body = sections.drop(1)
        val all = mutableListOf<List<String>>()
        val weak = mutableListOf<List<String>>()
        var n = 0
        var k = 0
        for (s in body) {
            for (r in s.rows) {
                if (r.label.isBlank()) continue
                n++
                all += listOf(n.toString(), s.title, r.label, r.value, statusName(r.status))
                if (r.status == Status.WARN || r.status == Status.BAD) {
                    k++
                    val f = Fixes.forRow(r.label, r.value)
                    weak += listOf(k.toString(), r.label + "\n(" + s.title + ")", f.first, f.second, if (r.status == Status.BAD) "High" else "Medium")
                }
            }
        }
        val tables = mutableListOf<SheetTable>()
        tables += SheetTable(
            "Weak points and how to fix them",
            listOf("#", "Weak point", "Why it matters", "How to fix it", "Priority"),
            listOf(4f, 18f, 26f, 44f, 8f), weak, setOf(4)
        )
        tables += SheetTable(
            "Full audit results",
            listOf("#", "Section", "Check", "Result", "Status"),
            listOf(4f, 16f, 16f, 52f, 8f), all, setOf(4)
        )
        return PdfDoc("$title - SEO Report", sub, chips, tables)
    }

    private fun generic(title: String, sub: String, sections: List<Section>): PdfDoc {
        val rows = mutableListOf<List<String>>()
        var n = 0
        for (s in sections) {
            for (r in s.rows) {
                chunks(r.value).forEachIndexed { i, part ->
                    n++
                    rows += listOf(n.toString(), if (i == 0) s.title else "", if (i == 0) r.label else "(continued)", part)
                }
            }
        }
        val table = SheetTable("Report data", listOf("#", "Section", "Item", "Details"), listOf(4f, 18f, 18f, 60f), rows)
        return PdfDoc("$title - Report", sub, emptyList(), listOf(table))
    }

    private fun chunks(v: String): List<String> {
        if (v.length <= 900) return listOf(v)
        val out = mutableListOf<String>()
        val cur = StringBuilder()
        for (ln in v.lines()) {
            val parts = if (ln.isEmpty()) listOf("") else ln.chunked(900)
            for (line in parts) {
                if (cur.isNotEmpty() && cur.length + line.length + 1 > 900) { out += cur.toString().trimEnd(); cur.setLength(0) }
                cur.append(line).append('\n')
            }
        }
        if (cur.isNotEmpty()) out += cur.toString().trimEnd()
        return out.take(80)
    }
}

/** Plain-language "why it matters" and "how to fix" text for common SEO checks. */
object Fixes {
    fun forRow(label: String, value: String): Pair<String, String> {
        val l = label.lowercase(Locale.ROOT)
        val v = value.lowercase(Locale.ROOT)
        return when {
            l == "title" -> {
                val why = "The title tag is the strongest on-page signal and the headline people see in Google."
                when {
                    v.startsWith("missing") -> Pair(why, "Add a unique <title> of 30-60 characters. Put the main keyword near the start and the brand at the end.")
                    v.contains("too short") -> Pair(why, "Expand the title to 30-60 characters: main keyword + a benefit or modifier + brand name.")
                    else -> Pair(why, "Shorten the title to under 60 characters so Google does not cut it off. Keep the main keyword first.")
                }
            }
            l == "meta description" -> {
                val why = "The meta description is the snippet text under your title in search results. A good one raises clicks."
                when {
                    v.startsWith("missing") -> Pair(why, "Add <meta name=\"description\" content=\"...\"> with 70-160 characters. Describe the page and add a call to action.")
                    v.contains("found only") -> Pair(why, "A description exists only as an Open Graph/Twitter tag. Add a standard <meta name=\"description\" content=\"...\"> tag (in WordPress: set it in Yoast/Rank Math > snippet editor).")
                    v.contains("too short") -> Pair(why, "Extend it to 70-160 characters with the main keyword, a benefit and a call to action.")
                    else -> Pair(why, "Trim it to 160 characters or less so it is not cut off. Keep the most important words first.")
                }
            }
            l == "canonical url" -> Pair(
                "Without a canonical tag, duplicate URLs (http/https, www, parameters) can split ranking signals.",
                "Add <link rel=\"canonical\" href=\"https://your-preferred-url\"> in the <head> of the page."
            )
            l == "robots meta" -> Pair(
                "A noindex directive tells Google not to show this page in search results at all.",
                "If the page should rank, remove noindex and use content=\"index, follow\". Keep noindex only for private or thin pages."
            )
            l == "h1 tag" -> if (v.contains("no h1")) Pair(
                "The H1 tells search engines and visitors what the page is about.",
                "Add exactly one <h1> that contains the main keyword and matches the page topic."
            ) else Pair(
                "Several H1 tags dilute the page topic and confuse the heading structure.",
                "Keep one H1 for the main topic and change the other H1 tags to H2 or H3."
            )
            l == "language" -> Pair(
                "The lang attribute helps browsers and search engines serve the page to the right audience.",
                "Set the language on the root tag, for example <html lang=\"en\">."
            )
            l == "viewport" -> Pair(
                "Without a viewport tag the page is not mobile friendly, and Google ranks mobile-first.",
                "Add <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"> in the <head>."
            )
            l.startsWith("og:") -> Pair(
                "Open Graph tags control how your link looks when shared on Facebook, WhatsApp and LinkedIn.",
                "Add <meta property=\"$label\" content=\"...\"> in the <head>. For og:image use a 1200x630 px image."
            )
            l.startsWith("twitter:") -> Pair(
                "Twitter/X card tags control the preview shown when your link is shared.",
                "Add <meta name=\"$label\" content=\"...\"> in the <head>. Use twitter:card = summary_large_image for big previews."
            )
            l == "schema markup" -> Pair(
                "Structured data can unlock rich results (stars, FAQs, breadcrumbs) and helps Google understand the page.",
                "Add JSON-LD (Organization, Article, Product or FAQPage) in a <script type=\"application/ld+json\"> block and test it in Google's Rich Results Test."
            )
            l == "word count" -> Pair(
                "Thin pages rarely rank because they do not fully answer the search intent.",
                "Expand the content to 300+ words (800+ for competitive topics): add sections, examples, FAQs and related keywords."
            )
            l == "images without alt text" -> Pair(
                "Alt text helps image search, accessibility and gives context to Google.",
                "Add short, descriptive alt text to every meaningful image. Leave alt empty only for pure decoration."
            )
            else -> Pair(
                "This item was flagged during the audit and can affect how well the page performs in search.",
                "Review the value shown in the audit table and follow SEO best practice for this element."
            )
        }
    }
}
