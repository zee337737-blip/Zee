package com.seohacker.browser

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class LoginActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var email: EditText
    private lateinit var password: EditText
    private lateinit var error: TextView
    private lateinit var progress: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        auth = FirebaseAuth.getInstance()
        if (auth.currentUser != null) { openBrowser(); return }
        setContentView(R.layout.activity_login)
        email = findViewById(R.id.emailInput)
        password = findViewById(R.id.passwordInput)
        error = findViewById(R.id.errorText)
        progress = findViewById(R.id.loginProgress)
        findViewById<Button>(R.id.loginButton).setOnClickListener { login() }
        findViewById<Button>(R.id.signupButton).setOnClickListener { signup() }
        findViewById<TextView>(R.id.forgotButton).setOnClickListener { reset() }
    }
    private fun valid(): Boolean {
        val e=email.text.toString().trim(); val p=password.text.toString()
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(e).matches()) { showError("Enter a valid email."); return false }
        if (p.length < 6) { showError("Password must be at least 6 characters."); return false }
        return true
    }
    private fun busy(v:Boolean){progress.visibility=if(v)View.VISIBLE else View.GONE}
    private fun showError(s:String){error.text=s;error.visibility=View.VISIBLE}
    private fun login() {
        if(!valid())return; busy(true)
        auth.signInWithEmailAndPassword(email.text.toString().trim(),password.text.toString()).addOnCompleteListener(this){
            busy(false); if(it.isSuccessful) openBrowser() else showError(it.exception?.localizedMessage ?: "Login failed.")
        }
    }
    private fun signup() {
        if(!valid())return; busy(true)
        auth.createUserWithEmailAndPassword(email.text.toString().trim(),password.text.toString()).addOnCompleteListener(this){
            busy(false); if(it.isSuccessful) openBrowser() else showError(it.exception?.localizedMessage ?: "Sign up failed.")
        }
    }
    private fun reset() {
        val e=email.text.toString().trim()
        if(!android.util.Patterns.EMAIL_ADDRESS.matcher(e).matches()){showError("Enter your email first.");return}
        busy(true); auth.sendPasswordResetEmail(e).addOnCompleteListener(this){
            busy(false); if(it.isSuccessful) showError("Password reset email sent.") else showError(it.exception?.localizedMessage ?: "Reset failed.")
        }
    }
    private fun openBrowser(){startActivity(Intent(this,MainActivity::class.java));finish()}
}
