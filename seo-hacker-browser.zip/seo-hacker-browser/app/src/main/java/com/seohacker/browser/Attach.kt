package com.seohacker.browser

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.media.ExifInterface
import android.net.Uri
import android.provider.OpenableColumns
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.Locale
import java.util.zip.ZipInputStream

/** A file the user attached to the AI chat. images = saved JPEG paths, text = extracted text. */
class Att(val name: String, val images: List<String>, val text: String)

object Attach {
    private const val MAX_TEXT = 30000
    private var counter = 0

    fun dir(ctx: Context): File {
        val d = File(ctx.filesDir, "chat_att")
        d.mkdirs()
        return d
    }

    fun discard(a: Att) {
        for (p in a.images) {
            try { File(p).delete() } catch (e: Exception) { }
        }
    }

    private fun nextFile(ctx: Context, tag: String): File {
        counter++
        return File(dir(ctx), tag + "_" + System.currentTimeMillis() + "_" + counter + ".jpg")
    }

    fun nameOf(ctx: Context, uri: Uri): String {
        var n = ""
        try {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) n = c.getString(i) ?: ""
                }
            }
        } catch (e: Exception) { }
        if (n.isBlank()) n = uri.lastPathSegment ?: "file"
        return n
    }

    fun load(ctx: Context, uri: Uri, tag: String): Att {
        val name = nameOf(ctx, uri)
        val lower = name.lowercase(Locale.ROOT)
        val mime = (ctx.contentResolver.getType(uri) ?: "").lowercase(Locale.ROOT)
        val isImage = mime.startsWith("image/") || Regex(".*\\.(png|jpe?g|webp|gif|bmp)$").matches(lower)
        return when {
            isImage -> Att(name, listOf(saveImage(ctx, uri, tag)), "")
            mime == "application/pdf" || lower.endsWith(".pdf") -> pdf(ctx, uri, name, tag)
            lower.endsWith(".docx") -> Att(name, emptyList(), docx(ctx, uri))
            lower.endsWith(".xlsx") || lower.endsWith(".xls") || lower.endsWith(".pptx") || lower.endsWith(".zip") ->
                throw IllegalStateException("$name: this file type is not supported. Export it as CSV or PDF and attach that.")
            else -> Att(name, emptyList(), readText(ctx, uri, name))
        }
    }

    private fun fit(b: Bitmap, max: Int, rot: Int): Bitmap {
        val m = Matrix()
        val side = maxOf(b.width, b.height)
        if (side > max) {
            val s = max.toFloat() / side
            m.postScale(s, s)
        }
        if (rot != 0) m.postRotate(rot.toFloat())
        if (m.isIdentity) return b
        val out = Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
        if (out !== b) b.recycle()
        return out
    }

    private fun saveJpeg(ctx: Context, tag: String, src: Bitmap, quality: Int): String {
        var bmp = src
        if (bmp.hasAlpha()) {
            val flat = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
            val c = Canvas(flat)
            c.drawColor(Color.WHITE)
            c.drawBitmap(bmp, 0f, 0f, null)
            bmp.recycle()
            bmp = flat
        }
        val f = nextFile(ctx, tag)
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, quality, it) }
        bmp.recycle()
        return f.absolutePath
    }

    private fun saveImage(ctx: Context, uri: Uri, tag: String): String {
        val cr = ctx.contentResolver
        val opts = BitmapFactory.Options()
        opts.inJustDecodeBounds = true
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        var sample = 1
        val maxSide = maxOf(opts.outWidth, opts.outHeight)
        while (maxSide / sample > 2400) sample *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sample
        val bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
            ?: throw IllegalStateException("Could not read this image.")
        var rot = 0
        try {
            cr.openInputStream(uri)?.use { s ->
                rot = when (ExifInterface(s).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                    6 -> 90
                    3 -> 180
                    8 -> 270
                    else -> 0
                }
            }
        } catch (e: Exception) { }
        return saveJpeg(ctx, tag, fit(bmp, 1568, rot), 82)
    }

    private fun pdf(ctx: Context, uri: Uri, name: String, tag: String): Att {
        val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: throw IllegalStateException("Could not open $name.")
        val paths = ArrayList<String>()
        var pages = 0
        try {
            val r = PdfRenderer(pfd)
            try {
                pages = r.pageCount
                for (i in 0 until minOf(pages, 6)) {
                    val p = r.openPage(i)
                    try {
                        val w = 1200
                        val h = (w.toFloat() * p.height / p.width).toInt().coerceIn(200, 3200)
                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(Color.WHITE)
                        p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        paths.add(saveJpeg(ctx, tag, bmp, 78))
                    } finally {
                        p.close()
                    }
                }
            } finally {
                try { r.close() } catch (e: Exception) { }
            }
        } catch (e: SecurityException) {
            throw IllegalStateException("$name is password protected or damaged.")
        } finally {
            try { pfd.close() } catch (e: Exception) { }
        }
        val note = if (pages > 6) "[$name: PDF with $pages pages, the first 6 pages are attached as images.]"
        else "[$name: PDF with $pages page(s) attached as images.]"
        return Att(name, paths, note)
    }

    private fun docx(ctx: Context, uri: Uri): String {
        ctx.contentResolver.openInputStream(uri)?.use { ins ->
            val z = ZipInputStream(ins)
            var e = z.nextEntry
            while (e != null) {
                if (e.name == "word/document.xml") {
                    val xml = readLimited(z, 3000000).toString(Charsets.UTF_8)
                    var t = xml.replace("</w:p>", "\n").replace(Regex("<w:tab/>"), "\t").replace(Regex("<w:br[^>]*/>"), "\n")
                    t = t.replace(Regex("<[^>]+>"), "")
                    t = t.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'")
                    return t.trim().take(MAX_TEXT)
                }
                e = z.nextEntry
            }
        }
        throw IllegalStateException("Could not read this Word file.")
    }

    private fun readLimited(ins: InputStream, limit: Int): ByteArray {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(16384)
        var total = 0
        while (total < limit) {
            val r = ins.read(buf, 0, minOf(buf.size, limit - total))
            if (r < 0) break
            out.write(buf, 0, r)
            total += r
        }
        return out.toByteArray()
    }

    private fun readText(ctx: Context, uri: Uri, name: String): String {
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { readLimited(it, 400000) }
            ?: throw IllegalStateException("Could not open $name.")
        val s = String(bytes, Charsets.UTF_8)
        var bad = 0
        for (ch in s.take(3000)) if (ch == '\u0000') bad++
        if (bad > 5) throw IllegalStateException("$name: this file type is not supported. Send images, PDF, Word (.docx) or text/CSV files.")
        return s.take(MAX_TEXT)
    }
}
