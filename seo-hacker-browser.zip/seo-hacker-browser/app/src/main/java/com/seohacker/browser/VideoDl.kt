package com.seohacker.browser

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.webkit.CookieManager
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Callable
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.CountDownLatch
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutionException
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

class CancelEx : RuntimeException()

class DlTask(val id: String, var title: String, var url: String, var headers: Map<String, String>, val kind: String) {
    @Volatile var audioUrl: String = ""
    @Volatile var state: String = "queued"
    @Volatile var done: Long = 0L
    @Volatile var total: Long = 0L
    @Volatile var bytes: Long = 0L
    @Volatile var message: String = ""
    @Volatile var note: String = ""
    @Volatile var fileName: String = ""
    @Volatile var uri: String = ""
    @Volatile var cancel: Boolean = false
    @Volatile var time: Long = System.currentTimeMillis()
    @Volatile var quality: String = ""

    fun active(): Boolean = state == "queued" || state == "downloading" || state == "merging"
    fun percent(): Int = if (total > 0) ((done * 100L) / total).toInt().coerceIn(0, 100) else 0
}

object Fmt {
    fun size(b: Long): String = when {
        b >= 1073741824L -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
        b >= 1048576L -> String.format(Locale.US, "%.1f MB", b / 1048576.0)
        b >= 1024L -> (b / 1024L).toString() + " KB"
        else -> b.toString() + " B"
    }

    fun dur(sec: Double): String {
        val s = sec.toLong()
        val h = s / 3600
        val m = (s % 3600) / 60
        val x = s % 60
        return if (h > 0) "${h}h ${m}m" else if (m > 0) "${m}m ${x}s" else "${x}s"
    }
}

object Names {
    fun base(title: String, q: String): String {
        var b = title.replace(Regex("[^\\p{L}\\p{N} _.-]"), "").trim().replace(Regex("\\s+"), "_").take(70)
        if (b.isBlank()) b = "video_" + System.currentTimeMillis()
        return if (q.isNotBlank()) b + "_" + q else b
    }
}

object Net {
    const val UA = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"

    class HttpFail(val code: Int, msg: String) : Exception(msg)

    fun open(url: String, headers: Map<String, String>, start: Long = -1L, len: Long = -1L): HttpURLConnection {
        var cur = url
        var hops = 0
        while (true) {
            val c = URL(cur).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 12000
            c.readTimeout = 25000
            var hasUa = false
            var hasCookie = false
            var hasAccept = false
            for ((k, v) in headers) {
                if (k.equals("user-agent", true)) hasUa = true
                if (k.equals("cookie", true)) hasCookie = true
                if (k.equals("accept", true)) hasAccept = true
                c.setRequestProperty(k, v)
            }
            if (!hasUa) c.setRequestProperty("User-Agent", UA)
            if (!hasAccept) c.setRequestProperty("Accept", "*/*")
            if (!hasCookie) {
                val ck = CookieManager.getInstance().getCookie(cur)
                if (!ck.isNullOrBlank()) c.setRequestProperty("Cookie", ck)
            }
            if (start >= 0L) {
                c.setRequestProperty("Range", "bytes=" + start + "-" + (if (len > 0L) (start + len - 1L).toString() else ""))
            }
            val code = c.responseCode
            if (code in 300..399 && hops < 6) {
                val loc = c.getHeaderField("Location")
                c.disconnect()
                if (loc.isNullOrBlank()) throw HttpFail(code, "HTTP $code")
                cur = URL(URL(cur), loc).toString()
                hops++
                continue
            }
            if (code !in 200..299) {
                c.disconnect()
                throw HttpFail(code, "HTTP $code")
            }
            return c
        }
    }

    fun bytes(url: String, headers: Map<String, String>, start: Long = -1L, len: Long = -1L): ByteArray {
        val c = open(url, headers, start, len)
        try {
            var data = c.inputStream.use { it.readBytes() }
            if (start >= 0L && len > 0L && c.responseCode == 200 && data.size > len) {
                val from = start.toInt()
                val to = (start + len).toInt()
                if (to <= data.size) data = data.copyOfRange(from, to)
            }
            return data
        } finally {
            c.disconnect()
        }
    }
}

class HlsSeg(
    val url: String, val dur: Double, val seq: Long, val method: String,
    val keyUrl: String, val iv: String, val rangeStart: Long, val rangeLen: Long
)

class HlsVariant(val url: String, val bw: Long, val res: String, val audio: String)
class HlsMaster(val variants: List<HlsVariant>, val audioUris: Map<String, String>)
class HlsMedia(val segs: List<HlsSeg>, val mapUrl: String, val mapStart: Long, val mapLen: Long, val vod: Boolean) {
    fun duration(): Double {
        var d = 0.0
        for (s in segs) d += s.dur
        return d
    }
}

object Hls {
    private val attrRe = Regex("([A-Z0-9-]+)=(\"[^\"]*\"|[^,]*)")

    fun attrs(s: String): Map<String, String> {
        val m = HashMap<String, String>()
        for (r in attrRe.findAll(s)) m[r.groupValues[1]] = r.groupValues[2].trim().trim('"')
        return m
    }

    fun resolve(base: String, ref: String): String =
        try { URL(URL(base), ref.trim()).toString() } catch (e: Exception) { ref.trim() }

    fun isMaster(t: String): Boolean = t.contains("#EXT-X-STREAM-INF")

    fun qLabel(v: HlsVariant): String {
        val r = v.res
        if (r.contains("x")) {
            val h = r.substringAfter("x").trim()
            if (h.isNotEmpty()) return h + "p"
        }
        return if (v.bw > 0) (v.bw / 1000).toString() + "kbps" else "auto"
    }

    fun master(text: String, base: String): HlsMaster {
        val vs = ArrayList<HlsVariant>()
        val au = HashMap<String, String>()
        val lines = text.lines().map { it.trim() }
        var i = 0
        while (i < lines.size) {
            val l = lines[i]
            if (l.startsWith("#EXT-X-MEDIA:")) {
                val a = attrs(l.substringAfter(':'))
                val uri = a["URI"]
                if (a["TYPE"] == "AUDIO" && !uri.isNullOrBlank()) {
                    val g = a["GROUP-ID"] ?: ""
                    if (!au.containsKey(g) || a["DEFAULT"] == "YES") au[g] = resolve(base, uri)
                }
            } else if (l.startsWith("#EXT-X-STREAM-INF:")) {
                val a = attrs(l.substringAfter(':'))
                var j = i + 1
                while (j < lines.size && (lines[j].isEmpty() || lines[j].startsWith("#"))) j++
                if (j < lines.size) {
                    vs.add(HlsVariant(resolve(base, lines[j]), a["BANDWIDTH"]?.toLongOrNull() ?: 0L, a["RESOLUTION"] ?: "", a["AUDIO"] ?: ""))
                    i = j
                }
            }
            i++
        }
        return HlsMaster(vs, au)
    }

    fun media(text: String, base: String): HlsMedia {
        var seq = 0L
        var method = "NONE"
        var keyUrl = ""
        var iv = ""
        var mapUrl = ""
        var mapStart = -1L
        var mapLen = -1L
        var dur = 0.0
        var rangeLen = -1L
        var rangeStart = -1L
        var lastEnd = 0L
        var vod = false
        val segs = ArrayList<HlsSeg>()
        for (raw in text.lines()) {
            val l = raw.trim()
            if (l.isEmpty()) continue
            if (l.startsWith("#")) {
                if (l.startsWith("#EXT-X-MEDIA-SEQUENCE:")) {
                    seq = l.substringAfter(':').trim().toLongOrNull() ?: 0L
                } else if (l.startsWith("#EXT-X-ENDLIST") || l.startsWith("#EXT-X-PLAYLIST-TYPE:VOD")) {
                    vod = true
                } else if (l.startsWith("#EXT-X-KEY:")) {
                    val a = attrs(l.substringAfter(':'))
                    method = a["METHOD"] ?: "NONE"
                    val u = a["URI"]
                    keyUrl = if (u.isNullOrBlank()) "" else resolve(base, u)
                    iv = a["IV"] ?: ""
                } else if (l.startsWith("#EXT-X-MAP:")) {
                    val a = attrs(l.substringAfter(':'))
                    val u = a["URI"]
                    if (!u.isNullOrBlank()) mapUrl = resolve(base, u)
                    val br = a["BYTERANGE"]
                    if (br != null) {
                        val p = br.split("@")
                        mapLen = p[0].toLongOrNull() ?: -1L
                        mapStart = if (p.size > 1) (p[1].toLongOrNull() ?: 0L) else 0L
                    }
                } else if (l.startsWith("#EXTINF:")) {
                    dur = l.substringAfter(':').substringBefore(',').trim().toDoubleOrNull() ?: 0.0
                } else if (l.startsWith("#EXT-X-BYTERANGE:")) {
                    val p = l.substringAfter(':').trim().split("@")
                    rangeLen = p[0].toLongOrNull() ?: -1L
                    rangeStart = if (p.size > 1) (p[1].toLongOrNull() ?: 0L) else lastEnd
                }
            } else {
                val hasRange = rangeLen > 0L
                segs.add(HlsSeg(resolve(base, l), dur, seq, method, keyUrl, iv, if (hasRange) rangeStart else -1L, if (hasRange) rangeLen else -1L))
                if (hasRange) lastEnd = rangeStart + rangeLen
                seq++
                dur = 0.0
                rangeLen = -1L
                rangeStart = -1L
            }
        }
        return HlsMedia(segs, mapUrl, mapStart, mapLen, vod)
    }
}

object Saver {
    fun save(src: File, name: String, mime: String): String {
        val ctx = App.ctx
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues()
            cv.put(MediaStore.Downloads.DISPLAY_NAME, name)
            cv.put(MediaStore.Downloads.MIME_TYPE, mime)
            cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            cv.put(MediaStore.Downloads.IS_PENDING, 1)
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                ?: throw IllegalStateException("Cannot create the file in Downloads.")
            try {
                val os = ctx.contentResolver.openOutputStream(uri) ?: throw IllegalStateException("Cannot open the Downloads file.")
                os.use { out -> FileInputStream(src).use { ins -> ins.copyTo(out, 65536) } }
            } catch (e: Exception) {
                try { ctx.contentResolver.delete(uri, null, null) } catch (x: Exception) { }
                throw e
            }
            val done = ContentValues()
            done.put(MediaStore.Downloads.IS_PENDING, 0)
            ctx.contentResolver.update(uri, done, null, null)
            return uri.toString()
        }
        @Suppress("DEPRECATION")
        val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        dir.mkdirs()
        val stem = name.substringBeforeLast('.')
        val ext = name.substringAfterLast('.', "")
        var f = File(dir, name)
        var n = 1
        while (f.exists()) {
            f = File(dir, stem + "_" + n + (if (ext.isNotEmpty()) ".$ext" else ""))
            n++
        }
        FileInputStream(src).use { ins -> FileOutputStream(f).use { out -> ins.copyTo(out, 65536) } }
        val latch = CountDownLatch(1)
        var res: Uri? = null
        MediaScannerConnection.scanFile(ctx, arrayOf(f.absolutePath), arrayOf(mime)) { _, u ->
            res = u
            latch.countDown()
        }
        latch.await(3, TimeUnit.SECONDS)
        return (res ?: Uri.fromFile(f)).toString()
    }
}

/** Re-wraps a .ts (or fragmented mp4) download into a normal .mp4, optionally merging a separate audio file. */
object Remux {
    fun toMp4(video: File, audio: File?, out: File, cancel: () -> Boolean, progress: (Int) -> Unit): Boolean {
        val srcs = ArrayList<MediaExtractor>()
        var muxer: MediaMuxer? = null
        var started = false
        try {
            val e1 = MediaExtractor()
            srcs.add(e1)
            e1.setDataSource(video.absolutePath)
            var e2: MediaExtractor? = null
            if (audio != null) {
                val x = MediaExtractor()
                srcs.add(x)
                x.setDataSource(audio.absolutePath)
                e2 = x
            }
            val mx = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = mx
            val maps = ArrayList<HashMap<Int, Int>>()
            var haveV = false
            var haveA = false

            fun pick(ex: MediaExtractor, wantV: Boolean, wantA: Boolean): HashMap<Int, Int> {
                val m = HashMap<Int, Int>()
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                    if (wantV && !haveV && mime.startsWith("video/")) {
                        if (f.containsKey(MediaFormat.KEY_ROTATION)) {
                            try { mx.setOrientationHint(f.getInteger(MediaFormat.KEY_ROTATION)) } catch (x: Exception) { }
                        }
                        m[i] = mx.addTrack(f)
                        haveV = true
                        ex.selectTrack(i)
                    } else if (wantA && !haveA && mime.startsWith("audio/")) {
                        m[i] = mx.addTrack(f)
                        haveA = true
                        ex.selectTrack(i)
                    }
                }
                return m
            }

            maps.add(pick(e1, true, e2 == null))
            if (e2 != null) maps.add(pick(e2, false, true))
            if (!haveV) return false
            if (e2 != null && !haveA) return false

            mx.start()
            started = true
            val buf = ByteBuffer.allocate(4 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()
            val total = (video.length() + (audio?.length() ?: 0L)).coerceAtLeast(1L)
            var read = 0L
            var lastP = -1
            while (true) {
                if (cancel()) return false
                var best = -1
                var bestT = Long.MAX_VALUE
                for (k in srcs.indices) {
                    val t = srcs[k].sampleTime
                    if (t >= 0L && t < bestT) {
                        bestT = t
                        best = k
                    }
                }
                if (best < 0) break
                val ex = srcs[best]
                buf.clear()
                val size = ex.readSampleData(buf, 0)
                if (size < 0) break
                val mi = maps[best][ex.sampleTrackIndex]
                if (mi != null) {
                    val key = (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0
                    info.set(0, size, ex.sampleTime, if (key) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                    mx.writeSampleData(mi, buf, info)
                }
                read += size
                ex.advance()
                val p = ((read * 100L) / total).toInt().coerceIn(0, 99)
                if (p != lastP) {
                    lastP = p
                    progress(p)
                }
            }
            mx.stop()
            started = false
            return true
        } catch (e: Throwable) {
            try { out.delete() } catch (x: Exception) { }
            return false
        } finally {
            if (started) {
                try { muxer?.stop() } catch (x: Exception) { }
            }
            try { muxer?.release() } catch (x: Exception) { }
            for (s in srcs) {
                try { s.release() } catch (x: Exception) { }
            }
        }
    }
}

object HlsEngine {
    private fun ivBytes(s: HlsSeg): ByteArray {
        if (s.iv.isNotBlank()) {
            var h = s.iv.trim().removePrefix("0x").removePrefix("0X")
            if (h.length > 32) h = h.takeLast(32)
            while (h.length < 32) h = "0$h"
            val b = ByteArray(16)
            for (i in 0 until 16) b[i] = h.substring(i * 2, i * 2 + 2).toInt(16).toByte()
            return b
        }
        val b = ByteArray(16)
        var v = s.seq
        for (i in 15 downTo 8) {
            b[i] = (v and 0xffL).toByte()
            v = v shr 8
        }
        return b
    }

    private fun decrypt(d: ByteArray, key: ByteArray, iv: ByteArray): ByteArray {
        val spec = SecretKeySpec(key, "AES")
        val ivs = IvParameterSpec(iv)
        return try {
            val c = Cipher.getInstance("AES/CBC/PKCS5Padding")
            c.init(Cipher.DECRYPT_MODE, spec, ivs)
            c.doFinal(d)
        } catch (e: Exception) {
            val n = d.size - d.size % 16
            val c = Cipher.getInstance("AES/CBC/NoPadding")
            c.init(Cipher.DECRYPT_MODE, spec, ivs)
            c.doFinal(d, 0, n)
        }
    }

    /** Some sites hide TS segments behind a fake image header. Find the real start (0x47 every 188 bytes). */
    private fun tsOffset(d: ByteArray): Int {
        if (d.isEmpty() || d[0] == 0x47.toByte()) return 0
        val lim = minOf(d.size - 376, 65536)
        var i = 1
        while (i < lim) {
            if (d[i] == 0x47.toByte() && d[i + 188] == 0x47.toByte() && d[i + 376] == 0x47.toByte()) return i
            i++
        }
        return 0
    }

    private fun fetchSeg(t: DlTask, s: HlsSeg, keys: ConcurrentHashMap<String, ByteArray>, strip: Boolean): ByteArray {
        var last: Exception? = null
        for (attempt in 1..5) {
            if (t.cancel) throw CancelEx()
            try {
                var d = Net.bytes(s.url, t.headers, s.rangeStart, s.rangeLen)
                if (s.method == "AES-128") {
                    if (s.keyUrl.isEmpty()) throw IllegalStateException("Encrypted video without a key link.")
                    val key = keys.getOrPut(s.keyUrl) { Net.bytes(s.keyUrl, t.headers) }
                    if (key.size != 16) throw IllegalStateException("The video key is protected and cannot be used.")
                    d = decrypt(d, key, ivBytes(s))
                }
                if (strip) {
                    val o = tsOffset(d)
                    if (o > 0) d = d.copyOfRange(o, d.size)
                }
                if (d.isEmpty()) throw IllegalStateException("Empty segment")
                return d
            } catch (e: CancelEx) {
                throw e
            } catch (e: Exception) {
                last = e
                if (e is Net.HttpFail && (e.code == 401 || e.code == 403 || e.code == 404 || e.code == 410) && attempt >= 2) break
                try { Thread.sleep(400L * attempt) } catch (ie: InterruptedException) { throw CancelEx() }
            }
        }
        val m = last
        if (m is Net.HttpFail) {
            throw IllegalStateException("The server refused a part of the video (" + m.message + "). The link may have expired or is protected. Play the video again and retry.")
        }
        throw IllegalStateException("A part of the video failed to download: " + (m?.message ?: "unknown error"))
    }

    private fun downloadSegments(t: DlTask, md: HlsMedia, out: File, baseDone: Long) {
        val n = md.segs.size
        val fmp4 = md.mapUrl.isNotEmpty()
        val keys = ConcurrentHashMap<String, ByteArray>()
        val pool = Executors.newFixedThreadPool(12)
        val futs = arrayOfNulls<Future<ByteArray>>(n)
        var submitted = 0
        val os = BufferedOutputStream(FileOutputStream(out), 65536)
        try {
            if (fmp4) {
                val initData = Net.bytes(md.mapUrl, t.headers, md.mapStart, md.mapLen)
                os.write(initData)
                t.bytes = t.bytes + initData.size
            }
            for (i in 0 until n) {
                while (submitted < n && submitted < i + 24) {
                    val s = md.segs[submitted]
                    futs[submitted] = pool.submit(Callable<ByteArray> { fetchSeg(t, s, keys, !fmp4) })
                    submitted++
                }
                val data = try {
                    futs[i]!!.get()
                } catch (e: ExecutionException) {
                    throw (e.cause ?: e)
                } catch (e: InterruptedException) {
                    throw CancelEx()
                }
                futs[i] = null
                os.write(data)
                t.bytes = t.bytes + data.size
                t.done = baseDone + i + 1
                t.message = ""
                DlManager.changed()
                if (t.cancel) throw CancelEx()
            }
        } finally {
            pool.shutdownNow()
            try { os.close() } catch (e: Exception) { }
        }
    }

    fun run(t: DlTask) {
        val dir = DlManager.tmpDir()
        val tmpV = File(dir, t.id + ".v")
        var tmpA: File? = null
        t.message = "Reading playlist..."
        DlManager.changed()
        var url = t.url
        var audioUrl = t.audioUrl
        var text = String(Net.bytes(url, t.headers), Charsets.UTF_8)
        if (!text.contains("#EXTM3U")) throw IllegalStateException("This link is not a valid video playlist.")
        if (Hls.isMaster(text)) {
            val m = Hls.master(text, url)
            if (m.variants.isEmpty()) throw IllegalStateException("No video quality found in the playlist.")
            val v = m.variants.maxByOrNull { it.bw } ?: m.variants[0]
            url = v.url
            if (audioUrl.isEmpty() && v.audio.isNotEmpty()) audioUrl = m.audioUris[v.audio] ?: ""
            if (t.quality.isEmpty()) t.quality = Hls.qLabel(v)
            text = String(Net.bytes(url, t.headers), Charsets.UTF_8)
        }
        val md = Hls.media(text, url)
        if (md.segs.isEmpty()) throw IllegalStateException("No video parts found in the playlist.")
        if (md.segs.any { it.method != "NONE" && it.method != "AES-128" }) {
            throw IllegalStateException("This video is DRM protected and cannot be saved.")
        }
        var am: HlsMedia? = null
        if (audioUrl.isNotEmpty()) {
            val at = String(Net.bytes(audioUrl, t.headers), Charsets.UTF_8)
            val parsed = Hls.media(at, audioUrl)
            if (parsed.segs.isNotEmpty()) am = parsed
        }
        t.total = (md.segs.size + (am?.segs?.size ?: 0)).toLong()
        t.done = 0L
        t.bytes = 0L
        t.message = ""
        DlManager.changed()

        downloadSegments(t, md, tmpV, 0L)
        if (am != null) {
            val fa = File(dir, t.id + ".a")
            downloadSegments(t, am, fa, md.segs.size.toLong())
            tmpA = fa
        }
        if (t.done < t.total) throw IllegalStateException("The download stopped early. Please retry.")
        if (t.cancel) throw CancelEx()

        val fmp4 = md.mapUrl.isNotEmpty()
        var finalFile = tmpV
        var ext = if (fmp4) "mp4" else "ts"
        var note = ""
        if (!fmp4 || tmpA != null) {
            t.state = "merging"
            t.message = "Converting to MP4..."
            DlManager.changed()
            val o = File(dir, t.id + ".mp4")
            val ok = Remux.toMp4(tmpV, tmpA, o, { t.cancel }) { p ->
                t.message = "Converting to MP4... $p%"
                DlManager.changed()
            }
            if (t.cancel) throw CancelEx()
            val inSize = tmpV.length() + (tmpA?.length() ?: 0L)
            if (ok && o.exists() && o.length() > inSize * 0.7) {
                finalFile = o
                ext = "mp4"
            } else {
                o.delete()
                note = "Saved as ." + ext + " (conversion to MP4 was not possible). Open it with VLC or MX Player."
            }
        }
        val base = Names.base(t.title, t.quality)
        val mime = if (ext == "mp4") "video/mp4" else "video/mp2t"
        val name = "$base.$ext"
        t.message = "Saving to Downloads..."
        DlManager.changed()
        t.bytes = finalFile.length()
        t.uri = Saver.save(finalFile, name, mime)
        t.fileName = name
        if (tmpA != null && finalFile === tmpV) {
            Saver.save(tmpA, "${base}_audio.ts", "video/mp2t")
            note = "Video and audio were saved as two files (could not merge)."
        }
        t.note = note
    }
}

object DirectEngine {
    private const val PARTS = 8

    /** Returns total size when the server supports ranges, else -1. */
    private fun rangeSize(t: DlTask): Long {
        return try {
            val c = Net.open(t.url, t.headers, 0L, 1L)
            try {
                val ct = (c.contentType ?: "").lowercase(Locale.ROOT)
                if (ct.startsWith("text/") || ct.contains("html")) return -1L
                val cr = c.getHeaderField("Content-Range")
                if (c.responseCode == 206 && cr != null && cr.contains("/")) cr.substringAfter("/").trim().toLongOrNull() ?: -1L else -1L
            } finally { c.disconnect() }
        } catch (e: Exception) { -1L }
    }

    private fun fast(t: DlTask, tmp: File, size: Long): Boolean {
        val partSize = (size + PARTS - 1) / PARTS
        val got = java.util.concurrent.atomic.AtomicLong(0L)
        val failed = java.util.concurrent.atomic.AtomicReference<Throwable?>(null)
        java.io.RandomAccessFile(tmp, "rw").use { it.setLength(size) }
        val pool = Executors.newFixedThreadPool(PARTS)
        t.total = size; t.done = 0L
        val tasks = (0 until PARTS).mapNotNull { i ->
            val from = i * partSize
            if (from >= size) null else Callable<Unit> {
                val to = minOf(size, from + partSize) - 1
                var pos = from
                var attempt = 0
                while (pos <= to && failed.get() == null) {
                    if (t.cancel) throw CancelEx()
                    try {
                        val c = Net.open(t.url, t.headers, pos, to - pos + 1)
                        try {
                            c.inputStream.use { ins ->
                                java.io.RandomAccessFile(tmp, "rw").use { raf ->
                                    raf.seek(pos)
                                    val buf = ByteArray(65536)
                                    while (pos <= to) {
                                        if (t.cancel) throw CancelEx()
                                        val r = ins.read(buf, 0, minOf(buf.size.toLong(), to - pos + 1).toInt())
                                        if (r < 0) break
                                        raf.write(buf, 0, r)
                                        pos += r
                                        t.done = got.addAndGet(r.toLong()); t.bytes = t.done
                                        DlManager.changed()
                                    }
                                }
                            }
                        } finally { c.disconnect() }
                        if (pos <= to) throw IllegalStateException("part ended early")
                    } catch (e: CancelEx) { throw e
                    } catch (e: Exception) {
                        attempt++
                        if (attempt >= 5) { failed.compareAndSet(null, e); break }
                        try { Thread.sleep(500L * attempt) } catch (ie: InterruptedException) { throw CancelEx() }
                    }
                }
            }
        }
        try {
            val futs = tasks.map { pool.submit(it) }
            for (f in futs) {
                try { f.get() } catch (e: ExecutionException) { throw (e.cause ?: e) }
            }
        } finally { pool.shutdownNow() }
        return failed.get() == null && got.get() >= size
    }

    fun run(t: DlTask) {
        t.message = "Connecting..."
        DlManager.changed()
        val tmp = File(DlManager.tmpDir(), t.id + ".d")
        val path = Uri.parse(t.url).path ?: ""
        val m = Regex("\\.(mp4|webm|mkv|mov|m4v|3gp|avi|flv|wmv)$", RegexOption.IGNORE_CASE).find(path)
        val ext = m?.groupValues?.get(1)?.lowercase(Locale.ROOT) ?: "mp4"
        val mime = when (ext) {
            "webm" -> "video/webm"
            "mkv" -> "video/x-matroska"
            "mov" -> "video/quicktime"
            "3gp" -> "video/3gpp"
            "avi" -> "video/x-msvideo"
            "flv" -> "video/x-flv"
            "wmv" -> "video/x-ms-wmv"
            else -> "video/mp4"
        }
        // Fast path: several connections at once (much quicker than one connection).
        val size = rangeSize(t)
        if (size > 3_000_000L) {
            val ok = try { fast(t, tmp, size) } catch (e: CancelEx) { throw e } catch (e: Exception) { false }
            if (ok) {
                val name = Names.base(t.title, t.quality) + "." + ext
                t.message = "Saving to Downloads..."
                DlManager.changed()
                t.uri = Saver.save(tmp, name, mime)
                t.fileName = name
                return
            }
            tmp.delete(); t.done = 0L; t.bytes = 0L
        }
        val c = Net.open(t.url, t.headers)
        try {
            val ct = (c.contentType ?: "").lowercase(Locale.ROOT)
            if (ct.startsWith("text/") || ct.contains("html")) {
                throw IllegalStateException("The server returned a web page instead of a video. The link may have expired.")
            }
            val len = c.contentLengthLong
            t.total = if (len > 0L) len else 0L
            t.done = 0L
            var count = 0L
            var lastTick = 0L
            c.inputStream.use { ins ->
                FileOutputStream(tmp).use { os ->
                    val buf = ByteArray(131072)
                    while (true) {
                        if (t.cancel) throw CancelEx()
                        val r = ins.read(buf)
                        if (r < 0) break
                        os.write(buf, 0, r)
                        count += r
                        t.done = count
                        t.bytes = count
                        val now = System.currentTimeMillis()
                        if (now - lastTick > 400L) {
                            lastTick = now
                            DlManager.changed()
                        }
                    }
                }
            }
            if (len > 0L && count < len) {
                throw IllegalStateException("The download ended early (" + Fmt.size(count) + " of " + Fmt.size(len) + "). Please retry.")
            }
            if (count < 1024L) throw IllegalStateException("The downloaded file is empty.")
            val name = Names.base(t.title, t.quality) + "." + ext
            t.message = "Saving to Downloads..."
            DlManager.changed()
            t.uri = Saver.save(tmp, name, mime)
            t.fileName = name
        } finally {
            c.disconnect()
        }
    }
}

object DlManager {
    val tasks = CopyOnWriteArrayList<DlTask>()
    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val main = Handler(Looper.getMainLooper())
    private val pool = Executors.newFixedThreadPool(2)
    private val lock = Any()
    private var pending = false
    private var loaded = false

    fun tmpDir(): File {
        val b = App.ctx.getExternalFilesDir(null) ?: App.ctx.filesDir
        val d = File(b, "vdl")
        d.mkdirs()
        return d
    }

    fun init() {
        if (loaded) return
        loaded = true
        try { tmpDir().listFiles()?.forEach { it.delete() } } catch (e: Exception) { }
        load()
    }

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }

    fun active(): List<DlTask> = tasks.filter { it.active() }

    fun changed() {
        synchronized(lock) {
            if (pending) return
            pending = true
        }
        main.postDelayed({
            synchronized(lock) { pending = false }
            for (l in listeners) {
                try { l() } catch (e: Exception) { }
            }
        }, 250)
    }

    fun start(ctx: Context, title: String, url: String, headers: Map<String, String>, kind: String, audio: String, quality: String): DlTask {
        val t = DlTask(UUID.randomUUID().toString(), title, url, headers, kind)
        t.audioUrl = audio
        t.quality = quality
        tasks.add(0, t)
        launch(ctx, t)
        return t
    }

    fun retry(ctx: Context, t: DlTask) {
        if (t.active()) return
        launch(ctx, t)
    }

    private fun launch(ctx: Context, t: DlTask) {
        t.state = "queued"
        t.cancel = false
        t.done = 0L
        t.total = 0L
        t.bytes = 0L
        t.note = ""
        t.message = "Waiting..."
        try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, DownloadService::class.java))
        } catch (e: Exception) { }
        changed()
        pool.execute { run(t) }
    }

    fun cancel(t: DlTask) {
        t.cancel = true
        changed()
    }

    fun remove(t: DlTask) {
        if (t.active()) t.cancel = true
        tasks.remove(t)
        persist()
        changed()
    }

    fun clearFinished() {
        tasks.removeAll(tasks.filter { !it.active() }.toSet())
        persist()
        changed()
    }

    private fun run(t: DlTask) {
        if (t.cancel) {
            finish(t, "canceled", "Canceled")
            return
        }
        t.state = "downloading"
        t.message = "Starting..."
        changed()
        try {
            if (t.kind == "hls") HlsEngine.run(t) else DirectEngine.run(t)
            if (t.cancel) finish(t, "canceled", "Canceled") else finish(t, "done", "")
        } catch (e: CancelEx) {
            finish(t, "canceled", "Canceled")
        } catch (e: OutOfMemoryError) {
            finish(t, "failed", "Not enough memory for this video.")
        } catch (e: Throwable) {
            finish(t, "failed", e.message ?: "Download failed.")
        }
    }

    private fun finish(t: DlTask, state: String, msg: String) {
        t.state = state
        t.message = if (state == "done") (if (t.note.isNotBlank()) t.note else "Saved to Downloads") else msg
        t.time = System.currentTimeMillis()
        try {
            tmpDir().listFiles()?.forEach { if (it.name.startsWith(t.id)) it.delete() }
        } catch (e: Exception) { }
        persist()
        changed()
        DlNotify.finished(App.ctx, t)
    }

    private fun sp() = App.ctx.getSharedPreferences("video_dl", Context.MODE_PRIVATE)

    fun persist() {
        val arr = JSONArray()
        for (t in tasks.filter { !it.active() }.take(100)) {
            val h = JSONObject()
            for ((k, v) in t.headers) h.put(k, v)
            arr.put(
                JSONObject().put("id", t.id).put("title", t.title).put("url", t.url).put("kind", t.kind)
                    .put("audio", t.audioUrl).put("state", t.state).put("msg", t.message).put("file", t.fileName)
                    .put("uri", t.uri).put("bytes", t.bytes).put("time", t.time).put("q", t.quality).put("h", h)
            )
        }
        sp().edit().putString("tasks", arr.toString()).apply()
    }

    private fun load() {
        try {
            val arr = JSONArray(sp().getString("tasks", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val hm = HashMap<String, String>()
                val ho = o.optJSONObject("h")
                if (ho != null) {
                    val it = ho.keys()
                    while (it.hasNext()) {
                        val k = it.next()
                        hm[k] = ho.optString(k)
                    }
                }
                val t = DlTask(o.optString("id"), o.optString("title"), o.optString("url"), hm, o.optString("kind"))
                t.audioUrl = o.optString("audio")
                t.state = o.optString("state", "failed")
                t.message = o.optString("msg")
                t.fileName = o.optString("file")
                t.uri = o.optString("uri")
                t.bytes = o.optLong("bytes")
                t.time = o.optLong("time")
                t.quality = o.optString("q")
                if (t.active()) {
                    t.state = "failed"
                    t.message = "Interrupted"
                }
                tasks.add(t)
            }
        } catch (e: Exception) { }
    }
}
