package com.seohacker.browser

import android.app.Application
import android.content.Context
import com.google.firebase.FirebaseApp

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        ctx = applicationContext
        androidx.appcompat.app.AppCompatDelegate.setDefaultNightMode(androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_YES)
        runCatching { FirebaseApp.initializeApp(this) }
        DlManager.init()
    }
    companion object { lateinit var ctx: Context }
}
