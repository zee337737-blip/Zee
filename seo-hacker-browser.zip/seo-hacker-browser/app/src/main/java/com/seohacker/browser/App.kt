package com.seohacker.browser

import android.app.Application
import android.content.Context
import com.google.firebase.FirebaseApp

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        ctx = applicationContext
        runCatching { FirebaseApp.initializeApp(this) }
    }
    companion object { lateinit var ctx: Context }
}
