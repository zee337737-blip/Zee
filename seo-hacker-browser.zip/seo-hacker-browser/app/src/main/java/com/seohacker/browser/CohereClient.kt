package com.seohacker.browser

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object CohereClient {
    fun chat(apiKey: String, model: String, prompt: String): Result<String> =
        chat(apiKey, model, listOf(Msg("user", prompt)))

    /** Multi-turn chat. Roles: system, user, assistant. */
    fun chat(apiKey: String, model: String, messages: List<Msg>, maxTokens: Int = 4096): Result<String> {
        if (apiKey.isBlank()) return Result.failure(IllegalArgumentException("No Cohere API key. Open Planning Hub -> Settings."))
        return try {
            val conn = URL("https://api.cohere.com/v2/chat").openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 120000
            conn.doOutput = true
            conn.setRequestProperty("Authorization", "Bearer $apiKey")
            conn.setRequestProperty("Content-Type", "application/json")
            val arr = JSONArray()
            messages.forEach { m ->
                val o = JSONObject().put("role", m.role)
                val text = if (m.docText.isNotBlank()) m.content + "\n\n" + m.docText else m.content
                val imgs = if (m.role == "user") m.images.filter { File(it).exists() } else emptyList()
                if (imgs.isNotEmpty()) {
                    val parts = JSONArray()
                    parts.put(JSONObject().put("type", "text").put("text", text))
                    for (path in imgs) {
                        val b64 = Base64.encodeToString(File(path).readBytes(), Base64.NO_WRAP)
                        parts.put(
                            JSONObject().put("type", "image_url")
                                .put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$b64"))
                        )
                    }
                    o.put("content", parts)
                } else {
                    o.put("content", text)
                }
                arr.put(o)
            }
            val body = JSONObject().put("model", model).put("messages", arr).put("max_tokens", maxTokens).toString()
            conn.outputStream.use { it.write(body.toByteArray()) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val response = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code == 401) return Result.failure(IllegalStateException("Invalid Cohere API key (401)."))
            if (code == 429) return Result.failure(IllegalStateException("Cohere rate limit reached (429). Wait a minute and try again."))
            if (code !in 200..299) return Result.failure(IllegalStateException("Cohere API error $code: $response"))
            val o = JSONObject(response)
            val msg = o.optJSONObject("message")
            val content = msg?.optJSONArray("content")
            val text = if (content != null && content.length() > 0) content.getJSONObject(0).optString("text")
            else o.optString("text")
            if (text.isBlank()) Result.failure(IllegalStateException("Cohere returned an empty response.")) else Result.success(text)
        } catch (e: Exception) {
            Result.failure(IllegalStateException("Cohere request failed: ${e.message}", e))
        }
    }
}
