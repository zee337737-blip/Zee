package com.seohacker.browser

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class HistoryItem(val title: String, val url: String, val time: Long)

object HistoryStore {
    private const val KEY = "history"
    private fun sp(c: Context) = c.getSharedPreferences("seo_browser", Context.MODE_PRIVATE)
    fun all(c: Context): MutableList<HistoryItem> {
        val a = JSONArray(sp(c).getString(KEY, "[]"))
        return MutableList(a.length()) { i ->
            val o = a.getJSONObject(i); HistoryItem(o.optString("title"), o.optString("url"), o.optLong("time"))
        }
    }
    fun add(c: Context, title: String, url: String) {
        val list = all(c)
        list.removeAll { it.url == url }
        list.add(0, HistoryItem(title, url, System.currentTimeMillis()))
        save(c, list.take(500))
    }
    fun clear(c: Context) = sp(c).edit().remove(KEY).apply()
    private fun save(c: Context, list: List<HistoryItem>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("title", it.title).put("url", it.url).put("time", it.time)) }
        sp(c).edit().putString(KEY, a.toString()).apply()
    }
}
