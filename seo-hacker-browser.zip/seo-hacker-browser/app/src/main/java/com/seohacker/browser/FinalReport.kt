package com.seohacker.browser

import android.graphics.Color
import org.json.JSONObject

/** The AI "final report": weak points, solutions, action plan and keywords, shown on screen and exported as a sheet-style PDF. */
object FinalReport {
    val REQUEST = """
Now write the FINAL SEO REPORT using everything above: the saved reports, the page extracts and our whole conversation (include every improvement we agreed on). Write it in clear English.
Return ONLY one valid JSON object. No markdown, no code fences, no text before or after it. Use exactly this shape:
{
 "title": "short report title",
 "site": "website or page URL if known",
 "score": 0,
 "summary": "2-4 sentence overview of the site's SEO health",
 "weak_points": [ {"area": "e.g. Title tag", "problem": "what is wrong", "impact": "why it hurts SEO", "fix": "exact step-by-step solution", "priority": "High"} ],
 "action_plan": [ {"step": "what to do", "timeframe": "e.g. Day 1-2", "result": "expected result"} ],
 "keywords": [ {"keyword": "...", "intent": "informational", "suggestion": "how to use it"} ],
 "better_strategy": ["short bullet points of the improved overall strategy"]
}
"score" is a number from 0 to 100. "priority" is High, Medium or Low. List EVERY weak point you can find, one by one, each with its own solution. Use only free methods and tools.
""".trimIndent()

    fun parse(raw: String): JSONObject? {
        val s = raw.trim()
        val a = s.indexOf('{')
        val b = s.lastIndexOf('}')
        if (a < 0 || b <= a) return null
        return runCatching { JSONObject(s.substring(a, b + 1)) }.getOrNull()
    }

    private fun items(o: JSONObject, key: String): List<JSONObject> {
        val a = o.optJSONArray(key) ?: return emptyList()
        return (0 until a.length()).mapNotNull { a.optJSONObject(it) }
    }

    private fun strings(o: JSONObject, key: String): List<String> {
        val a = o.optJSONArray(key) ?: return emptyList()
        return (0 until a.length()).map { a.optString(it) }.filter { it.isNotBlank() }
    }

    private fun prio(p: String) = when {
        p.startsWith("h", true) -> "High"
        p.startsWith("l", true) -> "Low"
        else -> "Medium"
    }

    fun title(o: JSONObject) = o.optString("title").ifBlank { "Final SEO Report" }

    fun toPdf(o: JSONObject): PdfDoc {
        val site = o.optString("site")
        val sub = (if (site.isNotBlank()) "$site   |   " else "") + "Generated " + ReportSheets.stamp()
        val wp = items(o, "weak_points")
        val high = wp.count { prio(it.optString("priority")) == "High" }
        val score = o.optInt("score", -1)
        val chips = mutableListOf<Chip>()
        if (score in 0..100) {
            val col = if (score >= 80) "#16A34A" else if (score >= 50) "#D97706" else "#DC2626"
            chips += Chip("SEO SCORE", "$score / 100", Color.parseColor(col))
        }
        chips += Chip("WEAK POINTS", wp.size.toString(), Color.parseColor("#DC2626"))
        chips += Chip("HIGH PRIORITY", high.toString(), Color.parseColor("#D97706"))

        val tables = mutableListOf<SheetTable>()
        val summary = o.optString("summary")
        if (summary.isNotBlank()) tables += SheetTable("Summary", listOf("Overview"), listOf(1f), listOf(listOf(summary)))
        tables += SheetTable(
            "Weak points and solutions",
            listOf("#", "Area", "Weak point", "Impact", "Solution", "Priority"),
            listOf(4f, 12f, 22f, 20f, 36f, 8f),
            wp.mapIndexed { i, w ->
                listOf((i + 1).toString(), w.optString("area"), w.optString("problem"), w.optString("impact"), w.optString("fix"), prio(w.optString("priority")))
            },
            setOf(5)
        )
        tables += SheetTable(
            "Action plan",
            listOf("#", "Step", "Timeframe", "Expected result"),
            listOf(4f, 46f, 14f, 36f),
            items(o, "action_plan").mapIndexed { i, s ->
                listOf((i + 1).toString(), s.optString("step").ifBlank { s.optString("action") }, s.optString("timeframe"), s.optString("result"))
            }
        )
        tables += SheetTable(
            "Keyword opportunities",
            listOf("#", "Keyword", "Intent", "How to use it"),
            listOf(4f, 26f, 16f, 54f),
            items(o, "keywords").mapIndexed { i, k ->
                listOf((i + 1).toString(), k.optString("keyword"), k.optString("intent"), k.optString("suggestion"))
            }
        )
        tables += SheetTable(
            "Improved strategy",
            listOf("#", "Strategy point"),
            listOf(4f, 96f),
            strings(o, "better_strategy").mapIndexed { i, s -> listOf((i + 1).toString(), s) }
        )
        return PdfDoc(title(o), sub, chips, tables)
    }

    fun toSections(o: JSONObject): List<Section> {
        val out = mutableListOf<Section>()
        val score = o.optInt("score", -1)
        val ov = mutableListOf<Row>()
        if (score in 0..100) ov += Row("SEO score", "$score / 100", if (score >= 80) Status.GOOD else if (score >= 50) Status.WARN else Status.BAD)
        val summary = o.optString("summary")
        if (summary.isNotBlank()) ov += Row("Summary", summary)
        if (ov.isNotEmpty()) out += Section("Overview", ov)

        val wp = items(o, "weak_points")
        if (wp.isNotEmpty()) out += Section("Weak points and solutions", wp.mapIndexed { i, w ->
            Row(
                "${i + 1}. ${w.optString("area")}  [${prio(w.optString("priority"))}]",
                "Problem: ${w.optString("problem")}\nImpact: ${w.optString("impact")}\nSolution: ${w.optString("fix")}",
                Status.INFO, false, true
            )
        })
        val plan = items(o, "action_plan")
        if (plan.isNotEmpty()) out += Section("Action plan", plan.mapIndexed { i, s ->
            Row(
                "${i + 1}. ${s.optString("step").ifBlank { s.optString("action") }}",
                "When: ${s.optString("timeframe")}\nResult: ${s.optString("result")}", Status.INFO, false, true
            )
        })
        val kw = items(o, "keywords")
        if (kw.isNotEmpty()) out += Section("Keyword opportunities", kw.mapIndexed { i, k ->
            Row("${i + 1}. ${k.optString("keyword")}", "Intent: ${k.optString("intent")}\n${k.optString("suggestion")}", Status.INFO, false, true)
        })
        val st = strings(o, "better_strategy")
        if (st.isNotEmpty()) out += Section("Improved strategy", st.mapIndexed { i, s -> Row("", "${i + 1}. $s") })
        if (out.isEmpty()) out += Section("Report", listOf(Row("", "(empty)")))
        return out
    }
}
