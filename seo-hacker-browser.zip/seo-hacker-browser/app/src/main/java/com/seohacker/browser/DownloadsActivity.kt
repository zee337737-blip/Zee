package com.seohacker.browser

import android.app.DownloadManager
import android.content.ContentUris
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class DownloadsActivity : AppCompatActivity() {
    private class Entry(val name: String, val uri: Uri, val mime: String?)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_downloads)
        val list = findViewById<ListView>(R.id.downloadList)
        val items = load()
        if (items.isEmpty()) Toast.makeText(this, "No downloads yet.", Toast.LENGTH_SHORT).show()
        list.adapter = RowAdapter(this, items.map { it.name to (it.mime ?: "") })
        list.setOnItemClickListener { _, _, p, _ ->
            val e = items[p]
            runCatching {
                startActivity(Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(e.uri, e.mime ?: "*/*")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                })
            }.onFailure { Toast.makeText(this, "Cannot open file: " + it.message, Toast.LENGTH_LONG).show() }
        }
    }

    private fun load(): List<Entry> {
        val out = mutableListOf<Entry>()
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val base = MediaStore.Downloads.EXTERNAL_CONTENT_URI
                val proj = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.MIME_TYPE)
                contentResolver.query(base, proj, null, null, MediaStore.MediaColumns.DATE_ADDED + " DESC")?.use { c ->
                    while (c.moveToNext()) {
                        out.add(Entry(c.getString(1) ?: "file", ContentUris.withAppendedId(base, c.getLong(0)), c.getString(2)))
                    }
                }
            } else {
                val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
                dm.query(DownloadManager.Query().setFilterByStatus(DownloadManager.STATUS_SUCCESSFUL))?.use { c ->
                    val idI = c.getColumnIndex(DownloadManager.COLUMN_ID)
                    val tI = c.getColumnIndex(DownloadManager.COLUMN_TITLE)
                    while (c.moveToNext()) {
                        val id = c.getLong(idI)
                        val uri = dm.getUriForDownloadedFile(id) ?: continue
                        out.add(Entry(c.getString(tI) ?: "file", uri, dm.getMimeTypeForDownloadedFile(id)))
                    }
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Cannot read downloads: " + e.message, Toast.LENGTH_LONG).show()
        }
        return out
    }
}
