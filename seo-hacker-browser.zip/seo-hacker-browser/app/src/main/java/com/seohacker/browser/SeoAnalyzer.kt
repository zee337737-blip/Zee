package com.seohacker.browser

import android.webkit.WebView
import org.json.JSONObject
import org.json.JSONTokener
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

object SeoAnalyzer {
    fun script(): String = """
        (function(){
          const clean=s=>String(s||'').trim();
          const text=document.body?document.body.innerText:'';
          const words=text.toLowerCase().match(/[a-z0-9][a-z0-9'-]*/g)||[];
          const freq={}; words.forEach(w=>{freq[w]=(freq[w]||0)+1});
          const top=Object.keys(freq).sort((a,b)=>freq[b]-freq[a]).slice(0,20).map(w=>w+': '+freq[w]);
          const count=s=>document.querySelectorAll(s).length;
          const firstTexts=s=>Array.from(document.querySelectorAll(s)).map(x=>clean(x.innerText)).filter(Boolean);
          const meta=n=>{const x=document.querySelector('meta[name="'+n+'"]');return x?clean(x.content):''};
          const prop=n=>{const x=document.querySelector('meta[property="'+n+'"]');return x?clean(x.content):''};
          const href=n=>{const x=document.querySelector('link[rel="'+n+'"]');return x?clean(x.href):''};
          const alts=Array.from(document.images).filter(i=>!clean(i.getAttribute('alt'))).length;
          const links=Array.from(document.links);
          const host=location.host;
          const internal=links.filter(a=>{try{return new URL(a.href,location.href).host===host}catch(e){return false}}).length;
          const external=links.filter(a=>{try{return new URL(a.href,location.href).host!==host}catch(e){return false}}).length;
          const nofollow=links.filter(a=>/\bnofollow\b/i.test(a.rel||'')).length;
          const hreflang=Array.from(document.querySelectorAll('link[rel="alternate"][hreflang]')).map(x=>x.getAttribute('hreflang')+'='+x.href);
          const og={title:prop('og:title'),description:prop('og:description'),image:prop('og:image'),url:prop('og:url'),type:prop('og:type')};
          const tw={card:meta('twitter:card'),title:meta('twitter:title'),description:meta('twitter:description'),image:meta('twitter:image')};
          const jsonld=Array.from(document.querySelectorAll('script[type="application/ld+json"]')).map(x=>clean(x.textContent)).filter(Boolean);
          return JSON.stringify({
            url:location.href,title:document.title,titleLength:clean(document.title).length,
            metaDescription:meta('description'),metaDescriptionLength:meta('description').length,
            canonical:href('canonical'),robots:meta('robots'),h1:firstTexts('h1'),h1Count:count('h1'),
            h2Count:count('h2'),h3Count:count('h3'),h4Count:count('h4'),h5Count:count('h5'),h6Count:count('h6'),
            hreflang,openGraph:og,twitter:tw,jsonLd:jsonld,imagesWithoutAlt:alts,wordCount:words.length,
            topKeywords:top,internalLinks:internal,externalLinks:external,nofollowLinks:nofollow,
            lang:document.documentElement.getAttribute('lang')||'',viewport:meta('viewport')
          });
        })();
    """.trimIndent()

    fun parse(value: String): JSONObject {
        val decoded = JSONTokener(value).nextValue()
        return JSONTokener(decoded.toString()).nextValue() as JSONObject
    }

    fun analyze(view: WebView, callback: (JSONObject) -> Unit) {
        view.evaluateJavascript(script()) { value ->
            runCatching { parse(value) }.onSuccess(callback)
        }
    }

    fun fetchText(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 12000
        c.readTimeout = 20000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android 14; Mobile) AppleWebKit/537.36 Chrome/126.0.0.0 Mobile Safari/537.36")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    fun stripHtml(html: String): String = html.replace(Regex("(?is)<script.*?</script>|<style.*?</style>"), " ")
        .replace(Regex("(?s)<[^>]*>"), " ").replace(Regex("\\s+"), " ").trim()
        .take(6000)
}
