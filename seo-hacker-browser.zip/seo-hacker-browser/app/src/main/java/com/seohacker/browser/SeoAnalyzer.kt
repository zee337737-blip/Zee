package com.seohacker.browser

import android.os.Handler
import android.os.Looper
import android.text.Html
import android.webkit.WebView
import org.json.JSONObject
import org.json.JSONTokener
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

object SeoAnalyzer {
    fun script(): String = """
        (function(){
          const clean=s=>String(s||'').trim();
          const text=document.body?document.body.innerText:'';
          const words=text.toLowerCase().match(/[a-z0-9][a-z0-9'-]*/g)||[];
          const freq={}; words.forEach(w=>{freq[w]=(freq[w]||0)+1});
          const top=Object.keys(freq).sort((a,b)=>freq[b]-freq[a]).slice(0,20).map(w=>w+': '+freq[w]);
          const count=s=>document.querySelectorAll(s).length;
          const firstTexts=s=>Array.from(document.querySelectorAll(s)).map(x=>clean(x.innerText)).filter(Boolean);
          const allMeta=Array.from(document.querySelectorAll('meta'));
          const metaBy=n=>{n=String(n).toLowerCase();for(const x of allMeta){const keys=[x.getAttribute('name'),x.getAttribute('property'),x.getAttribute('itemprop'),x.getAttribute('http-equiv')];if(keys.some(k=>k&&k.trim().toLowerCase()===n)){const c=clean(x.getAttribute('content'));if(c)return c}}return ''};
          const meta=metaBy;const prop=metaBy;
          const href=n=>{const x=Array.from(document.querySelectorAll('link[rel]')).find(l=>(l.getAttribute('rel')||'').toLowerCase().split(/\s+/).indexOf(n)>=0);return x?clean(x.href):''};
          let desc='',descSrc='';
          for(const n of ['description','og:description','twitter:description']){const v=metaBy(n);if(v){desc=v;descSrc=n;break}}
          const alts=Array.from(document.images).filter(i=>!clean(i.getAttribute('alt'))).length;
          const links=Array.from(document.links);
          const host=location.host;
          const internal=links.filter(a=>{try{return new URL(a.href,location.href).host===host}catch(e){return false}}).length;
          const external=links.filter(a=>{try{return new URL(a.href,location.href).host!==host}catch(e){return false}}).length;
          const nofollow=links.filter(a=>/\bnofollow\b/i.test(a.rel||'')).length;
          const hreflang=Array.from(document.querySelectorAll('link[rel="alternate"][hreflang]')).map(x=>x.getAttribute('hreflang')+'='+x.href);
          const og={title:prop('og:title'),description:prop('og:description'),image:prop('og:image'),url:prop('og:url'),type:prop('og:type')};
          const tw={card:meta('twitter:card'),title:meta('twitter:title'),description:meta('twitter:description'),image:meta('twitter:image')};
          const jsonld=Array.from(document.querySelectorAll('script[type="application/ld+json"]')).map(x=>clean(x.textContent)).filter(Boolean);
          return JSON.stringify({
            url:location.href,title:document.title,titleLength:clean(document.title).length,
            metaDescription:desc,metaDescriptionLength:desc.length,metaDescriptionSource:descSrc,readyState:document.readyState,
            canonical:href('canonical'),robots:meta('robots'),h1:firstTexts('h1'),h1Count:count('h1'),
            h2Count:count('h2'),h3Count:count('h3'),h4Count:count('h4'),h5Count:count('h5'),h6Count:count('h6'),
            hreflang,openGraph:og,twitter:tw,jsonLd:jsonld,imagesWithoutAlt:alts,wordCount:words.length,
            topKeywords:top,internalLinks:internal,externalLinks:external,nofollowLinks:nofollow,
            lang:document.documentElement.getAttribute('lang')||'',viewport:meta('viewport')
          });
        })();
    """.trimIndent()

    fun parse(value: String): JSONObject {
        val decoded = JSONTokener(value).nextValue()
        return JSONTokener(decoded.toString()).nextValue() as JSONObject
    }

    fun analyze(view: WebView, callback: (JSONObject) -> Unit) {
        val pageUrl = view.url ?: ""
        view.evaluateJavascript(script()) { value ->
            val o = runCatching { parse(value) }.getOrNull()
            if (o != null) {
                val needs = o.optString("metaDescription").isBlank() || o.optString("canonical").isBlank() || o.optString("robots").isBlank()
                if (!needs || !pageUrl.startsWith("http")) {
                    callback(o)
                } else {
                    // WordPress caching/optimizer plugins can hide or move tags: read the raw HTML as a second source.
                    Thread {
                        try { fillFromHtml(o, fetchText(pageUrl)) } catch (e: Exception) { }
                        Handler(Looper.getMainLooper()).post { callback(o) }
                    }.start()
                }
            }
        }
    }

    private val metaTag = Regex("<meta\\b[^>]*>", RegexOption.IGNORE_CASE)
    private val attrRe = Regex("([a-zA-Z_:-]+)\\s*=\\s*(\"([^\"]*)\"|'([^']*)'|([^\\s>]+))")

    private fun decode(s: String): String =
        Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY).toString().trim()

    private fun metaMap(html: String): Map<String, String> {
        val head = html.substringBefore("</head>", html).take(400000)
        val m = LinkedHashMap<String, String>()
        for (t in metaTag.findAll(head)) {
            val attrs = HashMap<String, String>()
            for (a in attrRe.findAll(t.value)) {
                val v = a.groups[3]?.value ?: a.groups[4]?.value ?: a.groups[5]?.value ?: ""
                attrs[a.groupValues[1].lowercase(Locale.ROOT)] = v
            }
            val c = attrs["content"]?.trim()
            if (c.isNullOrEmpty()) continue
            for (k in listOf("name", "property", "itemprop", "http-equiv")) {
                val key = attrs[k]?.trim()?.lowercase(Locale.ROOT)
                if (!key.isNullOrEmpty() && !m.containsKey(key)) m[key] = decode(c)
            }
        }
        return m
    }

    private fun fillFromHtml(o: JSONObject, html: String) {
        val m = metaMap(html)
        if (o.optString("metaDescription").isBlank()) {
            for (k in listOf("description", "og:description", "twitter:description")) {
                val v = m[k]
                if (!v.isNullOrBlank()) {
                    o.put("metaDescription", v)
                    o.put("metaDescriptionLength", v.length)
                    o.put("metaDescriptionSource", k)
                    break
                }
            }
        }
        if (o.optString("robots").isBlank()) {
            val r = m["robots"]
            if (!r.isNullOrBlank()) o.put("robots", r)
        }
        if (o.optString("canonical").isBlank()) {
            val tag = Regex("<link\\b[^>]*rel\\s*=\\s*[\"']?[^\"'>]*canonical[^>]*>", RegexOption.IGNORE_CASE).find(html)
            if (tag != null) {
                val h = Regex("href\\s*=\\s*(\"([^\"]*)\"|'([^']*)')", RegexOption.IGNORE_CASE).find(tag.value)
                val u = h?.groups?.get(2)?.value ?: h?.groups?.get(3)?.value
                if (!u.isNullOrBlank()) o.put("canonical", u.trim())
            }
        }
    }

    fun fetchText(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 12000
        c.readTimeout = 20000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36")
        c.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
        c.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
        val cookie = android.webkit.CookieManager.getInstance().getCookie(url)
        if (!cookie.isNullOrBlank()) c.setRequestProperty("Cookie", cookie)
        val code = c.responseCode
        val stream = if (code in 200..399) c.inputStream else (c.errorStream ?: throw IllegalStateException("HTTP $code"))
        return stream.bufferedReader().use { it.readText() }
    }

    fun stripHtml(html: String): String = html.replace(Regex("(?is)<script.*?</script>|<style.*?</style>"), " ")
        .replace(Regex("(?s)<[^>]*>"), " ").replace(Regex("\\s+"), " ").trim()
        .take(6000)
}
