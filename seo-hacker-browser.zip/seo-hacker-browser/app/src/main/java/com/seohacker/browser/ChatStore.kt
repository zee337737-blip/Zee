package com.seohacker.browser

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** One chat message. files = names shown in the chat, images = saved image paths sent to the AI, docText = text extracted from files. */
data class Msg(
    val role: String,
    val content: String,
    val files: List<String> = emptyList(),
    val images: List<String> = emptyList(),
    val docText: String = ""
)

/** Saved AI chats (the "AI history"). Newest-updated chat first. */
object ChatStore {
    private fun sp() = App.ctx.getSharedPreferences("planning_chats", Context.MODE_PRIVATE)
    private fun arr() = JSONArray(sp().getString("chats", "[]"))

    fun newId() = System.currentTimeMillis().toString()

    fun list(): List<JSONObject> {
        val a = arr()
        return (0 until a.length()).map { a.getJSONObject(it) }
    }

    fun latestId(): String? = list().firstOrNull()?.optString("id")

    private fun strings(a: JSONArray?): List<String> {
        if (a == null) return emptyList()
        return (0 until a.length()).map { a.optString(it) }.filter { it.isNotBlank() }
    }

    fun load(id: String): List<Msg> {
        val o = list().firstOrNull { it.optString("id") == id } ?: return emptyList()
        val m = o.optJSONArray("m") ?: return emptyList()
        return (0 until m.length()).map {
            val x = m.getJSONObject(it)
            Msg(
                x.optString("r"), x.optString("c"), strings(x.optJSONArray("f")),
                strings(x.optJSONArray("i")).filter { p -> File(p).exists() }, x.optString("d")
            )
        }
    }

    fun save(id: String, msgs: List<Msg>) {
        if (msgs.isEmpty()) return
        val title = msgs.firstOrNull { it.role == "user" }?.content?.replace("\n", " ")?.take(48) ?: "Chat"
        val o = JSONObject().put("id", id).put("title", title).put("ts", System.currentTimeMillis())
        val m = JSONArray()
        msgs.forEach {
            val x = JSONObject().put("r", it.role).put("c", it.content)
            if (it.files.isNotEmpty()) x.put("f", JSONArray(it.files))
            if (it.images.isNotEmpty()) x.put("i", JSONArray(it.images))
            if (it.docText.isNotBlank()) x.put("d", it.docText.take(40000))
            m.put(x)
        }
        o.put("m", m)
        val out = JSONArray()
        out.put(o)
        var kept = 0
        for (x in list()) {
            if (x.optString("id") != id && kept < 49) {
                out.put(x)
                kept++
            }
        }
        sp().edit().putString("chats", out.toString()).apply()
    }

    private fun deleteFiles(prefix: String?) {
        try {
            val dir = File(App.ctx.filesDir, "chat_att")
            dir.listFiles()?.forEach { if (prefix == null || it.name.startsWith(prefix)) it.delete() }
        } catch (e: Exception) { }
    }

    fun delete(id: String) {
        val out = JSONArray()
        list().filter { it.optString("id") != id }.forEach { out.put(it) }
        sp().edit().putString("chats", out.toString()).apply()
        deleteFiles(id + "_")
    }

    fun clear() {
        sp().edit().remove("chats").apply()
        deleteFiles(null)
    }
}
