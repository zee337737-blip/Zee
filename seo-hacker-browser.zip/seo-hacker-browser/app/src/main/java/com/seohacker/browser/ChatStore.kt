package com.seohacker.browser

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Msg(val role: String, val content: String)

/** Saved AI chats (the "AI history"). Newest-updated chat first. */
object ChatStore {
    private fun sp() = App.ctx.getSharedPreferences("planning_chats", Context.MODE_PRIVATE)
    private fun arr() = JSONArray(sp().getString("chats", "[]"))

    fun newId() = System.currentTimeMillis().toString()

    fun list(): List<JSONObject> {
        val a = arr()
        return (0 until a.length()).map { a.getJSONObject(it) }
    }

    fun latestId(): String? = list().firstOrNull()?.optString("id")

    fun load(id: String): List<Msg> {
        val o = list().firstOrNull { it.optString("id") == id } ?: return emptyList()
        val m = o.optJSONArray("m") ?: return emptyList()
        return (0 until m.length()).map { val x = m.getJSONObject(it); Msg(x.optString("r"), x.optString("c")) }
    }

    fun save(id: String, msgs: List<Msg>) {
        if (msgs.isEmpty()) return
        val title = msgs.firstOrNull { it.role == "user" }?.content?.replace("\n", " ")?.take(48) ?: "Chat"
        val o = JSONObject().put("id", id).put("title", title).put("ts", System.currentTimeMillis())
        val m = JSONArray()
        msgs.forEach { m.put(JSONObject().put("r", it.role).put("c", it.content)) }
        o.put("m", m)
        val out = JSONArray()
        out.put(o)
        var kept = 0
        for (x in list()) {
            if (x.optString("id") != id && kept < 49) { out.put(x); kept++ }
        }
        sp().edit().putString("chats", out.toString()).apply()
    }

    fun delete(id: String) {
        val out = JSONArray()
        list().filter { it.optString("id") != id }.forEach { out.put(it) }
        sp().edit().putString("chats", out.toString()).apply()
    }

    fun clear() = sp().edit().remove("chats").apply()
}
