package com.seohacker.browser

import android.content.Context
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import java.security.MessageDigest
import java.util.UUID

/** Local password that protects Planning Hub, History and Downloads. */
object Vault {
    private const val UNLOCK_MS = 5 * 60 * 1000L
    private var unlockedAt = 0L

    private fun sp() = App.ctx.getSharedPreferences("vault", Context.MODE_PRIVATE)
    private fun hash(p: String, salt: String) =
        MessageDigest.getInstance("SHA-256").digest((salt + p).toByteArray()).joinToString("") { "%02x".format(it) }
    private fun hasPassword() = sp().contains("h")
    private fun check(p: String) = hash(p, sp().getString("s", "") ?: "") == sp().getString("h", "")
    fun lock() { unlockedAt = 0L }

    private fun field(a: AppCompatActivity, hint: String) = EditText(a).apply {
        this.hint = hint; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    }
    private fun wrap(a: AppCompatActivity, vararg v: EditText) = LinearLayout(a).apply {
        orientation = LinearLayout.VERTICAL
        val p = (20 * a.resources.displayMetrics.density).toInt()
        setPadding(p, 8, p, 0); v.forEach { addView(it) }
    }
    private fun toast(a: AppCompatActivity, m: String) = Toast.makeText(a, m, Toast.LENGTH_LONG).show()

    fun require(a: AppCompatActivity, onOk: () -> Unit) {
        if (hasPassword() && System.currentTimeMillis() - unlockedAt < UNLOCK_MS) { onOk(); return }
        if (hasPassword()) enter(a, onOk) else create(a, onOk)
    }

    fun change(a: AppCompatActivity) {
        if (hasPassword()) enter(a) { create(a) {} } else create(a) {}
    }

    private fun create(a: AppCompatActivity, onOk: () -> Unit) {
        val p1 = field(a, "New password (min 4 characters)"); val p2 = field(a, "Confirm password")
        AlertDialog.Builder(a).setTitle("Set password").setMessage("This password protects Planning Hub, History and Downloads.")
            .setView(wrap(a, p1, p2)).setCancelable(false)
            .setPositiveButton("Save") { _, _ ->
                val x = p1.text.toString()
                when {
                    x.length < 4 -> { toast(a, "Password must be at least 4 characters."); create(a, onOk) }
                    x != p2.text.toString() -> { toast(a, "Passwords do not match."); create(a, onOk) }
                    else -> {
                        val salt = UUID.randomUUID().toString()
                        sp().edit().putString("s", salt).putString("h", hash(x, salt)).apply()
                        unlockedAt = System.currentTimeMillis(); onOk()
                    }
                }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun enter(a: AppCompatActivity, onOk: () -> Unit) {
        val p = field(a, "Password")
        AlertDialog.Builder(a).setTitle("Enter password").setView(wrap(a, p)).setCancelable(false)
            .setPositiveButton("Unlock") { _, _ ->
                if (check(p.text.toString())) { unlockedAt = System.currentTimeMillis(); onOk() }
                else { toast(a, "Wrong password."); enter(a, onOk) }
            }
            .setNeutralButton("Forgot?") { _, _ -> forgot(a, onOk) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun forgot(a: AppCompatActivity, onOk: () -> Unit) {
        val user = FirebaseAuth.getInstance().currentUser
        val email = user?.email
        if (user == null || email == null) { toast(a, "Please log in again first."); return }
        val acc = field(a, "Account login password")
        AlertDialog.Builder(a).setTitle("Reset password").setMessage("Verify with your account password ($email).")
            .setView(wrap(a, acc))
            .setPositiveButton("Verify") { _, _ ->
                user.reauthenticate(EmailAuthProvider.getCredential(email, acc.text.toString())).addOnCompleteListener { t ->
                    if (t.isSuccessful) { sp().edit().clear().apply(); create(a, onOk) } else toast(a, "Account password is wrong.")
                }
            }.setNegativeButton("Cancel", null).show()
    }
}
