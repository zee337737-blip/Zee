package com.seohacker.browser

import android.content.Context
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import java.security.MessageDigest
import java.util.UUID

/** Local password that protects Planning Hub, History and Downloads. */
object Vault {
    private const val UNLOCK_MS = 5 * 60 * 1000L
    private var unlockedAt = 0L

    private fun sp() = App.ctx.getSharedPreferences("vault", Context.MODE_PRIVATE)
    private fun hash(p: String, salt: String) =
        MessageDigest.getInstance("SHA-256").digest((salt + p).toByteArray()).joinToString("") { "%02x".format(it) }
    private fun hasPassword() = sp().contains("h")
    private fun check(p: String) = hash(p, sp().getString("s", "") ?: "") == sp().getString("h", "")
    private fun store(p: String) {
        val salt = UUID.randomUUID().toString()
        sp().edit().putString("s", salt).putString("h", hash(p, salt)).apply()
        unlockedAt = System.currentTimeMillis()
    }
    fun lock() { unlockedAt = 0L }

    private fun toast(a: AppCompatActivity, m: String) = Toast.makeText(a, m, Toast.LENGTH_LONG).show()

    fun require(a: AppCompatActivity, onOk: () -> Unit) {
        if (hasPassword() && System.currentTimeMillis() - unlockedAt < UNLOCK_MS) { onOk(); return }
        if (hasPassword()) enter(a, onOk) else create(a, onOk)
    }

    /** Change password: the current password must be entered first. */
    fun change(a: AppCompatActivity) {
        if (!hasPassword()) { create(a) {}; return }
        val f = FormDialog(a, "Change password", "Enter your current password first, then choose a new one.")
        val old = f.password("Current password")
        val p1 = f.password("New password (min 4 characters)")
        val p2 = f.password("Confirm new password")
        f.leftLink("Forgot?") { f.dialog.dismiss(); forgot(a) {} }
        f.button("Cancel")
        f.button("Update", primary = true, dismiss = false) {
            val o = old.text.toString()
            val x = p1.text.toString()
            when {
                !check(o) -> f.fail("Current password is wrong.")
                x.length < 4 -> f.fail("New password must be at least 4 characters.")
                x == o -> f.fail("New password must be different from the current one.")
                x != p2.text.toString() -> f.fail("New passwords do not match.")
                else -> {
                    store(x)
                    f.dialog.dismiss()
                    Toast.makeText(a, "Password changed.", Toast.LENGTH_SHORT).show()
                }
            }
        }
        f.show()
    }

    private fun create(a: AppCompatActivity, onOk: () -> Unit) {
        val f = FormDialog(a, "Set password", "This password protects Planning Hub, History and Downloads.", cancelable = false)
        val p1 = f.password("New password (min 4 characters)")
        val p2 = f.password("Confirm password")
        f.button("Cancel")
        f.button("Save", primary = true, dismiss = false) {
            val x = p1.text.toString()
            when {
                x.length < 4 -> f.fail("Password must be at least 4 characters.")
                x != p2.text.toString() -> f.fail("Passwords do not match.")
                else -> { store(x); f.dialog.dismiss(); onOk() }
            }
        }
        f.show()
    }

    private fun enter(a: AppCompatActivity, onOk: () -> Unit) {
        val f = FormDialog(a, "Enter password", "Unlock to continue.", cancelable = false)
        val p = f.password("Password")
        f.leftLink("Forgot?") { f.dialog.dismiss(); forgot(a, onOk) }
        f.button("Cancel")
        f.button("Unlock", primary = true, dismiss = false) {
            if (check(p.text.toString())) {
                unlockedAt = System.currentTimeMillis(); f.dialog.dismiss(); onOk()
            } else {
                f.fail("Wrong password. Try again."); p.setText("")
            }
        }
        f.show()
    }

    private fun forgot(a: AppCompatActivity, onOk: () -> Unit) {
        val user = FirebaseAuth.getInstance().currentUser
        val email = user?.email
        if (user == null || email == null) { toast(a, "Please log in again first."); return }
        val f = FormDialog(a, "Reset password", "Verify with your account login password ($email).")
        val acc = f.password("Account login password")
        f.button("Cancel")
        f.button("Verify", primary = true, dismiss = false) {
            user.reauthenticate(EmailAuthProvider.getCredential(email, acc.text.toString())).addOnCompleteListener { t ->
                if (t.isSuccessful) {
                    f.dialog.dismiss(); sp().edit().clear().apply(); create(a, onOk)
                } else f.fail("Account password is wrong.")
            }
        }
        f.show()
    }
}
