package com.seohacker.browser

import android.content.Context
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** A slide-in side panel (like the SEO tools drawer). Tapping outside the panel closes it. */
class SidePanel(private val host: FrameLayout) {
    private val ctx: Context = host.context
    private val d = ctx.resources.displayMetrics.density
    private fun dp(n: Int) = (n * d).toInt()

    private val scrim = View(ctx).apply {
        setBackgroundColor(0x99000000.toInt()); visibility = View.GONE
        elevation = dp(20).toFloat(); isClickable = true
        setOnClickListener { hide() }
    }
    private val panel = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL; setBackgroundColor(ctx.getColor(R.color.panel))
        visibility = View.GONE; elevation = dp(24).toFloat(); isClickable = true
    }
    private val titleView = TextView(ctx).apply {
        setTextColor(ctx.getColor(R.color.text)); textSize = 18f; setTypeface(typeface, Typeface.BOLD)
    }
    private val body = FrameLayout(ctx)
    private val footer = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(6), dp(8), dp(8)) }

    init {
        host.addView(scrim, FrameLayout.LayoutParams(-1, -1))
        host.addView(panel, FrameLayout.LayoutParams(-1, -1, Gravity.END).apply { marginStart = dp(36) })
        val header = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(10), dp(8), dp(10)) }
        header.addView(titleView, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(TextView(ctx).apply {
            text = "\u2715"; textSize = 20f; setTextColor(ctx.getColor(R.color.secondary)); setPadding(dp(12), dp(6), dp(12), dp(6))
            setOnClickListener { hide() }
        })
        panel.addView(header, LinearLayout.LayoutParams(-1, -2))
        panel.addView(View(ctx).apply { setBackgroundColor(ctx.getColor(R.color.border)) }, LinearLayout.LayoutParams(-1, dp(1)))
        panel.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        panel.addView(footer, LinearLayout.LayoutParams(-1, -2))
    }

    val isShowing: Boolean get() = panel.visibility == View.VISIBLE

    fun show(title: String, content: View, actions: List<Pair<String, () -> Unit>> = emptyList()) {
        titleView.text = title
        body.removeAllViews(); body.addView(content, FrameLayout.LayoutParams(-1, -1))
        footer.removeAllViews()
        actions.chunked(2).forEach { row ->
            val r = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            row.forEach { (label, act) ->
                r.addView(Button(ctx).apply {
                    text = label; isAllCaps = false; textSize = 13f; setTextColor(ctx.getColor(R.color.text))
                    setBackgroundResource(R.drawable.bg_card); minHeight = 0; minimumHeight = 0
                    setOnClickListener { act() }
                }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { setMargins(dp(4), dp(3), dp(4), dp(3)) })
            }
            if (row.size == 1) r.addView(View(ctx), LinearLayout.LayoutParams(0, dp(44), 1f))
            footer.addView(r, LinearLayout.LayoutParams(-1, -2))
        }
        footer.visibility = if (actions.isEmpty()) View.GONE else View.VISIBLE
        val w = (if (host.width > 0) host.width else ctx.resources.displayMetrics.widthPixels).toFloat()
        scrim.visibility = View.VISIBLE; panel.visibility = View.VISIBLE
        panel.animate().cancel(); panel.translationX = w
        panel.animate().translationX(0f).setDuration(200).start()
    }

    /** A list of tappable boxes, for menus. */
    fun showMenu(title: String, items: List<Pair<String, () -> Unit>>) {
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(10), dp(10), dp(10)) }
        items.forEach { (label, act) ->
            col.addView(TextView(ctx).apply {
                text = label; textSize = 16f; setTextColor(ctx.getColor(R.color.text))
                setBackgroundResource(R.drawable.bg_card); setPadding(dp(16), dp(14), dp(16), dp(14))
                setOnClickListener { hide(); act() }
            }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
        show(title, ScrollView(ctx).apply { addView(col) })
    }

    fun hide() {
        if (!isShowing) return
        (ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(panel.windowToken, 0)
        val w = (if (host.width > 0) host.width else ctx.resources.displayMetrics.widthPixels).toFloat()
        scrim.visibility = View.GONE
        panel.animate().cancel()
        panel.animate().translationX(w).setDuration(160).withEndAction { panel.visibility = View.GONE }.start()
    }
}
