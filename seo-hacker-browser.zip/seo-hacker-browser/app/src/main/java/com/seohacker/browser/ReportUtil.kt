package com.seohacker.browser

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ReportUtil {
    fun saveBytes(context: Context, filename: String, mime: String, content: ByteArray): Uri? {
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, filename)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("MediaStore insert returned null")
                context.contentResolver.openOutputStream(uri)?.use { it.write(content) }
                    ?: throw IllegalStateException("Unable to open output stream")
                Toast.makeText(context, "Saved to Downloads: $filename", Toast.LENGTH_SHORT).show()
                uri
            } else {
                @Suppress("DEPRECATION")
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (!dir.exists() && !dir.mkdirs()) throw IllegalStateException("Cannot create Downloads directory")
                val file = File(dir, filename)
                FileOutputStream(file).use { it.write(content) }
                Toast.makeText(context, "Saved to Downloads: $filename", Toast.LENGTH_SHORT).show()
                Uri.fromFile(file)
            }
        } catch (e: Exception) {
            Toast.makeText(context, "Save failed: ${e.message}", Toast.LENGTH_LONG).show()
            null
        }
    }

    fun save(context: Context, filename: String, mime: String, content: String): Uri? =
        saveBytes(context, filename, mime, content.toByteArray())

    /** Builds the spreadsheet-style PDF and saves it into Downloads. */
    fun pdf(context: Context, name: String, doc: PdfDoc): Uri? {
        val bytes = try {
            PdfReport.build(doc)
        } catch (e: Exception) {
            Toast.makeText(context, "PDF failed: ${e.message}", Toast.LENGTH_LONG).show()
            return null
        }
        val clean = name.replace(Regex("[^A-Za-z0-9_-]+"), "_").trim('_').ifBlank { "report" }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
        return saveBytes(context, "${clean}_$stamp.pdf", "application/pdf", bytes)
    }

    fun txt(context: Context, title: String, text: String) = save(context, "$title.txt", "text/plain", text)
}
