package com.seohacker.browser

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

object ReportUtil {
    fun save(context: Context, filename: String, mime: String, content: String): Uri? {
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, filename)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("MediaStore insert returned null")
                context.contentResolver.openOutputStream(uri)?.use { it.write(content.toByteArray()) }
                    ?: throw IllegalStateException("Unable to open output stream")
                Toast.makeText(context, "Saved to Downloads: $filename", Toast.LENGTH_SHORT).show()
                uri
            } else {
                @Suppress("DEPRECATION")
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (!dir.exists() && !dir.mkdirs()) throw IllegalStateException("Cannot create Downloads directory")
                val file = File(dir, filename)
                FileOutputStream(file).use { it.write(content.toByteArray()) }
                Toast.makeText(context, "Saved to Downloads: $filename", Toast.LENGTH_SHORT).show()
                Uri.fromFile(file)
            }
        } catch (e: Exception) {
            Toast.makeText(context, "Save failed: ${e.message}", Toast.LENGTH_LONG).show()
            null
        }
    }
    fun csv(context: Context, title: String, fields: Map<String, String>) {
        val csv = buildString {
            append("field,value\n")
            fields.forEach { append(csvCell(it.key)).append(',').append(csvCell(it.value)).append('\n') }
        }
        save(context, "$title.csv", "text/csv", csv)
    }
    fun txt(context: Context, title: String, text: String) = save(context, "$title.txt", "text/plain", text)
    private fun csvCell(s: String) = "\"" + s.replace("\"", "\"\"").replace("\r", " ").replace("\n", " ") + "\""
}
