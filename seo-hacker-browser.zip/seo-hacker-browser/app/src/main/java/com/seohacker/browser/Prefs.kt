package com.seohacker.browser

import android.content.Context

object Prefs {
    private const val NAME = "seo_browser"
    private const val KEY_ENGINE = "search_engine"
    private const val KEY_COHERE = "cohere_key"
    private const val KEY_MODEL = "cohere_model"
    private const val KEY_VISION = "cohere_vision_model"
    private const val KEY_DESKTOP = "desktop_mode"
    private const val KEY_ADS = "ad_blocker"
    private const val KEY_TABS = "tabs"
    private const val KEY_URLS = "tab_urls"

    private fun p(c: Context) = c.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    var searchEngine: String
        get() = p(App.ctx).getString(KEY_ENGINE, "Google") ?: "Google"
        set(v) = p(App.ctx).edit().putString(KEY_ENGINE, v).apply()

    var cohereKey: String
        get() = p(App.ctx).getString(KEY_COHERE, "") ?: ""
        set(v) = p(App.ctx).edit().putString(KEY_COHERE, v).apply()

    var cohereModel: String
        get() = p(App.ctx).getString(KEY_MODEL, "command-r-plus-08-2024") ?: "command-r-plus-08-2024"
        set(v) = p(App.ctx).edit().putString(KEY_MODEL, v).apply()

    var cohereVisionModel: String
        get() = p(App.ctx).getString(KEY_VISION, "command-a-vision-07-2025") ?: "command-a-vision-07-2025"
        set(v) = p(App.ctx).edit().putString(KEY_VISION, v).apply()

    var desktopMode: Boolean
        get() = p(App.ctx).getBoolean(KEY_DESKTOP, false)
        set(v) = p(App.ctx).edit().putBoolean(KEY_DESKTOP, v).apply()

    var adBlocker: Boolean
        get() = p(App.ctx).getBoolean(KEY_ADS, true)
        set(v) = p(App.ctx).edit().putBoolean(KEY_ADS, v).apply()

    var proxyOn: Boolean
        get() = p(App.ctx).getBoolean("proxy_on", false)
        set(v) = p(App.ctx).edit().putBoolean("proxy_on", v).apply()
    var proxyHost: String
        get() = p(App.ctx).getString("proxy_host", "") ?: ""
        set(v) = p(App.ctx).edit().putString("proxy_host", v).apply()
    var proxyPort: String
        get() = p(App.ctx).getString("proxy_port", "8080") ?: "8080"
        set(v) = p(App.ctx).edit().putString("proxy_port", v).apply()
    var proxyType: String
        get() = p(App.ctx).getString("proxy_type", "HTTP") ?: "HTTP"
        set(v) = p(App.ctx).edit().putString("proxy_type", v).apply()

    fun saveTabs(urls: List<String>) {
        p(App.ctx).edit().putInt(KEY_TABS, urls.size).apply {
            urls.forEachIndexed { i, u -> putString("$KEY_URLS$i", u) }
        }.apply()
    }

    fun loadTabs(): MutableList<String> {
        val sp = p(App.ctx)
        val n = sp.getInt(KEY_TABS, 0)
        return (0 until n).mapNotNull { sp.getString("$KEY_URLS$it", null) }.toMutableList()
    }
}
