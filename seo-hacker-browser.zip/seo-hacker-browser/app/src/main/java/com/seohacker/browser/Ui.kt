package com.seohacker.browser

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Typeface
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** Card-style list rows (title + small subtitle) used by every list in the app. */
class RowAdapter(private val ctx: Context, private val items: List<Pair<String, String>>) : BaseAdapter() {
    override fun getCount() = items.size
    override fun getItem(position: Int) = items[position]
    override fun getItemId(position: Int) = position.toLong()
    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val v = convertView ?: LayoutInflater.from(ctx).inflate(R.layout.item_row, parent, false)
        v.findViewById<TextView>(R.id.rowTitle).text = items[position].first
        val sub = v.findViewById<TextView>(R.id.rowSub)
        sub.text = items[position].second
        sub.visibility = if (items[position].second.isBlank()) View.GONE else View.VISIBLE
        return v
    }
}

/** Tiny markdown renderer for AI replies: headings, bullets and **bold**. */
object Md {
    private val bold = Regex("\\*\\*(.+?)\\*\\*")

    fun render(src: String): CharSequence {
        val sb = SpannableStringBuilder()
        src.lines().forEach { raw ->
            var line = raw.trimEnd()
            var all = false
            val t = line.trimStart()
            if (t.startsWith("#")) {
                line = t.trimStart('#').trim(); all = true
            } else if (t.startsWith("- ") || t.startsWith("* ")) {
                line = "\u2022 " + t.drop(2)
            }
            val start = sb.length
            var last = 0
            for (m in bold.findAll(line)) {
                sb.append(line.substring(last, m.range.first))
                val s = sb.length
                sb.append(m.groupValues[1])
                if (sb.length > s) sb.setSpan(StyleSpan(Typeface.BOLD), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                last = m.range.last + 1
            }
            sb.append(line.substring(last))
            if (all && sb.length > start) sb.setSpan(StyleSpan(Typeface.BOLD), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.append('\n')
        }
        if (sb.isNotEmpty()) sb.delete(sb.length - 1, sb.length)
        return sb
    }
}

/** A rounded dark dialog with optional password fields (with Show/Hide), inline errors and buttons. */
class FormDialog(private val a: Activity, title: String, message: String? = null, cancelable: Boolean = true) {
    private val d = a.resources.displayMetrics.density
    private fun dp(n: Int) = (n * d).toInt()
    val dialog = Dialog(a)
    private val box = LinearLayout(a)
    private val error = TextView(a)
    private val buttons = LinearLayout(a)

    init {
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(cancelable)
        box.orientation = LinearLayout.VERTICAL
        box.setBackgroundResource(R.drawable.bg_dialog)
        box.setPadding(dp(20), dp(20), dp(20), dp(12))
        box.addView(TextView(a).apply {
            text = title; textSize = 19f; setTextColor(a.getColor(R.color.text)); setTypeface(typeface, Typeface.BOLD)
        })
        if (!message.isNullOrBlank()) box.addView(TextView(a).apply {
            text = message; textSize = 13.5f; setTextColor(a.getColor(R.color.secondary)); setPadding(0, dp(6), 0, dp(4))
        })
        error.textSize = 13f
        error.setTextColor(a.getColor(R.color.error))
        error.visibility = View.GONE
        error.setPadding(0, dp(10), 0, 0)
        buttons.orientation = LinearLayout.HORIZONTAL
        buttons.gravity = Gravity.END or Gravity.CENTER_VERTICAL
    }

    fun password(hint: String): EditText {
        val row = FrameLayout(a)
        val et = EditText(a)
        et.hint = hint
        et.setHintTextColor(a.getColor(R.color.secondary))
        et.setTextColor(a.getColor(R.color.text))
        et.textSize = 15f
        et.setBackgroundResource(R.drawable.bg_input)
        et.setSingleLine(true)
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        et.setPadding(dp(14), 0, dp(66), 0)
        var shown = false
        val eye = TextView(a)
        eye.text = "Show"
        eye.textSize = 12.5f
        eye.setTextColor(a.getColor(R.color.accent))
        eye.gravity = Gravity.CENTER
        eye.setPadding(dp(12), 0, dp(14), 0)
        eye.setOnClickListener {
            shown = !shown
            et.inputType = InputType.TYPE_CLASS_TEXT or
                (if (shown) InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD else InputType.TYPE_TEXT_VARIATION_PASSWORD)
            et.setSelection(et.text.length)
            eye.text = if (shown) "Hide" else "Show"
        }
        row.addView(et, FrameLayout.LayoutParams(-1, dp(52)))
        row.addView(eye, FrameLayout.LayoutParams(-2, dp(52), Gravity.END))
        box.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        return et
    }

    fun custom(v: View, height: Int = -2) {
        box.addView(v, LinearLayout.LayoutParams(-1, height).apply { topMargin = dp(12) })
    }

    fun fail(msg: String) {
        error.text = msg
        error.visibility = if (msg.isBlank()) View.GONE else View.VISIBLE
    }

    /** A text link on the far left of the button row (e.g. "Forgot?"). Does not close the dialog by itself. */
    fun leftLink(label: String, onClick: () -> Unit) {
        val tv = TextView(a)
        tv.text = label
        tv.textSize = 13.5f
        tv.setTextColor(a.getColor(R.color.accent))
        tv.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        tv.setPadding(0, dp(10), dp(10), dp(10))
        tv.setOnClickListener { onClick() }
        buttons.addView(tv, 0, LinearLayout.LayoutParams(0, -2, 1f))
    }

    fun button(label: String, primary: Boolean = false, dismiss: Boolean = true, onClick: () -> Unit = {}) {
        val tv = TextView(a)
        tv.text = label
        tv.textSize = 14.5f
        tv.gravity = Gravity.CENTER
        tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.setTextColor(a.getColor(if (primary) R.color.white else R.color.secondary))
        if (primary) tv.setBackgroundResource(R.drawable.bg_button)
        tv.setPadding(dp(18), dp(10), dp(18), dp(10))
        tv.setOnClickListener { if (dismiss) dialog.dismiss(); onClick() }
        buttons.addView(tv, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })
    }

    fun show(): Dialog {
        box.addView(error)
        if (buttons.childCount > 0) box.addView(buttons, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        dialog.setContentView(box)
        dialog.show()
        dialog.window?.let { w ->
            w.setBackgroundDrawableResource(android.R.color.transparent)
            val width = minOf((a.resources.displayMetrics.widthPixels * 0.92f).toInt(), dp(420))
            w.setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT)
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        }
        return dialog
    }
}
