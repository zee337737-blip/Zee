package com.seohacker.browser

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Bookmark(val title: String, val url: String)

object BookmarkStore {
    private const val KEY = "bookmarks"
    private fun sp(c: Context) = c.getSharedPreferences("seo_browser", Context.MODE_PRIVATE)
    fun all(c: Context): MutableList<Bookmark> {
        val a = JSONArray(sp(c).getString(KEY, "[]"))
        return MutableList(a.length()) { i ->
            val o = a.getJSONObject(i); Bookmark(o.optString("title"), o.optString("url"))
        }
    }
    fun add(c: Context, title: String, url: String) {
        val list = all(c)
        if (list.none { it.url == url }) list.add(0, Bookmark(title, url))
        save(c, list)
    }
    fun remove(c: Context, url: String) { save(c, all(c).filterNot { it.url == url }) }
    private fun save(c: Context, list: List<Bookmark>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("title", it.title).put("url", it.url)) }
        sp(c).edit().putString(KEY, a.toString()).apply()
    }
}
