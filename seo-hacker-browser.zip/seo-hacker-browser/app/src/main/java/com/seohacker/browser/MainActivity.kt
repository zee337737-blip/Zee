package com.seohacker.browser

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.*
import android.view.*
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.firebase.auth.FirebaseAuth
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

data class BrowserTab(var title:String,var url:String,var view:WebView)

class MainActivity : AppCompatActivity() {
    private val tabs=mutableListOf<BrowserTab>()
    private var current=0
    private lateinit var address:EditText
    private lateinit var progress:ProgressBar
    private lateinit var suggestion:ListView
    private lateinit var webFrame:FrameLayout
    private lateinit var left:View
    private lateinit var right:View
    private lateinit var panel:SidePanel
    private lateinit var drawerScrim:View
    private lateinit var bookmarkList:ListView
    private lateinit var grabber:VideoGrabber
    private var fab:View?=null
    private var fsFab:View?=null
    private val exec=Executors.newCachedThreadPool()
    private var fileCallback:ValueCallback<Array<Uri>>?=null
    private var fullscreen:View?=null
    private var fullscreenCb:WebChromeClient.CustomViewCallback?=null
    private val PICK=71
    private val permission=72

    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        if(FirebaseAuth.getInstance().currentUser==null){startActivity(Intent(this,LoginActivity::class.java));finish();return}
        setContentView(R.layout.activity_main)
        AdBlocker.init(this)
        bindUi()
        requestInitialPermissions()
        val restored=Prefs.loadTabs()
        if(restored.isEmpty())newTab("file:///android_asset/index.html") else restored.take(8).forEach{newTab(it)}
        if(intent?.data!=null)navigate(intent.data.toString()) else showTab(0)
    }

    private fun bindUi(){
        address=findViewById(R.id.addressBar);progress=findViewById(R.id.pageProgress);suggestion=findViewById(R.id.suggestionList)
        panel=SidePanel(findViewById(R.id.contentFrame));drawerScrim=findViewById(R.id.drawerScrim);drawerScrim.setOnClickListener{closeDrawers()};left=findViewById(R.id.leftDrawer);right=findViewById(R.id.rightDrawer);bookmarkList=findViewById(R.id.bookmarkList)
        findViewById<ImageButton>(R.id.backButton).setOnClickListener{goBackOrHome()}
        findViewById<ImageButton>(R.id.forwardButton).setOnClickListener{tabs.getOrNull(current)?.view?.let{if(it.canGoForward())it.goForward()}}
        findViewById<ImageButton>(R.id.reloadButton).setOnClickListener{tabs.getOrNull(current)?.view?.reload()}
        findViewById<Button>(R.id.goButton).setOnClickListener{go()}
        findViewById<ImageButton>(R.id.bookmarkButton).setOnClickListener{bookmark()}
        findViewById<ImageButton>(R.id.tabsButton).setOnClickListener{tabsDialog()}
        findViewById<ImageButton>(R.id.menuButton).setOnClickListener{menu()}
        val ph=findViewById<View>(R.id.webView);webFrame=ph.parent as FrameLayout;webFrame.removeView(ph)
        address.setSelectAllOnFocus(true)
        address.setOnFocusChangeListener{_,f->setAddressMode(f);if(f){address.selectAll();suggest("")}else suggestion.visibility=View.GONE}
        address.setOnEditorActionListener{_,action,event->
            val enter=event?.keyCode==android.view.KeyEvent.KEYCODE_ENTER&&event.action==android.view.KeyEvent.ACTION_DOWN
            if(action==android.view.inputmethod.EditorInfo.IME_ACTION_GO||action==android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH||
                action==android.view.inputmethod.EditorInfo.IME_ACTION_DONE||action==android.view.inputmethod.EditorInfo.IME_ACTION_UNSPECIFIED||enter){go();true}else false}
        address.addTextChangedListener(object:android.text.TextWatcher{
            override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){}
            override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){if(address.hasFocus())suggest(s?.toString()?:"") else suggestion.visibility=View.GONE}
            override fun afterTextChanged(e:android.text.Editable?){}
        })
        grabber=VideoGrabber(this,{tabs.getOrNull(current)?.view}){updateFab()}
        fab=findViewById(R.id.dlFab);fab?.setOnClickListener{grabber.open(null,null)}
        listToolClicks()
        refreshBookmarks()
    }

    private fun listToolClicks(){
        findViewById<Button>(R.id.toolAnalyze).setOnClickListener{closeDrawers();analyze()}
        findViewById<Button>(R.id.toolSource).setOnClickListener{closeDrawers();viewSource()}
        findViewById<Button>(R.id.toolRedirects).setOnClickListener{closeDrawers();redirectChain()}
        findViewById<Button>(R.id.toolHeaders).setOnClickListener{closeDrawers();headers()}
        findViewById<Button>(R.id.toolRobots).setOnClickListener{closeDrawers();textTool("robots.txt")}
        findViewById<Button>(R.id.toolSitemap).setOnClickListener{closeDrawers();textTool("sitemap.xml")}
        findViewById<Button>(R.id.toolLoad).setOnClickListener{closeDrawers();loadInfo()}
        findViewById<Button>(R.id.toolUA).setOnClickListener{closeDrawers();uaDialog()}
        findViewById<Button>(R.id.toolBroken).setOnClickListener{closeDrawers();brokenLinks()}
        findViewById<Button>(R.id.toolVideos).setOnClickListener{closeDrawers();grabber.open(null,null)}
        findViewById<Button>(R.id.toolVideoDl).setOnClickListener{closeDrawers();showVideoDownloads()}
        findViewById<Button>(R.id.toolPlanning).setOnClickListener{closeDrawers();Vault.require(this){startActivity(Intent(this,PlanningHubActivity::class.java))}}
        findViewById<Button>(R.id.toolHistory).setOnClickListener{closeDrawers();Vault.require(this){startActivity(Intent(this,HistoryActivity::class.java))}}
        findViewById<Button>(R.id.toolDownloads).setOnClickListener{closeDrawers();Vault.require(this){startActivity(Intent(this,DownloadsActivity::class.java))}}
    }

    private fun requestInitialPermissions(){
        val req=mutableListOf<String>()
        if(Build.VERSION.SDK_INT>=33&&ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)req.add(Manifest.permission.POST_NOTIFICATIONS)
        if(Build.VERSION.SDK_INT<=28&&ContextCompat.checkSelfPermission(this,Manifest.permission.WRITE_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED)req.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if(req.isNotEmpty())ActivityCompat.requestPermissions(this,req.toTypedArray(),permission)
    }

    private fun newTab(url:String){
        val w=WebView(this)
        configure(w)
        tabs.add(BrowserTab("New tab",url,w))
        w.loadUrl(url)
        current=tabs.lastIndex
        attachWebView(w)
    }
    private fun attachWebView(w:WebView){
        tabs.forEach{(it.view.parent as? ViewGroup)?.removeView(it.view)}
        (w.parent as? ViewGroup)?.removeView(w)
        webFrame.addView(w,0,ViewGroup.LayoutParams(-1,-1))
    }
    private val HOME="file:///android_asset/index.html"
    private var clearHistoryFor:WebView?=null
    private fun isHome(u:String?)=u!=null&&u.startsWith("file:///android_asset")
    // Back: normal history first; if the tab was restored (no history) and isn't on the home page, go to home page.
    private fun goBackOrHome():Boolean{
        val v=tabs.getOrNull(current)?.view?:return false
        if(v.canGoBack()){v.goBack();return true}
        if(!isHome(v.url)){clearHistoryFor=v;v.loadUrl(HOME);return true}
        return false
    }
    private fun shownUrl(u:String?)=if(u==null||u.startsWith("file:///android_asset"))"" else u
    @Suppress("DEPRECATION")
    private fun lightPages(w:WebView){
        if(Build.VERSION.SDK_INT>=33)w.settings.isAlgorithmicDarkeningAllowed=false
        else if(Build.VERSION.SDK_INT>=29)w.settings.forceDark=WebSettings.FORCE_DARK_OFF
    }
    private var immersive=false
    private fun toggleImmersive(){immersive=!immersive;Immersive.set(this,immersive)}
    private fun configure(w:WebView){
        w.setBackgroundColor(getColor(R.color.bg))
        w.settings.javaScriptEnabled=true;w.settings.domStorageEnabled=true;w.settings.databaseEnabled=true
        w.settings.allowFileAccess=true;w.settings.allowContentAccess=true
        w.settings.mixedContentMode=WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        w.settings.setSupportMultipleWindows(false);w.settings.javaScriptCanOpenWindowsAutomatically=true
        w.settings.userAgentString=ua()
        w.settings.useWideViewPort=true;w.settings.loadWithOverviewMode=true
        w.settings.setSupportZoom(true);w.settings.builtInZoomControls=true;w.settings.displayZoomControls=false
        lightPages(w)
        w.importantForAutofill=View.IMPORTANT_FOR_AUTOFILL_YES
        CookieManager.getInstance().setAcceptCookie(true);CookieManager.getInstance().setAcceptThirdPartyCookies(w,true)
        w.addJavascriptInterface(DownloadBridge(this),"AndroidDownload")
        w.addJavascriptInterface(StartBridge(),"StartBridge")
        w.addJavascriptInterface(VideoBridge(),"VideoBridge")
        w.webViewClient=object:WebViewClient(){
            override fun shouldOverrideUrlLoading(v:WebView,r:WebResourceRequest):Boolean{
                val u=r.url.toString()
                if(u.startsWith("http://")||u.startsWith("https://"))return false
                if(u.startsWith("intent:")||u.startsWith("tel:")||u.startsWith("mailto:"))runCatching{startActivity(Intent.parseUri(u,Intent.URI_INTENT_SCHEME))}.onFailure{Toast.makeText(this@MainActivity,"Cannot open external link: ${it.message}",Toast.LENGTH_LONG).show()}
                return true
            }
            override fun shouldInterceptRequest(v:WebView,r:WebResourceRequest):WebResourceResponse?{
                val u=r.url.toString()
                grabber.onRequest(v,r)
                return AdBlocker.intercept(r)
            }
            override fun onPageStarted(v:WebView,u:String,b:Bitmap?){
                v.tag=u;grabber.reset(v)
                if(v===tabs.getOrNull(current)?.view){address.setText(shownUrl(u));progress.visibility=View.VISIBLE}
            }
            override fun onPageFinished(v:WebView,u:String){
                val t=tabs.firstOrNull{it.view===v}
                if(v===clearHistoryFor&&isHome(u)){v.clearHistory();clearHistoryFor=null}
                if(t!=null){t.url=u;t.title=v.title?:u}
                if(t!=null&&t===tabs.getOrNull(current)){address.setText(shownUrl(u));progress.visibility=View.GONE}
                if(!u.startsWith("file:")){HistoryStore.add(this@MainActivity,v.title?:u,u)}
                CookieManager.getInstance().flush()
                if(AdBlocker.enabled)v.evaluateJavascript(AdBlocker.cssJs(),null)
                if(!u.startsWith("file:"))v.evaluateJavascript(VIDEO_JS,null)
                Prefs.saveTabs(tabs.map{it.url})
            }
        }
        w.webChromeClient=object:WebChromeClient(){
            override fun onProgressChanged(v:WebView,p:Int){progress.progress=p;progress.visibility=if(p<100)View.VISIBLE else View.GONE}
            override fun onShowFileChooser(v:WebView,cb:ValueCallback<Array<Uri>>,params:FileChooserParams):Boolean{
                fileCallback?.onReceiveValue(null);fileCallback=cb
                val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{
                    addCategory(Intent.CATEGORY_OPENABLE);type="*/*"
                    if(params.mode==FileChooserParams.MODE_OPEN_MULTIPLE)putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true)
                    val types=params.acceptTypes.flatMap{it.split(",")}.map{it.trim()}.filter{it.contains("/")}
                    if(types.isNotEmpty())putExtra(Intent.EXTRA_MIME_TYPES,types.toTypedArray())
                }
                return try{startActivityForResult(i,PICK);true}catch(e:Exception){fileCallback?.onReceiveValue(null);fileCallback=null;false}
            }
            override fun onPermissionRequest(r:PermissionRequest){
                val needed=r.resources.mapNotNull{
                    when(it){PermissionRequest.RESOURCE_VIDEO_CAPTURE->Manifest.permission.CAMERA
                        PermissionRequest.RESOURCE_AUDIO_CAPTURE->Manifest.permission.RECORD_AUDIO else->null}
                }.distinct()
                if(needed.all{ContextCompat.checkSelfPermission(this@MainActivity,it)==PackageManager.PERMISSION_GRANTED})r.grant(r.resources)
                else {pendingWebPermission=r;ActivityCompat.requestPermissions(this@MainActivity,needed.toTypedArray(),permission)}
            }
            override fun onGeolocationPermissionsShowPrompt(origin:String,cb:GeolocationPermissions.Callback){
                geoCallback=cb;geoOrigin=origin
                if(ContextCompat.checkSelfPermission(this@MainActivity,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED)cb.invoke(origin,true,false)
                else ActivityCompat.requestPermissions(this@MainActivity,arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),permission)
            }
            override fun onShowCustomView(view:View,cb:CustomViewCallback){fullscreen=view;fullscreenCb=cb;addContentView(view,ViewGroup.LayoutParams(-1,-1));showFsFab();updateFab()}
            override fun onHideCustomView(){fullscreen?.let{(it.parent as? ViewGroup)?.removeView(it)};fullscreen=null;fullscreenCb?.onCustomViewHidden();fullscreenCb=null;hideFsFab();updateFab()}
        }
        w.setDownloadListener{url,agent,cd,mime,_->DownloadHelper.handle(this,w,url,agent,cd,mime)}
    }
    private var pendingWebPermission:PermissionRequest?=null
    private var geoCallback:GeolocationPermissions.Callback?=null
    private var geoOrigin:String?=null

    override fun onRequestPermissionsResult(r:Int,p:Array<out String>,g:IntArray){
        super.onRequestPermissionsResult(r,p,g)
        if(r==permission){
            pendingWebPermission?.let{req->if(g.any{it==PackageManager.PERMISSION_GRANTED})req.grant(req.resources) else req.deny();pendingWebPermission=null}
            geoCallback?.let{cb->val ok=ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;cb.invoke(geoOrigin,ok,false);geoCallback=null}
        }
    }

    private fun go(){navigate(address.text.toString().trim());leaveAddress()}
    private fun navigate(raw:String){
        val q=raw.trim();if(q.isBlank())return
        val url=if(q.startsWith("http://")||q.startsWith("https://"))q else if(q.contains(".")&&!q.contains(" "))"https://$q" else{
            val base=when(Prefs.searchEngine){"Bing"->"https://www.bing.com/search?q=";"DuckDuckGo"->"https://duckduckgo.com/?q=";else->"https://www.google.com/search?q="}
            base+URLEncoder.encode(q,"UTF-8")
        }
        tabs.getOrNull(current)?.view?.loadUrl(url)
    }
    private fun showTab(i:Int){if(i !in tabs.indices)return;current=i;attachWebView(tabs[i].view);address.setText(tabs[i].view.url?:tabs[i].url);updateFab()}
    private fun tabsDialog(){
        val rows=tabs.mapIndexed{i,t->"${i+1}. ${t.title.ifBlank{"New tab"}}"}
        val items=(rows+listOf("New tab")).toTypedArray()
        androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Tabs").setItems(items){_,which->
            if(which==tabs.size)newTab("file:///android_asset/index.html") else showTab(which)
        }.setNegativeButton("Close current"){_,_->closeTab(current)}.setNeutralButton("Close",null).show()
    }
    private fun closeTab(i:Int){if(tabs.size<=1){finish();return};val gone=tabs.removeAt(i);(gone.view.parent as? ViewGroup)?.removeView(gone.view);gone.view.destroy();current=minOf(current,tabs.lastIndex);showTab(current);Prefs.saveTabs(tabs.map{it.url})}
    private fun bookmark(){val t=tabs.getOrNull(current)?:return;BookmarkStore.add(this,t.title,t.url);refreshBookmarks();Toast.makeText(this,"Bookmark saved",Toast.LENGTH_SHORT).show()}
    private fun refreshBookmarks(){
        val b=BookmarkStore.all(this);bookmarkList.adapter=RowAdapter(this,b.map{it.title.ifBlank{it.url} to it.url})
        bookmarkList.setOnItemClickListener{_,_,p,_->showTab(current);navigate(b[p].url);closeDrawers()}
    }
    private fun menu(){
        panel.showMenu("Menu",listOf(
            "SEO tools" to {showDrawer(left)},
            "Bookmarks" to {showDrawer(right)},
            "Video downloads" to {showVideoDownloads()},
            "Find in page" to {findInPage()},
            ("Desktop mode: "+(if(Prefs.desktopMode)"ON" else "OFF")) to {Prefs.desktopMode=!Prefs.desktopMode;tabs.getOrNull(current)?.view?.settings?.userAgentString=ua();tabs.getOrNull(current)?.view?.reload()},
            ("Ad blocker: "+(if(Prefs.adBlocker)"ON" else "OFF")) to {Prefs.adBlocker=!Prefs.adBlocker;AdBlocker.enabled=Prefs.adBlocker;Toast.makeText(this,"Ad blocker ${if(Prefs.adBlocker)"on" else "off"} - blocked ${AdBlocker.count}",Toast.LENGTH_SHORT).show()},
            ("Full screen: "+(if(immersive)"ON" else "OFF")) to {toggleImmersive()},
            "Open in Chrome Custom Tab" to {tabs.getOrNull(current)?.view?.url?.let{runCatching{CustomTabsIntent.Builder().build().launchUrl(this,Uri.parse(it))}}},
            "Clear browsing data" to {clearData()},
            "Settings" to {searchSettings()},
            "Change password" to {Vault.change(this)},
            "Log out" to {Vault.lock();FirebaseAuth.getInstance().signOut();startActivity(Intent(this,LoginActivity::class.java));finish()}))
    }
    private fun showDrawer(d:View){
        closeDrawers(false)
        drawerScrim.visibility=View.VISIBLE;d.animate().cancel();d.visibility=View.VISIBLE
        d.translationX=(if(d===left)-310 else 320)*resources.displayMetrics.density
        d.animate().translationX(0f).setDuration(200).start()
    }
    private fun closeDrawers(animate:Boolean=true){
        drawerScrim.visibility=View.GONE
        listOf(left,right).forEach{d->
            if(d.visibility==View.VISIBLE){
                d.animate().cancel()
                if(!animate){d.visibility=View.GONE;d.translationX=0f}
                else{val off=if(d===left)-d.width.toFloat() else d.width.toFloat();d.animate().translationX(off).setDuration(160).withEndAction{d.visibility=View.GONE;d.translationX=0f}.start()}
            }
        }
    }
    private fun findInPage(){
        val e=EditText(this);e.hint="Find in page"
        androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Find in page").setView(e).setPositiveButton("Find"){_,_->tabs.getOrNull(current)?.view?.findAllAsync(e.text.toString())}.show()
    }
    private fun clearData(){
        androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Clear browsing data").setMessage("Clear cookies, cache, web storage, history and bookmarks?")
            .setPositiveButton("Clear"){_,_->CookieManager.getInstance().removeAllCookies(null);CookieManager.getInstance().flush();tabs.forEach{it.view.clearCache(true);it.view.clearHistory()};HistoryStore.clear(this);Toast.makeText(this,"Browsing data cleared.",Toast.LENGTH_SHORT).show()}
            .setNegativeButton("Cancel",null).show()
    }
    private fun searchSettings(){
        val items=arrayOf("Google","Bing","DuckDuckGo");val checked=items.indexOf(Prefs.searchEngine).coerceAtLeast(0)
        androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Search engine").setSingleChoiceItems(items,checked){d,w->Prefs.searchEngine=items[w];d.dismiss()}.show()
    }
    private var sugGen=0
    private fun setAddressMode(f:Boolean){
        val v=if(f)View.GONE else View.VISIBLE
        listOf(R.id.backButton,R.id.forwardButton,R.id.reloadButton,R.id.bookmarkButton,R.id.tabsButton,R.id.menuButton).forEach{findViewById<View>(it).visibility=v}
        findViewById<View>(R.id.goButton).visibility=if(f)View.VISIBLE else View.GONE
    }
    private fun leaveAddress(){
        address.clearFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).hideSoftInputFromWindow(address.windowToken,0)
        tabs.getOrNull(current)?.view?.requestFocus()
    }
    private fun renderSuggestions(hist:List<HistoryItem>,web:List<String>){
        val rows=ArrayList<Pair<String,String>>();val vals=ArrayList<String>()
        hist.forEach{rows.add((it.title.ifBlank{it.url}) to ("History  -  "+it.url));vals.add(it.url)}
        web.forEach{w->if(hist.none{it.title.equals(w,true)}){rows.add(w to "Search suggestion");vals.add(w)}}
        if(rows.isEmpty()){suggestion.visibility=View.GONE;return}
        suggestion.adapter=RowAdapter(this,rows)
        suggestion.setOnItemClickListener{_,_,p,_->if(p in vals.indices){address.setText(vals[p]);go()}}
        suggestion.visibility=View.VISIBLE
    }
    private fun suggest(q:String){
        val t=q.trim()
        val curUrl=shownUrl(tabs.getOrNull(current)?.view?.url).trim()
        val recent=t.isEmpty()||t==curUrl
        val all=HistoryStore.all(this).filter{!it.url.startsWith("file:")}
        val hist:List<HistoryItem>=if(recent)all.filter{it.url!=curUrl}.take(8) else{
            val terms=t.lowercase().split(" ").filter{it.isNotBlank()}
            all.filter{h->val hay=(h.title+" "+h.url).lowercase();terms.all{hay.contains(it)}}.take(6)
        }
        renderSuggestions(hist,emptyList())
        if(recent||t.length<2)return
        val gen=++sugGen
        exec.execute{runCatching{
            val u=URL("https://suggestqueries.google.com/complete/search?client=firefox&q="+URLEncoder.encode(t,"UTF-8"))
            val c=u.openConnection() as HttpURLConnection;c.connectTimeout=4000;c.readTimeout=4000
            val a=org.json.JSONArray(c.inputStream.bufferedReader().use{it.readText()}).getJSONArray(1)
            val s=MutableList(a.length()){a.getString(it)}.take(6)
            runOnUiThread{if(gen==sugGen&&address.hasFocus())renderSuggestions(hist,s)}
        }}
    }
    private fun analyze(){
        val v=tabs.getOrNull(current)?.view?:return
        SeoAnalyzer.analyze(v){o->showReport("Page analysis",ReportBuilder.analysis(o))}
    }
    private fun reportDialog(title:String,fields:Map<String,String>){showReport(title,ReportBuilder.generic(fields))}
    private fun showReport(title:String,sections:List<Section>){
        val text=ReportBuilder.toText(title,sections)
        val pageUrl=tabs.getOrNull(current)?.view?.url?:""
        val name=title.replace(" ","_")
        panel.show(title,ReportBuilder.render(this,sections),listOf(
            "Copy all" to {ReportBuilder.copy(this,title,text)},
            "Planning Hub" to {sendReport(title,pageUrl,text,sections)},
            "Save TXT" to {ReportUtil.txt(this,name,text)},
            "Save PDF" to {ReportUtil.pdf(this,name,ReportSheets.fromSections(title,pageUrl,sections))}))
    }
    private fun sendReport(title:String,pageUrl:String,text:String,sections:List<Section>){
        val a=getSharedPreferences("planning",MODE_PRIVATE);val arr=org.json.JSONArray(a.getString("reports","[]"));arr.put(JSONObject().put("title",title).put("url",pageUrl).put("report",text).put("sections",ReportBuilder.toJson(sections)));a.edit().putString("reports",arr.toString()).apply();Toast.makeText(this,"Sent to Planning Hub.",Toast.LENGTH_SHORT).show()
    }
    private fun viewSource(){val u=tabs.getOrNull(current)?.view?.url?:return;exec.execute{runCatching{SeoAnalyzer.fetchText(u)}.onSuccess{html->runOnUiThread{reportDialog("View source",mapOf("url" to u,"source" to html.take(20000)))}}.onFailure{showErr(it.message)}}}
    private fun headers(){val u=tabs.getOrNull(current)?.view?.url?:return;exec.execute{runCatching{
        val c=URL(u).openConnection() as HttpURLConnection;c.instanceFollowRedirects=false;c.connect();val h=c.headerFields.entries.joinToString("\n"){(k,v)->"${k?:"status"}: ${v.joinToString("; ")}"};runOnUiThread{reportDialog("Response headers",mapOf("url" to u,"headers" to h))}
    }.onFailure{showErr(it.message)}}}
    private fun redirectChain(){
        val u=tabs.getOrNull(current)?.view?.url?:return
        exec.execute{runCatching{
            var cur=u;val out=StringBuilder()
            for(n in 0 until 10){
                val c=URL(cur).openConnection() as HttpURLConnection
                c.instanceFollowRedirects=false;c.connectTimeout=10000;c.readTimeout=10000;c.connect()
                val code=c.responseCode;val loc=c.getHeaderField("Location");c.disconnect()
                out.append(code).append(" ").append(cur).append("\n")
                if(loc==null||code !in 300..399)break
                cur=URL(URL(cur),loc).toString()
            }
            runOnUiThread{reportDialog("Redirect chain",mapOf("url" to u,"chain" to out.toString()))}
        }.onFailure{showErr(it.message)}}
    }
    private fun textTool(file:String){val base=tabs.getOrNull(current)?.view?.url?:return;val uri=runCatching{val x=URL(base);URL(x.protocol,x.host,if(file=="robots.txt")"/robots.txt" else "/sitemap.xml")}.getOrNull()?:return;exec.execute{runCatching{val t=SeoAnalyzer.fetchText(uri.toString());runOnUiThread{reportDialog(file,mapOf("url" to uri.toString(),"content" to t.take(30000)))}}.onFailure{showErr(it.message)}}}
    private fun loadInfo(){
        val u=tabs.getOrNull(current)?.view?.url?:return
        exec.execute{runCatching{
            val t0=System.currentTimeMillis()
            val c=URL(u).openConnection() as HttpURLConnection
            c.connectTimeout=15000;c.readTimeout=20000;c.setRequestProperty("User-Agent",ua())
            var n=0L;val buf=ByteArray(8192)
            c.inputStream.use{st->while(true){val r=st.read(buf);if(r<0)break;n+=r}}
            val ms=System.currentTimeMillis()-t0;c.disconnect()
            runOnUiThread{reportDialog("Page load time + size",mapOf("url" to u,"time_ms" to ms.toString(),"size_bytes" to n.toString(),"size_kb" to String.format("%.1f",n/1024.0)))}
        }.onFailure{showErr(it.message)}}
    }
    private fun uaDialog(){val a=arrayOf("Mobile","Desktop","Googlebot");val sel=if(Prefs.desktopMode)1 else 0;androidx.appcompat.app.AlertDialog.Builder(this).setTitle("User agent").setSingleChoiceItems(a,sel){d,w->val v=tabs.getOrNull(current)?.view?:return@setSingleChoiceItems;v.settings.userAgentString=when(w){1->"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";2->"Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)";else->"Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"};Prefs.desktopMode=w==1;v.reload();d.dismiss()}.show()}
    private fun brokenLinks(){
        val v=tabs.getOrNull(current)?.view?:return
        v.evaluateJavascript("(function(){return JSON.stringify(Array.from(document.links).map(a=>a.href).filter(Boolean).slice(0,50));})()"){raw->
            exec.execute{runCatching{val urls=org.json.JSONArray(org.json.JSONTokener(raw).nextValue() as String);val out=StringBuilder();for(i in 0 until urls.length()){val u=urls.getString(i);runCatching{val c=URL(u).openConnection() as HttpURLConnection;c.requestMethod="HEAD";c.connectTimeout=5000;c.readTimeout=5000;out.append(c.responseCode).append(" ").append(u).append("\n")}.onFailure{out.append("ERROR ").append(u).append(" ").append(it.message).append("\n")}};runOnUiThread{reportDialog("Broken-link checker",mapOf("url" to(v.url?:""),"results" to out.toString()))}}.onFailure{showErr(it.message)}}
        }
    }
    // ---------- Video downloader (see VideoGrabber / VideoDl / DlPanel) ----------
    private fun updateFab(){fab?.visibility=if(grabber.hasAny()&&fullscreen==null)View.VISIBLE else View.GONE}
    private fun showFsFab(){
        hideFsFab()
        val d=resources.displayMetrics.density
        val b=ImageView(this);b.setImageResource(R.drawable.ic_download);b.setBackgroundResource(R.drawable.bg_fab)
        val pad=(14*d).toInt();b.setPadding(pad,pad,pad,pad)
        b.imageTintList=android.content.res.ColorStateList.valueOf(getColor(R.color.white));b.elevation=12*d
        b.setOnClickListener{grabber.open(null,null)}
        val lp=FrameLayout.LayoutParams((54*d).toInt(),(54*d).toInt(),Gravity.END or Gravity.TOP)
        lp.setMargins(0,(64*d).toInt(),(16*d).toInt(),0)
        addContentView(b,lp);fsFab=b
    }
    private fun hideFsFab(){fsFab?.let{(it.parent as? ViewGroup)?.removeView(it)};fsFab=null}
    private fun showVideoDownloads(){
        panel.show("Video downloads",DlPanel.build(this),listOf("Paste link" to {grabber.pasteLink()},"Clear finished" to {DlManager.clearFinished()}))
    }
    private val VIDEO_JS="""
        (function(){
          if(window.__vdInit)return;window.__vdInit=true;
          var btns=new Map();
          function srcOf(v){if(v.currentSrc)return v.currentSrc;if(v.src)return v.src;var s=v.querySelector('source[src]');return s?s.src:'';}
          function make(v){
            if(!document.body)return;
            var b=document.createElement('div');b.textContent='\u2B07 Download';
            b.style.cssText='position:fixed;z-index:2147483647;background:#3B82F6;color:#fff;font:600 13px sans-serif;padding:8px 12px;border-radius:18px;box-shadow:0 2px 8px rgba(0,0,0,.5);display:none;';
            b.addEventListener('click',function(e){e.preventDefault();e.stopPropagation();try{VideoBridge.download(srcOf(v),document.title||'video');}catch(x){}},true);
            document.body.appendChild(b);btns.set(v,b);
          }
          function tick(){
            document.querySelectorAll('video').forEach(function(v){if(!btns.has(v))make(v);});
            btns.forEach(function(b,v){
              if(!document.contains(v)){b.remove();btns.delete(v);return;}
              var r=v.getBoundingClientRect();
              var vis=r.width>140&&r.height>80&&r.bottom>0&&r.top<innerHeight&&r.right>0&&r.left<innerWidth;
              if(!vis){b.style.display='none';return;}
              b.style.display='block';
              b.style.left=Math.max(4,Math.min(innerWidth-120,r.left+8))+'px';
              b.style.top=Math.max(4,Math.min(innerHeight-44,r.top+8))+'px';
            });
          }
          setInterval(tick,700);window.addEventListener('scroll',tick,{passive:true});tick();
        })();
    """.trimIndent()
    private fun showErr(s:String?){runOnUiThread{Toast.makeText(this,s?:"Operation failed.",Toast.LENGTH_LONG).show()}}
    private fun ua()=if(Prefs.desktopMode)"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36" else "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
    override fun onPause(){super.onPause();CookieManager.getInstance().flush();if(tabs.isNotEmpty())Prefs.saveTabs(tabs.map{it.view.url?:it.url})}
    override fun onNewIntent(i:Intent){super.onNewIntent(i);i.data?.toString()?.let{navigate(it)}}
    override fun onBackPressed(){when{address.hasFocus()->leaveAddress();panel.isShowing->panel.hide();left.visibility==View.VISIBLE||right.visibility==View.VISIBLE->closeDrawers();goBackOrHome()->{};else->super.onBackPressed()}}
    inner class VideoBridge{
        @JavascriptInterface fun download(src:String,title:String){runOnUiThread{grabber.open(src,title)}}
    }
    inner class StartBridge{
        @JavascriptInterface fun search(q:String){runOnUiThread{
            val cur=tabs.getOrNull(current)?.view?.url?:""
            if(cur.startsWith("file:///android_asset/")){address.setText(q);navigate(q)}
        }}
    }
    inner class DownloadBridge(private val c:Context){
        @JavascriptInterface fun saveBase64(token:String,name:String,b64:String,mime:String){DownloadHelper.saveBase64(c,token,name,b64,mime)}
        @JavascriptInterface fun saveError(token:String,msg:String){DownloadHelper.saveError(c,token,msg)}
    }

    @Deprecated("Deprecated")
    override fun onActivityResult(req:Int,res:Int,data:Intent?){
        super.onActivityResult(req,res,data)
        if(req==PICK){
            val cb=fileCallback;fileCallback=null
            if(cb==null)return
            if(res!=RESULT_OK||data==null){cb.onReceiveValue(null);return}
            val r=ArrayList<Uri>();val clip=data.clipData
            if(clip!=null){for(i in 0 until clip.itemCount)r.add(clip.getItemAt(i).uri)} else data.data?.let{r.add(it)}
            cb.onReceiveValue(if(r.isEmpty())null else r.toTypedArray())
        }
    }
}
