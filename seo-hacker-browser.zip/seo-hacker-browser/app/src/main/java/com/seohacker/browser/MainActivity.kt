package com.seohacker.browser

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.*
import android.view.*
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.firebase.auth.FirebaseAuth
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

data class BrowserTab(var title:String,var url:String,var view:WebView)

class MainActivity : AppCompatActivity() {
    private val tabs=mutableListOf<BrowserTab>()
    private var current=0
    private lateinit var address:EditText
    private lateinit var progress:ProgressBar
    private lateinit var suggestion:ListView
    private lateinit var webFrame:FrameLayout
    private lateinit var left:View
    private lateinit var right:View
    private lateinit var bookmarkList:ListView
    private val exec=Executors.newCachedThreadPool()
    private var fileCallback:ValueCallback<Array<Uri>>?=null
    private var fullscreen:View?=null
    private var fullscreenCb:WebChromeClient.CustomViewCallback?=null
    private val PICK=71
    private val permission=72

    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        if(FirebaseAuth.getInstance().currentUser==null){startActivity(Intent(this,LoginActivity::class.java));finish();return}
        setContentView(R.layout.activity_main)
        AdBlocker.init(this)
        bindUi()
        requestInitialPermissions()
        val restored=Prefs.loadTabs()
        if(restored.isEmpty())newTab("file:///android_asset/index.html") else restored.take(8).forEach{newTab(it)}
        if(intent?.data!=null)navigate(intent.data.toString()) else showTab(0)
    }

    private fun bindUi(){
        address=findViewById(R.id.addressBar);progress=findViewById(R.id.pageProgress);suggestion=findViewById(R.id.suggestionList)
        left=findViewById(R.id.leftDrawer);right=findViewById(R.id.rightDrawer);bookmarkList=findViewById(R.id.bookmarkList)
        findViewById<ImageButton>(R.id.backButton).setOnClickListener{tabs.getOrNull(current)?.view?.let{if(it.canGoBack())it.goBack()}}
        findViewById<ImageButton>(R.id.forwardButton).setOnClickListener{tabs.getOrNull(current)?.view?.let{if(it.canGoForward())it.goForward()}}
        findViewById<ImageButton>(R.id.reloadButton).setOnClickListener{tabs.getOrNull(current)?.view?.reload()}
        findViewById<Button>(R.id.goButton).setOnClickListener{go()}
        findViewById<ImageButton>(R.id.bookmarkButton).setOnClickListener{bookmark()}
        findViewById<ImageButton>(R.id.tabsButton).setOnClickListener{tabsDialog()}
        findViewById<ImageButton>(R.id.menuButton).setOnClickListener{menu()}
        val ph=findViewById<View>(R.id.webView);webFrame=ph.parent as FrameLayout;webFrame.removeView(ph)
        address.setSelectAllOnFocus(true)
        address.setOnFocusChangeListener{_,f->if(f)address.selectAll()}
        address.setOnEditorActionListener{_,action,event->
            val enter=event?.keyCode==android.view.KeyEvent.KEYCODE_ENTER&&event.action==android.view.KeyEvent.ACTION_DOWN
            if(action==android.view.inputmethod.EditorInfo.IME_ACTION_GO||action==android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH||
                action==android.view.inputmethod.EditorInfo.IME_ACTION_DONE||action==android.view.inputmethod.EditorInfo.IME_ACTION_UNSPECIFIED||enter){go();true}else false}
        address.addTextChangedListener(object:android.text.TextWatcher{
            override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){}
            override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){if(address.hasFocus())suggest(s?.toString()?:"") else suggestion.visibility=View.GONE}
            override fun afterTextChanged(e:android.text.Editable?){}
        })
        listToolClicks()
        refreshBookmarks()
    }

    private fun listToolClicks(){
        findViewById<Button>(R.id.toolAnalyze).setOnClickListener{closeDrawers();analyze()}
        findViewById<Button>(R.id.toolSource).setOnClickListener{closeDrawers();viewSource()}
        findViewById<Button>(R.id.toolRedirects).setOnClickListener{closeDrawers();redirectChain()}
        findViewById<Button>(R.id.toolHeaders).setOnClickListener{closeDrawers();headers()}
        findViewById<Button>(R.id.toolRobots).setOnClickListener{closeDrawers();textTool("robots.txt")}
        findViewById<Button>(R.id.toolSitemap).setOnClickListener{closeDrawers();textTool("sitemap.xml")}
        findViewById<Button>(R.id.toolLoad).setOnClickListener{closeDrawers();loadInfo()}
        findViewById<Button>(R.id.toolUA).setOnClickListener{closeDrawers();uaDialog()}
        findViewById<Button>(R.id.toolBroken).setOnClickListener{closeDrawers();brokenLinks()}
        findViewById<Button>(R.id.toolPlanning).setOnClickListener{startActivity(Intent(this,PlanningHubActivity::class.java))}
        findViewById<Button>(R.id.toolHistory).setOnClickListener{startActivity(Intent(this,HistoryActivity::class.java))}
        findViewById<Button>(R.id.toolDownloads).setOnClickListener{startActivity(Intent(this,DownloadsActivity::class.java))}
    }

    private fun requestInitialPermissions(){
        val req=mutableListOf<String>()
        if(Build.VERSION.SDK_INT>=33&&ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)req.add(Manifest.permission.POST_NOTIFICATIONS)
        if(Build.VERSION.SDK_INT<=28&&ContextCompat.checkSelfPermission(this,Manifest.permission.WRITE_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED)req.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if(req.isNotEmpty())ActivityCompat.requestPermissions(this,req.toTypedArray(),permission)
    }

    private fun newTab(url:String){
        val w=WebView(this)
        configure(w)
        tabs.add(BrowserTab("New tab",url,w))
        w.loadUrl(url)
        current=tabs.lastIndex
        attachWebView(w)
    }
    private fun attachWebView(w:WebView){
        tabs.forEach{(it.view.parent as? ViewGroup)?.removeView(it.view)}
        (w.parent as? ViewGroup)?.removeView(w)
        webFrame.addView(w,0,ViewGroup.LayoutParams(-1,-1))
    }
    private fun shownUrl(u:String?)=if(u==null||u.startsWith("file:///android_asset"))"" else u
    private fun configure(w:WebView){
        w.setBackgroundColor(getColor(R.color.bg))
        w.settings.javaScriptEnabled=true;w.settings.domStorageEnabled=true;w.settings.databaseEnabled=true
        w.settings.allowFileAccess=true;w.settings.allowContentAccess=true
        w.settings.mixedContentMode=WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        w.settings.setSupportMultipleWindows(false);w.settings.javaScriptCanOpenWindowsAutomatically=true
        w.settings.userAgentString=ua()
        w.importantForAutofill=View.IMPORTANT_FOR_AUTOFILL_YES
        CookieManager.getInstance().setAcceptCookie(true);CookieManager.getInstance().setAcceptThirdPartyCookies(w,true)
        w.addJavascriptInterface(DownloadBridge(this),"AndroidDownload")
        w.addJavascriptInterface(StartBridge(),"StartBridge")
        w.webViewClient=object:WebViewClient(){
            override fun shouldOverrideUrlLoading(v:WebView,r:WebResourceRequest):Boolean{
                val u=r.url.toString()
                if(u.startsWith("http://")||u.startsWith("https://"))return false
                if(u.startsWith("intent:")||u.startsWith("tel:")||u.startsWith("mailto:"))runCatching{startActivity(Intent.parseUri(u,Intent.URI_INTENT_SCHEME))}.onFailure{Toast.makeText(this@MainActivity,"Cannot open external link: ${it.message}",Toast.LENGTH_LONG).show()}
                return true
            }
            override fun shouldInterceptRequest(v:WebView,r:WebResourceRequest):WebResourceResponse?=AdBlocker.intercept(r)
            override fun onPageStarted(v:WebView,u:String,b:Bitmap?){
                if(v===tabs.getOrNull(current)?.view){address.setText(shownUrl(u));progress.visibility=View.VISIBLE}
            }
            override fun onPageFinished(v:WebView,u:String){
                val t=tabs.firstOrNull{it.view===v}
                if(t!=null){t.url=u;t.title=v.title?:u}
                if(t!=null&&t===tabs.getOrNull(current)){address.setText(shownUrl(u));progress.visibility=View.GONE}
                if(!u.startsWith("file:")){HistoryStore.add(this@MainActivity,v.title?:u,u)}
                CookieManager.getInstance().flush()
                if(AdBlocker.enabled)v.evaluateJavascript(AdBlocker.cssJs(),null)
                Prefs.saveTabs(tabs.map{it.url})
            }
        }
        w.webChromeClient=object:WebChromeClient(){
            override fun onProgressChanged(v:WebView,p:Int){progress.progress=p;progress.visibility=if(p<100)View.VISIBLE else View.GONE}
            override fun onShowFileChooser(v:WebView,cb:ValueCallback<Array<Uri>>,params:FileChooserParams):Boolean{
                fileCallback?.onReceiveValue(null);fileCallback=cb
                val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{
                    addCategory(Intent.CATEGORY_OPENABLE);type="*/*"
                    if(params.mode==FileChooserParams.MODE_OPEN_MULTIPLE)putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true)
                    val types=params.acceptTypes.flatMap{it.split(",")}.map{it.trim()}.filter{it.contains("/")}
                    if(types.isNotEmpty())putExtra(Intent.EXTRA_MIME_TYPES,types.toTypedArray())
                }
                return try{startActivityForResult(i,PICK);true}catch(e:Exception){fileCallback?.onReceiveValue(null);fileCallback=null;false}
            }
            override fun onPermissionRequest(r:PermissionRequest){
                val needed=r.resources.mapNotNull{
                    when(it){PermissionRequest.RESOURCE_VIDEO_CAPTURE->Manifest.permission.CAMERA
                        PermissionRequest.RESOURCE_AUDIO_CAPTURE->Manifest.permission.RECORD_AUDIO else->null}
                }.distinct()
                if(needed.all{ContextCompat.checkSelfPermission(this@MainActivity,it)==PackageManager.PERMISSION_GRANTED})r.grant(r.resources)
                else {pendingWebPermission=r;ActivityCompat.requestPermissions(this@MainActivity,needed.toTypedArray(),permission)}
            }
            override fun onGeolocationPermissionsShowPrompt(origin:String,cb:GeolocationPermissions.Callback){
                geoCallback=cb;geoOrigin=origin
                if(ContextCompat.checkSelfPermission(this@MainActivity,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED)cb.invoke(origin,true,false)
                else ActivityCompat.requestPermissions(this@MainActivity,arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),permission)
            }
            override fun onShowCustomView(view:View,cb:CustomViewCallback){fullscreen=view;fullscreenCb=cb;addContentView(view,ViewGroup.LayoutParams(-1,-1))}
            override fun onHideCustomView(){fullscreen?.let{(it.parent as? ViewGroup)?.removeView(it)};fullscreen=null;fullscreenCb?.onCustomViewHidden();fullscreenCb=null}
        }
        w.setDownloadListener{url,agent,cd,mime,_->DownloadHelper.handle(this,w,url,agent,cd,mime)}
    }
    private var pendingWebPermission:PermissionRequest?=null
    private var geoCallback:GeolocationPermissions.Callback?=null
    private var geoOrigin:String?=null

    override fun onRequestPermissionsResult(r:Int,p:Array<out String>,g:IntArray){
        super.onRequestPermissionsResult(r,p,g)
        if(r==permission){
            pendingWebPermission?.let{req->if(g.any{it==PackageManager.PERMISSION_GRANTED})req.grant(req.resources) else req.deny();pendingWebPermission=null}
            geoCallback?.let{cb->val ok=ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;cb.invoke(geoOrigin,ok,false);geoCallback=null}
        }
    }

    private fun go(){navigate(address.text.toString().trim());address.clearFocus()}
    private fun navigate(raw:String){
        val q=raw.trim();if(q.isBlank())return
        val url=if(q.startsWith("http://")||q.startsWith("https://"))q else if(q.contains(".")&&!q.contains(" "))"https://$q" else{
            val base=when(Prefs.searchEngine){"Bing"->"https://www.bing.com/search?q=";"DuckDuckGo"->"https://duckduckgo.com/?q=";else->"https://www.google.com/search?q="}
            base+URLEncoder.encode(q,"UTF-8")
        }
        tabs.getOrNull(current)?.view?.loadUrl(url)
    }
    private fun showTab(i:Int){if(i !in tabs.indices)return;current=i;attachWebView(tabs[i].view);address.setText(tabs[i].view.url?:tabs[i].url)}
    private fun tabsDialog(){
        val rows=tabs.mapIndexed{i,t->"${i+1}. ${t.title.ifBlank{"New tab"}}"}
        val items=(rows+listOf("New tab")).toTypedArray()
        androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Tabs").setItems(items){_,which->
            if(which==tabs.size)newTab("file:///android_asset/index.html") else showTab(which)
        }.setNegativeButton("Close current"){_,_->closeTab(current)}.setNeutralButton("Close",null).show()
    }
    private fun closeTab(i:Int){if(tabs.size<=1){finish();return};val gone=tabs.removeAt(i);(gone.view.parent as? ViewGroup)?.removeView(gone.view);gone.view.destroy();current=minOf(current,tabs.lastIndex);showTab(current);Prefs.saveTabs(tabs.map{it.url})}
    private fun bookmark(){val t=tabs.getOrNull(current)?:return;BookmarkStore.add(this,t.title,t.url);refreshBookmarks();Toast.makeText(this,"Bookmark saved",Toast.LENGTH_SHORT).show()}
    private fun refreshBookmarks(){
        val b=BookmarkStore.all(this);bookmarkList.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_2,android.R.id.text1,b.map{it.title.ifBlank{it.url}})
        bookmarkList.setOnItemClickListener{_,_,p,_->showTab(current);navigate(b[p].url);right.visibility=View.GONE}
    }
    private fun menu(){
        val names=arrayOf("SEO tools","Bookmarks","Find in page","Desktop mode","Ad blocker","Open in Chrome Custom Tab","Clear browsing data","Settings","Log out")
        androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Menu").setItems(names){_,w->
            when(w){0->left.visibility=View.VISIBLE;1->right.visibility=View.VISIBLE;2->findInPage();3->{Prefs.desktopMode=!Prefs.desktopMode;tabs.getOrNull(current)?.view?.settings?.userAgentString=ua();tabs.getOrNull(current)?.view?.reload()}
                4->{Prefs.adBlocker=!Prefs.adBlocker;AdBlocker.enabled=Prefs.adBlocker;Toast.makeText(this,"Ad blocker ${if(Prefs.adBlocker)"on" else "off"} • blocked ${AdBlocker.count}",Toast.LENGTH_SHORT).show()}
                5->tabs.getOrNull(current)?.view?.url?.let{runCatching{CustomTabsIntent.Builder().build().launchUrl(this,Uri.parse(it))}}
                6->clearData();7->searchSettings();8->{FirebaseAuth.getInstance().signOut();startActivity(Intent(this,LoginActivity::class.java));finish()}
            }
        }.show()
    }
    private fun closeDrawers(){left.visibility=View.GONE;right.visibility=View.GONE}
    private fun findInPage(){
        val e=EditText(this);e.hint="Find in page"
        androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Find in page").setView(e).setPositiveButton("Find"){_,_->tabs.getOrNull(current)?.view?.findAllAsync(e.text.toString())}.show()
    }
    private fun clearData(){
        androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Clear browsing data").setMessage("Clear cookies, cache, web storage, history and bookmarks?")
            .setPositiveButton("Clear"){_,_->CookieManager.getInstance().removeAllCookies(null);CookieManager.getInstance().flush();tabs.forEach{it.view.clearCache(true);it.view.clearHistory()};HistoryStore.clear(this);Toast.makeText(this,"Browsing data cleared.",Toast.LENGTH_SHORT).show()}
            .setNegativeButton("Cancel",null).show()
    }
    private fun searchSettings(){
        val items=arrayOf("Google","Bing","DuckDuckGo");val checked=items.indexOf(Prefs.searchEngine).coerceAtLeast(0)
        androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Search engine").setSingleChoiceItems(items,checked){d,w->Prefs.searchEngine=items[w];d.dismiss()}.show()
    }
    private fun suggest(q:String){
        if(q.length<2){suggestion.visibility=View.GONE;return}
        exec.execute{runCatching{
            val u=URL("https://suggestqueries.google.com/complete/search?client=firefox&q="+URLEncoder.encode(q,"UTF-8"))
            val c=u.openConnection() as HttpURLConnection;c.connectTimeout=4000;c.readTimeout=4000
            val a=org.json.JSONArray(c.inputStream.bufferedReader().use{it.readText()}).getJSONArray(1)
            val s=MutableList(a.length()){a.getString(it)}
            runOnUiThread{suggestion.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,s);suggestion.visibility=View.VISIBLE;suggestion.setOnItemClickListener{_,_,p,_->address.setText(s[p]);go();suggestion.visibility=View.GONE}}
        }}
    }
    private fun analyze(){
        val v=tabs.getOrNull(current)?.view?:return
        SeoAnalyzer.analyze(v){o->val fields=linkedMapOf<String,String>();val keys=arrayOf("url","title","titleLength","metaDescription","metaDescriptionLength","canonical","robots","h1","h1Count","h2Count","h3Count","h4Count","h5Count","h6Count","hreflang","openGraph","twitter","jsonLd","imagesWithoutAlt","wordCount","topKeywords","internalLinks","externalLinks","nofollowLinks","lang","viewport")
            keys.forEach{fields[it]=o.opt(it).toString()};reportDialog("Page analysis",fields)}
    }
    private fun reportDialog(title:String,fields:Map<String,String>){
        val text=fields.entries.joinToString("\n\n"){"${it.key}: ${it.value}"}
        androidx.appcompat.app.AlertDialog.Builder(this).setTitle(title).setMessage(text).setPositiveButton("Download CSV"){_,_->ReportUtil.csv(this,title.replace(" ","_"),fields)}
            .setNegativeButton("Download TXT"){_,_->ReportUtil.txt(this,title.replace(" ","_"),text)}
            .setNeutralButton("Send to Planning Hub?"){_,_->sendReport(title,fields)}.show()
    }
    private fun sendReport(title:String,fields:Map<String,String>){
        val a=getSharedPreferences("planning",MODE_PRIVATE);val arr=org.json.JSONArray(a.getString("reports","[]"));arr.put(JSONObject().put("title",title).put("url",tabs.getOrNull(current)?.view?.url?:"").put("report",fields.entries.joinToString("\n"){"${it.key}: ${it.value}"}));a.edit().putString("reports",arr.toString()).apply();Toast.makeText(this,"Sent to Planning Hub.",Toast.LENGTH_SHORT).show()
    }
    private fun viewSource(){val u=tabs.getOrNull(current)?.view?.url?:return;exec.execute{runCatching{SeoAnalyzer.fetchText(u)}.onSuccess{html->runOnUiThread{reportDialog("View source",mapOf("url" to u,"source" to html.take(20000)))}}.onFailure{showErr(it.message)}}}
    private fun headers(){val u=tabs.getOrNull(current)?.view?.url?:return;exec.execute{runCatching{
        val c=URL(u).openConnection() as HttpURLConnection;c.instanceFollowRedirects=false;c.connect();val h=c.headerFields.entries.joinToString("\n"){(k,v)->"${k?:"status"}: ${v.joinToString("; ")}"};runOnUiThread{reportDialog("Response headers",mapOf("url" to u,"headers" to h))}
    }.onFailure{showErr(it.message)}}}
    private fun redirectChain(){
        val u=tabs.getOrNull(current)?.view?.url?:return
        exec.execute{runCatching{
            var cur=u;val out=StringBuilder()
            for(n in 0 until 10){
                val c=URL(cur).openConnection() as HttpURLConnection
                c.instanceFollowRedirects=false;c.connectTimeout=10000;c.readTimeout=10000;c.connect()
                val code=c.responseCode;val loc=c.getHeaderField("Location");c.disconnect()
                out.append(code).append(" ").append(cur).append("\n")
                if(loc==null||code !in 300..399)break
                cur=URL(URL(cur),loc).toString()
            }
            runOnUiThread{reportDialog("Redirect chain",mapOf("url" to u,"chain" to out.toString()))}
        }.onFailure{showErr(it.message)}}
    }
    private fun textTool(file:String){val base=tabs.getOrNull(current)?.view?.url?:return;val uri=runCatching{val x=URL(base);URL(x.protocol,x.host,if(file=="robots.txt")"/robots.txt" else "/sitemap.xml")}.getOrNull()?:return;exec.execute{runCatching{val t=SeoAnalyzer.fetchText(uri.toString());runOnUiThread{reportDialog(file,mapOf("url" to uri.toString(),"content" to t.take(30000)))}}.onFailure{showErr(it.message)}}}
    private fun loadInfo(){
        val u=tabs.getOrNull(current)?.view?.url?:return
        exec.execute{runCatching{
            val t0=System.currentTimeMillis()
            val c=URL(u).openConnection() as HttpURLConnection
            c.connectTimeout=15000;c.readTimeout=20000;c.setRequestProperty("User-Agent",ua())
            var n=0L;val buf=ByteArray(8192)
            c.inputStream.use{st->while(true){val r=st.read(buf);if(r<0)break;n+=r}}
            val ms=System.currentTimeMillis()-t0;c.disconnect()
            runOnUiThread{reportDialog("Page load time + size",mapOf("url" to u,"time_ms" to ms.toString(),"size_bytes" to n.toString(),"size_kb" to String.format("%.1f",n/1024.0)))}
        }.onFailure{showErr(it.message)}}
    }
    private fun uaDialog(){val a=arrayOf("Mobile","Desktop","Googlebot");val sel=if(Prefs.desktopMode)1 else 0;androidx.appcompat.app.AlertDialog.Builder(this).setTitle("User agent").setSingleChoiceItems(a,sel){d,w->val v=tabs.getOrNull(current)?.view?:return@setSingleChoiceItems;v.settings.userAgentString=when(w){1->"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";2->"Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)";else->"Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"};Prefs.desktopMode=w==1;v.reload();d.dismiss()}.show()}
    private fun brokenLinks(){
        val v=tabs.getOrNull(current)?.view?:return
        v.evaluateJavascript("(function(){return JSON.stringify(Array.from(document.links).map(a=>a.href).filter(Boolean).slice(0,50));})()"){raw->
            exec.execute{runCatching{val urls=org.json.JSONArray(org.json.JSONTokener(raw).nextValue() as String);val out=StringBuilder();for(i in 0 until urls.length()){val u=urls.getString(i);runCatching{val c=URL(u).openConnection() as HttpURLConnection;c.requestMethod="HEAD";c.connectTimeout=5000;c.readTimeout=5000;out.append(c.responseCode).append(" ").append(u).append("\n")}.onFailure{out.append("ERROR ").append(u).append(" ").append(it.message).append("\n")}};runOnUiThread{reportDialog("Broken-link checker",mapOf("url" to(v.url?:""),"results" to out.toString()))}}.onFailure{showErr(it.message)}}
        }
    }
    private fun showErr(s:String?){runOnUiThread{Toast.makeText(this,s?:"Operation failed.",Toast.LENGTH_LONG).show()}}
    private fun ua()=if(Prefs.desktopMode)"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36" else "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
    override fun onPause(){super.onPause();CookieManager.getInstance().flush();if(tabs.isNotEmpty())Prefs.saveTabs(tabs.map{it.view.url?:it.url})}
    override fun onNewIntent(i:Intent){super.onNewIntent(i);i.data?.toString()?.let{navigate(it)}}
    override fun onBackPressed(){when{left.visibility==View.VISIBLE->{left.visibility=View.GONE};right.visibility==View.VISIBLE->{right.visibility=View.GONE};tabs.getOrNull(current)?.view?.canGoBack()==true->tabs[current].view.goBack();else->super.onBackPressed()}}
    inner class StartBridge{
        @JavascriptInterface fun search(q:String){runOnUiThread{
            val cur=tabs.getOrNull(current)?.view?.url?:""
            if(cur.startsWith("file:///android_asset/")){address.setText(q);navigate(q)}
        }}
    }
    inner class DownloadBridge(private val c:Context){
        @JavascriptInterface fun saveBase64(token:String,name:String,b64:String,mime:String){DownloadHelper.saveBase64(c,token,name,b64,mime)}
        @JavascriptInterface fun saveError(token:String,msg:String){DownloadHelper.saveError(c,token,msg)}
    }

    @Deprecated("Deprecated")
    override fun onActivityResult(req:Int,res:Int,data:Intent?){
        super.onActivityResult(req,res,data)
        if(req==PICK){
            val cb=fileCallback;fileCallback=null
            if(cb==null)return
            if(res!=RESULT_OK||data==null){cb.onReceiveValue(null);return}
            val r=ArrayList<Uri>();val clip=data.clipData
            if(clip!=null){for(i in 0 until clip.itemCount)r.add(clip.getItemAt(i).uri)} else data.data?.let{r.add(it)}
            cb.onReceiveValue(if(r.isEmpty())null else r.toTypedArray())
        }
    }
}
