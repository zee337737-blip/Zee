package com.seohacker.browser

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

/** Shows an AI reply as boxes: one card per section, code in dark code boxes, Warning/Fix labels coloured. */
object ReplyView {
    private class Item(val kind: String, val text: String, val prefix: String = "", val indent: Int = 0)
    private class Sec(val title: String?) {
        val items = ArrayList<Item>()
    }

    private val headRe = Regex("^#{1,6}\\s+(.*)$")
    private val boldLineRe = Regex("^\\*\\*(.+?)\\*\\*:?$")
    private val numColonRe = Regex("^\\d+[.)]\\s+(?:\\*\\*)?(.{2,80}?)(?:\\*\\*)?:$")
    private val bulletRe = Regex("^(\\s*)([-*\\u2022]|\\d+[.)])\\s+(.*)$")
    private val onlyCodeRe = Regex("^`([^`]+)`$")
    private val inlineRe = Regex("\\*\\*(.+?)\\*\\*|`([^`]+)`")
    private val badRe = Regex("^(warnings?|problems?|issues?|errors?|weak points?|missing|critical)\\b[^:]{0,30}:", RegexOption.IGNORE_CASE)
    private val goodRe = Regex("^(fix|fixes|solution|recommendation|tip|suggestion|action|how to fix|result)\\b[^:]{0,30}:", RegexOption.IGNORE_CASE)

    private fun clean(s: String): String = s.replace("**", "").trim().trimEnd(':').trim()

    private fun headingOf(t: String): String? {
        val h = headRe.find(t)
        if (h != null) return clean(h.groupValues[1])
        val b = boldLineRe.find(t)
        if (b != null && b.groupValues[1].length <= 90 && !b.groupValues[1].contains("**")) return clean(b.groupValues[1])
        if (numColonRe.find(t) != null) return clean(t)
        return null
    }

    private fun parse(md: String): List<Sec> {
        val secs = ArrayList<Sec>()
        var cur = Sec(null)
        var inCode = false
        val code = StringBuilder()
        for (raw in md.lines()) {
            val line = raw.trimEnd()
            val t = line.trim()
            if (t.startsWith("```")) {
                if (inCode) {
                    cur.items.add(Item("c", code.toString().trimEnd()))
                    code.setLength(0)
                    inCode = false
                } else inCode = true
                continue
            }
            if (inCode) {
                code.append(line).append('\n')
                continue
            }
            if (t.isEmpty()) continue
            val head = headingOf(t)
            if (head != null) {
                if (cur.title != null || cur.items.isNotEmpty()) secs.add(cur)
                cur = Sec(head)
                continue
            }
            val bm = bulletRe.find(line)
            if (bm != null) {
                val marker = bm.groupValues[2]
                val body = bm.groupValues[3].trim()
                val only = onlyCodeRe.find(body)
                if (only != null) {
                    cur.items.add(Item("c", only.groupValues[1]))
                } else {
                    val prefix = if (marker[0].isDigit()) "$marker " else "\u2022 "
                    cur.items.add(Item("b", body, prefix, if (bm.groupValues[1].length >= 2) 1 else 0))
                }
                continue
            }
            cur.items.add(Item("p", t))
        }
        if (inCode && code.isNotEmpty()) cur.items.add(Item("c", code.toString().trimEnd()))
        if (cur.title != null || cur.items.isNotEmpty()) secs.add(cur)
        return secs
    }

    private fun inline(text: String): SpannableStringBuilder {
        val sb = SpannableStringBuilder()
        var last = 0
        for (m in inlineRe.findAll(text)) {
            sb.append(text.substring(last, m.range.first))
            val s = sb.length
            val bold = m.groups[1]
            if (bold != null) {
                sb.append(bold.value)
                sb.setSpan(StyleSpan(Typeface.BOLD), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            } else {
                val c = m.groups[2]?.value ?: ""
                sb.append(c)
                sb.setSpan(TypefaceSpan("monospace"), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                sb.setSpan(BackgroundColorSpan(Color.parseColor("#0B1220")), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                sb.setSpan(ForegroundColorSpan(Color.parseColor("#7DD3FC")), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            last = m.range.last + 1
        }
        sb.append(text.substring(last))
        return sb
    }

    private fun styled(prefix: String, text: String): CharSequence {
        val sb = SpannableStringBuilder(prefix)
        val body = inline(text)
        sb.append(body)
        val plain = body.toString()
        val bad = badRe.find(plain)
        val good = if (bad == null) goodRe.find(plain) else null
        val hit = bad ?: good
        if (hit != null) {
            val col = if (bad != null) "#F87171" else "#4ADE80"
            val end = prefix.length + hit.range.last + 1
            sb.setSpan(ForegroundColorSpan(Color.parseColor(col)), prefix.length, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.setSpan(StyleSpan(Typeface.BOLD), prefix.length, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        return sb
    }

    private fun secText(s: Sec): String {
        val sb = StringBuilder()
        if (s.title != null) sb.append(s.title).append('\n')
        for (item in s.items) sb.append(item.prefix).append(item.text).append('\n')
        return sb.toString().trim()
    }

    fun build(ctx: Context, md: String): View {
        val d = ctx.resources.displayMetrics.density
        fun dp(n: Int) = (n * d).toInt()
        val colText = ctx.getColor(R.color.text)
        val colAccent = ctx.getColor(R.color.accent)
        val root = LinearLayout(ctx)
        root.orientation = LinearLayout.VERTICAL
        var secs = parse(md)
        if (secs.isEmpty()) {
            val one = Sec(null)
            one.items.add(Item("p", md.trim().ifBlank { "(empty)" }))
            secs = listOf(one)
        }
        for (s in secs) {
            val card = LinearLayout(ctx)
            card.orientation = LinearLayout.VERTICAL
            card.setBackgroundResource(R.drawable.bg_card)
            card.setPadding(dp(14), dp(12), dp(14), dp(12))

            val head = LinearLayout(ctx)
            head.orientation = LinearLayout.HORIZONTAL
            head.gravity = Gravity.CENTER_VERTICAL
            if (s.title != null) {
                val t = TextView(ctx)
                t.text = s.title
                t.textSize = 15.5f
                t.setTextColor(colAccent)
                t.setTypeface(t.typeface, Typeface.BOLD)
                head.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
            } else {
                head.addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f))
            }
            val copy = TextView(ctx)
            copy.text = "Copy"
            copy.textSize = 12.5f
            copy.setTextColor(colAccent)
            copy.setPadding(dp(10), dp(2), 0, dp(2))
            val whole = secText(s)
            copy.setOnClickListener { ReportBuilder.copy(ctx, s.title ?: "AI reply", whole) }
            head.addView(copy)
            card.addView(head)

            for (item in s.items) {
                when (item.kind) {
                    "c" -> {
                        val box = LinearLayout(ctx)
                        box.orientation = LinearLayout.VERTICAL
                        box.setBackgroundResource(R.drawable.bg_code)
                        box.setPadding(dp(10), dp(6), dp(10), dp(8))
                        val cp = TextView(ctx)
                        cp.text = "Copy code"
                        cp.textSize = 11.5f
                        cp.setTextColor(colAccent)
                        cp.gravity = Gravity.END
                        val codeText = item.text
                        cp.setOnClickListener { ReportBuilder.copy(ctx, "code", codeText) }
                        box.addView(cp, LinearLayout.LayoutParams(-1, -2))
                        val tv = TextView(ctx)
                        tv.text = codeText
                        tv.typeface = Typeface.MONOSPACE
                        tv.textSize = 12.5f
                        tv.setTextColor(Color.parseColor("#CBD5E1"))
                        tv.setTextIsSelectable(true)
                        box.addView(tv, LinearLayout.LayoutParams(-1, -2))
                        card.addView(box, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
                    }
                    else -> {
                        val tv = TextView(ctx)
                        tv.text = styled(item.prefix, item.text)
                        tv.textSize = 14.5f
                        tv.setTextColor(colText)
                        tv.setLineSpacing(0f, 1.1f)
                        tv.setTextIsSelectable(true)
                        card.addView(tv, LinearLayout.LayoutParams(-1, -2).apply {
                            topMargin = dp(if (item.kind == "b") 6 else 8)
                            marginStart = dp(item.indent * 14)
                        })
                    }
                }
            }
            root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
        return root
    }
}
