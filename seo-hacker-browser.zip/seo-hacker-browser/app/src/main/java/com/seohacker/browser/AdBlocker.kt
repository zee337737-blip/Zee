package com.seohacker.browser

import android.content.Context
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import java.io.ByteArrayInputStream

object AdBlocker {
    private val blocked = HashSet<String>()
    var enabled = true
    var count = 0
    fun init(c: Context) {
        if (blocked.isNotEmpty()) return
        runCatching {
            c.assets.open("blocklist.txt").bufferedReader().useLines { lines ->
                lines.map { it.trim().lowercase() }.filter { it.isNotBlank() && !it.startsWith("#") }.forEach(blocked::add)
            }
        }
        enabled = Prefs.adBlocker
    }
    fun shouldBlock(host: String): Boolean {
        if (!enabled) return false
        var h = host.lowercase().trim('.')
        if (h.isEmpty()) return false
        if (h == "google.com" || h.endsWith(".google.com") || h == "gstatic.com" || h.endsWith(".gstatic.com") ||
            h == "googleapis.com" || h.endsWith(".googleapis.com") || h == "youtube.com" || h.endsWith(".youtube.com")) return false
        while (true) {
            if (blocked.contains(h)) return true
            val i = h.indexOf('.')
            if (i < 0 || i == h.length - 1) return false
            h = h.substring(i + 1)
        }
    }
    fun intercept(request: WebResourceRequest): WebResourceResponse? {
        if (shouldBlock(request.url.host ?: "")) {
            count++
            return WebResourceResponse("text/plain", "UTF-8", ByteArrayInputStream(ByteArray(0)))
        }
        return null
    }
    fun cssJs(): String = """
        (function(){
          if(document.getElementById('__seo_adcss'))return;
          var s=document.createElement('style');s.id='__seo_adcss';
          s.textContent='ins.adsbygoogle,[id^="google_ads"],[id^="div-gpt-ad"],[class~="adsbygoogle"],[data-ad-slot],[data-google-query-id],'
            +'iframe[src*="doubleclick.net"],iframe[src*="googlesyndication.com"],[id*="taboola"],[class*="taboola"],[class*="outbrain"],'
            +'[aria-label="Advertisement"],.ad-banner,.ad-container,.ad-slot,.ad-wrapper,.advert,.advertisement,.sponsored-ad'
            +'{display:none!important}';
          (document.head||document.documentElement).appendChild(s);
        })();
    """.trimIndent()
}
