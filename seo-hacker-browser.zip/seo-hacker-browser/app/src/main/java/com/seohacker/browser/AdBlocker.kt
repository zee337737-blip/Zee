package com.seohacker.browser

import android.content.Context
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream

object AdBlocker {
    private val blocked = HashSet<String>()
    @Volatile var enabled = true
    @Volatile var count = 0
    @Volatile var popupCount = 0

    // Sites that must never be blocked (login / core services).
    private val safe = listOf(
        "google.com", "gstatic.com", "googleapis.com", "youtube.com", "ytimg.com", "googlevideo.com",
        "facebook.com", "fbcdn.net", "twitter.com", "x.com", "github.com", "githubusercontent.com",
        "cloudflare.com", "cloudflareinsights.com", "recaptcha.net", "hcaptcha.com", "firebaseapp.com"
    )

    // Parts of a URL that are (almost) always ads. Only specific enough words, to avoid breaking real sites.
    private val badParts = listOf(
        "/popunder", "popunder.", "/pop-under", "/popads", "pop.js", "/adserver", "/ad-server",
        "adsbygoogle.js", "/prebid", "/banner-ads/", "/ads/banner", "/adframe", "/ad_frame",
        "/advert/", "/adsense/", "/showads", "/ads.js", "/ad.js", "/adv.js", "/adblock-detect",
        "/clickunder", "/interstitial-ad", "/vast.xml", "/vast?", "/vpaid", "/preroll"
    )

    fun init(c: Context) {
        if (blocked.isNotEmpty()) { enabled = Prefs.adBlocker; return }
        runCatching {
            c.assets.open("blocklist.txt").bufferedReader().useLines { lines ->
                lines.map { it.trim().lowercase() }.filter { it.isNotBlank() && !it.startsWith("#") }.forEach(blocked::add)
            }
        }
        enabled = Prefs.adBlocker
    }

    private fun isSafe(h: String): Boolean = safe.any { h == it || h.endsWith(".$it") }

    fun shouldBlock(host: String): Boolean {
        if (!enabled) return false
        var h = host.lowercase().trim('.')
        if (h.isEmpty() || isSafe(h)) return false
        while (true) {
            if (blocked.contains(h)) return true
            val i = h.indexOf('.')
            if (i < 0 || i == h.length - 1) return false
            h = h.substring(i + 1)
        }
    }

    fun shouldBlockUrl(url: String): Boolean {
        if (!enabled) return false
        val u = url.lowercase()
        val host = try { android.net.Uri.parse(u).host ?: "" } catch (e: Exception) { "" }
        if (host.isNotEmpty() && isSafe(host)) return false
        if (host.isNotEmpty() && shouldBlock(host)) return true
        return badParts.any { u.contains(it) }
    }

    fun intercept(request: WebResourceRequest): WebResourceResponse? {
        val u = request.url.toString()
        if (!u.startsWith("http")) return null
        if (shouldBlockUrl(u)) {
            count++
            return WebResourceResponse("text/plain", "UTF-8", ByteArrayInputStream(ByteArray(0)))
        }
        return null
    }

    /** Runs at document start in every frame: blocks popups / popunders and ad redirects started by scripts. */
    fun startJs(): String = """
        (function(){
          if(window.__seoAdGuard)return;window.__seoAdGuard=true;
          var okHosts=['accounts.google.com','appleid.apple.com','login.microsoftonline.com','www.facebook.com','m.facebook.com','twitter.com','x.com','github.com','www.paypal.com','discord.com','t.me','telegram.org','wa.me','api.whatsapp.com'];
          function site(h){var p=String(h||'').split('.');return p.length>2?p.slice(-2).join('.'):String(h||'')}
          function allowed(u){
            try{var a=new URL(u,location.href);
              if(a.protocol!=='http:'&&a.protocol!=='https:')return false;
              if(okHosts.indexOf(a.hostname)>=0)return true;
              return site(a.hostname)===site(location.hostname);
            }catch(e){return false}
          }
          var realOpen=window.open;
          window.open=function(u,t,f){
            if(u&&allowed(u)){try{return realOpen.call(window,u,t,f)}catch(e){}}
            try{if(window.PopupBridge)PopupBridge.blocked(String(u||''))}catch(e){}
            return {closed:true,close:function(){},focus:function(){},blur:function(){},postMessage:function(){},document:{write:function(){},close:function(){}},location:{}};
          };
          // click-jacking: links that open another site in a new tab right after a click on empty page areas
          document.addEventListener('click',function(e){
            var a=e.target&&e.target.closest?e.target.closest('a[target=_blank]'):null;
            if(a&&a.href&&!allowed(a.href)){
              var h=''; try{h=new URL(a.href,location.href).hostname}catch(x){}
              try{if(window.AdGuardBridge&&AdGuardBridge.isAd(a.href)){e.preventDefault();e.stopPropagation();return false}}catch(x){}
            }
          },true);
        })();
    """.trimIndent()

    /** Hides ad boxes and removes invisible full-screen click-catching overlays. Runs after every page load. */
    fun cssJs(): String = """
        (function(){
          if(!document.getElementById('__seo_adcss')){
            var s=document.createElement('style');s.id='__seo_adcss';
            s.textContent='ins.adsbygoogle,[id^="google_ads"],[id^="div-gpt-ad"],[class~="adsbygoogle"],[data-ad-slot],[data-google-query-id],[data-ad-client],'
              +'iframe[src*="doubleclick.net"],iframe[src*="googlesyndication.com"],iframe[src*="exoclick"],iframe[src*="adsterra"],iframe[src*="popads"],iframe[src*="propeller"],'
              +'[id*="taboola"],[class*="taboola"],[class*="outbrain"],[id^="ad-"],[id^="ads-"],[id$="-ad"],[id$="_ad"],[id*="adcontainer"],[id*="ad_container"],'
              +'[aria-label="Advertisement"],[aria-label="advertisement"],.ad-banner,.ad-container,.ad-slot,.ad-wrapper,.ad-box,.ad-unit,.adbox,.advert,.advertisement,.adv-box,.sponsored-ad,.sponsor-ad,'
              +'.banner-ads,.banner_ads,.google-ad,.mgid,.mgbox,[class*="popunder"],[id*="popunder"],[class*="pop-up-ad"],a[href*="exoclick"],a[href*="adsterra"],a[href*="popcash"],a[href*="propellerads"]'
              +'{display:none!important;visibility:hidden!important;height:0!important;min-height:0!important;overflow:hidden!important}';
            (document.head||document.documentElement).appendChild(s);
          }
          if(window.__seoOverlayTimer)return;
          function sweep(){
            try{
              var vw=innerWidth,vh=innerHeight;
              var els=document.querySelectorAll('div,a,span,section,iframe');
              for(var i=0;i<els.length&&i<1500;i++){
                var el=els[i];
                var cs=getComputedStyle(el);
                if(cs.position!=='fixed'&&cs.position!=='absolute')continue;
                var z=parseInt(cs.zIndex,10);if(!(z>=1000))continue;
                var r=el.getBoundingClientRect();
                if(r.width<vw*0.7||r.height<vh*0.7)continue;
                var txt=(el.innerText||'').trim();
                var hasMedia=el.querySelector('video,audio,canvas,input,button,form,img,svg');
                var op=parseFloat(cs.opacity);
                var transparent=op<0.15||cs.backgroundColor==='rgba(0, 0, 0, 0)'||cs.backgroundColor==='transparent';
                if(txt.length<40&&!hasMedia&&transparent){el.remove();}
                else if(el.tagName==='IFRAME'&&transparent&&!el.src){el.remove();}
              }
              if(document.body&&getComputedStyle(document.body).overflow==='hidden'&&!document.querySelector('[role=dialog],.modal,[class*=cookie],[id*=cookie]')){document.body.style.overflow='auto'}
            }catch(e){}
          }
          window.__seoOverlayTimer=setInterval(sweep,1500);sweep();
        })();
    """.trimIndent()
}
