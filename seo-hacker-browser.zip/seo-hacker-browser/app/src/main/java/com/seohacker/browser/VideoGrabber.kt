package com.seohacker.browser

import android.app.Dialog
import android.content.ClipboardManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.View
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONTokener
import java.net.URI
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class Cand(val url: String, val kind: String, val headers: MutableMap<String, String>) {
    @Volatile var ok = true
    @Volatile var sub = false
    @Volatile var single = false
    @Volatile var duration = 0.0
    @Volatile var size = 0L
    @Volatile var segCount = 0
    @Volatile var err = ""
    var variants: List<HlsVariant> = emptyList()
    var audioUris: Map<String, String> = emptyMap()
}

/** Finds video streams on the page (HLS playlists and video files) and starts full downloads. */
class VideoGrabber(
    private val act: AppCompatActivity,
    private val cur: () -> WebView?,
    private val onChange: () -> Unit
) {
    private val state = HashMap<WebView, MutableList<Cand>>()
    private val main = Handler(Looper.getMainLooper())
    private val probePool = Executors.newFixedThreadPool(6)
    private val fileRe = Regex("(\\.(mp4|webm|mkv|mov|m4v|3gp|avi|flv|wmv)(\\?|#|$))|(videoplayback)|(/get_video)|([?&]mime=video)", RegexOption.IGNORE_CASE)
    private val hlsRe = Regex("\\.m3u8(\\?|#|$)", RegexOption.IGNORE_CASE)

    private fun dp(n: Int) = (n * act.resources.displayMetrics.density).toInt()
    private fun toast(m: String) = Toast.makeText(act, m, Toast.LENGTH_LONG).show()

    /** Called from WebView's background thread for every request. */
    fun onRequest(v: WebView, r: WebResourceRequest) {
        val u = r.url.toString()
        if (!u.startsWith("http")) return
        val isHls = hlsRe.containsMatchIn(u)
        val isFile = !isHls && fileRe.containsMatchIn(u)
        if (!isHls && !isFile) return
        val h = LinkedHashMap<String, String>()
        val rh = r.requestHeaders
        if (rh != null) {
            for ((k, value) in rh) {
                if (k.equals("referer", true) || k.equals("origin", true) || k.equals("user-agent", true) || k.equals("accept-language", true)) h[k] = value
            }
        }
        if (h.keys.none { it.equals("referer", true) }) {
            val p = v.tag as? String
            if (!p.isNullOrBlank() && p.startsWith("http")) h["Referer"] = p
        }
        var added = false
        synchronized(state) {
            val l = state.getOrPut(v) { ArrayList() }
            if (l.none { it.url == u }) {
                l.add(Cand(u, if (isHls) "hls" else "file", h))
                while (l.size > 25) l.removeAt(0)
                added = true
            }
        }
        if (added) main.post { onChange() }
    }

    fun reset(v: WebView) {
        synchronized(state) { state.remove(v) }
        main.post { onChange() }
    }

    fun hasAny(): Boolean {
        val v = cur() ?: return false
        return synchronized(state) { state[v]?.isNotEmpty() == true }
    }

    /** Opens the "choose video" dialog. extra = a src given by the page button (may be blob:). */
    fun open(extra: String?, title: String?) {
        val v = cur() ?: return
        val page = v.url ?: ""
        val pageTitle = (title ?: v.title ?: "video")
        val js = "(function(){return JSON.stringify(Array.from(document.querySelectorAll('video')).map(function(x){var s=x.querySelector('source');return x.currentSrc||x.src||(s?s.src:'')}).filter(Boolean));})()"
        v.evaluateJavascript(js) { raw ->
            val found = ArrayList<String>()
            if (!extra.isNullOrBlank()) found.add(extra)
            try {
                val arr = JSONArray(JSONTokener(raw).nextValue() as String)
                for (i in 0 until arr.length()) found.add(arr.getString(i))
            } catch (e: Exception) { }
            val ua = v.settings.userAgentString ?: Net.UA
            val base = ArrayList<Cand>()
            synchronized(state) { state[v]?.let { base.addAll(it) } }
            startProbe(base, found, pageTitle, page, ua)
        }
    }

    fun pasteLink() {
        val f = FormDialog(act, "Paste video link", "Paste an .m3u8 stream link or a direct video link.")
        val et = EditText(act)
        et.hint = "https://..."
        et.setHintTextColor(act.getColor(R.color.secondary))
        et.setTextColor(act.getColor(R.color.text))
        et.textSize = 14f
        et.setBackgroundResource(R.drawable.bg_input)
        et.setSingleLine(true)
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        et.setPadding(dp(14), 0, dp(14), 0)
        try {
            val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip?.getItemAt(0)?.text?.toString()?.trim()
            if (clip != null && clip.startsWith("http")) et.setText(clip)
        } catch (e: Exception) { }
        f.custom(et)
        f.button("Cancel")
        f.button("Check", primary = true) {
            val u = et.text.toString().trim()
            if (u.startsWith("http")) {
                val v = cur()
                startProbe(ArrayList(), listOf(u), v?.title ?: "video", v?.url ?: "", v?.settings?.userAgentString ?: Net.UA)
            } else toast("Please paste a valid http link.")
        }
        f.show()
    }

    private fun startProbe(base: List<Cand>, urls: List<String>, title: String, page: String, ua: String) {
        val list = ArrayList<Cand>(base)
        for (u in urls) {
            if (!u.startsWith("http")) continue
            if (list.any { it.url == u }) continue
            val h = LinkedHashMap<String, String>()
            if (page.startsWith("http")) h["Referer"] = page
            list.add(Cand(u, if (hlsRe.containsMatchIn(u)) "hls" else "file", h))
        }
        if (list.isEmpty()) {
            toast("No video found yet. Press play on the video, wait a few seconds, then tap download again.")
            return
        }
        for (c in list) {
            if (c.headers.keys.none { it.equals("user-agent", true) }) c.headers["User-Agent"] = ua
        }
        val ld = FormDialog(act, "Checking videos...", "Finding the full video. This takes a few seconds.")
        ld.custom(ProgressBar(act))
        val dlg: Dialog = ld.show()
        Thread {
            try {
                val calls = list.map { c -> Callable<Unit> { probe(c) } }
                probePool.invokeAll(calls, 25, TimeUnit.SECONDS)
            } catch (e: Exception) { }
            main.post {
                try { dlg.dismiss() } catch (e: Exception) { }
                val good = list.filter { it.ok && !it.sub }
                if (good.isEmpty()) {
                    val why = list.firstOrNull { it.err.isNotEmpty() }?.err
                    toast("Could not read the video link" + (if (why != null) " ($why)" else "") + ". Play the video again and retry.")
                } else showChooser(good, title)
            }
        }.start()
    }

    private fun probe(c: Cand) {
        try {
            if (c.kind == "hls") {
                val text = String(Net.bytes(c.url, c.headers), Charsets.UTF_8)
                if (!text.contains("#EXTM3U")) {
                    c.ok = false
                    return
                }
                if (Hls.isMaster(text)) {
                    val m = Hls.master(text, c.url)
                    if (m.variants.isEmpty()) {
                        c.ok = false
                        return
                    }
                    c.variants = m.variants.sortedByDescending { it.bw }
                    c.audioUris = m.audioUris
                    val mt = String(Net.bytes(c.variants[0].url, c.headers), Charsets.UTF_8)
                    val md = Hls.media(mt, c.variants[0].url)
                    c.duration = md.duration()
                    c.segCount = md.segs.size
                } else {
                    val md = Hls.media(text, c.url)
                    if (md.segs.isEmpty()) {
                        c.ok = false
                        return
                    }
                    val first = md.segs[0].url.substringBefore('?').lowercase()
                    if (first.endsWith(".vtt") || first.endsWith(".srt") || first.endsWith(".webvtt")) {
                        c.sub = true
                        return
                    }
                    c.duration = md.duration()
                    c.segCount = md.segs.size
                    c.single = true
                }
            } else {
                val conn = Net.open(c.url, c.headers, 0L, 1L)
                try {
                    val cr = conn.getHeaderField("Content-Range")
                    var size = -1L
                    if (cr != null && cr.contains("/")) size = cr.substringAfter("/").trim().toLongOrNull() ?: -1L
                    if (size <= 0L) size = conn.contentLengthLong
                    c.size = if (size > 0L) size else 0L
                } finally {
                    conn.disconnect()
                }
                if (c.size in 1L..800000L) c.ok = false
            }
        } catch (e: Exception) {
            c.ok = false
            c.err = e.message ?: "error"
        }
    }

    private fun score(c: Cand): Double = if (c.duration > 0.0) c.duration else c.size / 250000.0

    private fun card(title: String, sub: String, tag: String?, onClick: () -> Unit): View {
        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL
        box.setBackgroundResource(R.drawable.bg_card)
        box.setPadding(dp(14), dp(12), dp(14), dp(12))
        if (tag != null) {
            val t = TextView(act)
            t.text = tag
            t.textSize = 11.5f
            t.setTextColor(act.getColor(R.color.accent))
            t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
            box.addView(t)
        }
        val a = TextView(act)
        a.text = title
        a.textSize = 15.5f
        a.setTextColor(act.getColor(R.color.text))
        box.addView(a)
        val b = TextView(act)
        b.text = sub
        b.textSize = 12f
        b.maxLines = 2
        b.setTextColor(act.getColor(R.color.secondary))
        box.addView(b)
        box.setOnClickListener { onClick() }
        return box
    }

    private fun host(u: String): String = try { URI(u).host ?: "" } catch (e: Exception) { "" }

    private fun showChooser(list: List<Cand>, title: String) {
        if (act.isFinishing) return
        val sorted = list.sortedByDescending { score(it) }
        val f = FormDialog(act, "Download video", "Pick the full video. Short ones are usually ads or previews.")
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        sorted.forEachIndexed { i, c ->
            val head = when {
                c.duration > 0.0 -> "Length " + Fmt.dur(c.duration)
                c.size > 0L -> Fmt.size(c.size)
                else -> "Video (length unknown)"
            }
            val detail = if (c.kind == "hls") {
                if (c.variants.size > 1) "Stream  -  " + c.variants.joinToString(", ") { Hls.qLabel(it) }.take(60)
                else "Stream  -  " + c.segCount + " parts"
            } else "Video file  -  " + (if (c.size > 0L) Fmt.size(c.size) else "size unknown")
            val v = card(head, detail + "  -  " + host(c.url), if (i == 0 && sorted.size > 1) "RECOMMENDED (longest)" else null) {
                f.dialog.dismiss()
                if (c.kind == "hls") chooseQuality(c, title) else startFile(c, title)
            }
            col.addView(v, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
        val sv = ScrollView(act)
        sv.addView(col)
        f.custom(sv, minOf(sorted.size * dp(86), (act.resources.displayMetrics.heightPixels * 0.5f).toInt()))
        f.button("Cancel")
        f.show()
    }

    private fun chooseQuality(c: Cand, title: String) {
        if (c.variants.size <= 1) {
            startHls(c, c.variants.firstOrNull(), title)
            return
        }
        val f = FormDialog(act, "Choose quality", "Higher quality means a bigger file.")
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        c.variants.forEachIndexed { i, v ->
            val est = if (v.bw > 0L && c.duration > 0.0) "  -  about " + Fmt.size((v.bw * c.duration / 8.0).toLong()) else ""
            val kb = if (v.bw > 0L) (v.bw / 1000).toString() + " kbps" else ""
            val cv = card(Hls.qLabel(v) + est, kb, if (i == 0) "BEST QUALITY" else null) {
                f.dialog.dismiss()
                startHls(c, v, title)
            }
            col.addView(cv, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
        val sv = ScrollView(act)
        sv.addView(col)
        f.custom(sv, minOf(c.variants.size * dp(86), (act.resources.displayMetrics.heightPixels * 0.5f).toInt()))
        f.button("Cancel")
        f.show()
    }

    private fun startHls(c: Cand, v: HlsVariant?, title: String) {
        val url = v?.url ?: c.url
        val audio = if (v != null && v.audio.isNotEmpty()) (c.audioUris[v.audio] ?: "") else ""
        val q = if (v != null) Hls.qLabel(v) else ""
        DlManager.start(act, title, url, c.headers, "hls", audio, q)
        toast("Download started. See progress: sidebar > Video downloads")
    }

    private fun startFile(c: Cand, title: String) {
        DlManager.start(act, title, c.url, c.headers, "file", "", "")
        toast("Download started. See progress: sidebar > Video downloads")
    }
}
