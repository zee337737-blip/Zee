package com.seohacker.browser

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import java.io.ByteArrayOutputStream
import java.util.Locale

data class Chip(val label: String, val value: String, val color: Int)
data class SheetTable(
    val title: String,
    val headers: List<String>,
    val widths: List<Float>,
    val rows: List<List<String>>,
    val colorCols: Set<Int> = emptySet()
)
data class PdfDoc(val title: String, val subtitle: String, val chips: List<Chip>, val tables: List<SheetTable>)

/** Builds a landscape, spreadsheet-style PDF (header row, grid lines, zebra rows, coloured status cells). */
object PdfReport {
    private const val PW = 842
    private const val PH = 595
    private const val M = 28f
    private const val PAD = 5f

    fun build(doc: PdfDoc): ByteArray {
        val w = Writer(doc.title)
        w.start(doc)
        doc.tables.filter { it.rows.isNotEmpty() }.forEach { w.table(it) }
        return w.finish()
    }

    private class Writer(val docTitle: String) {
        val pdf = PdfDocument()
        var page: PdfDocument.Page? = null
        lateinit var c: Canvas
        var y = 0f
        var n = 0

        val text = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 9f; color = Color.parseColor("#0F172A") }
        val bold = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 9f; color = Color.parseColor("#0F172A"); typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val headP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 9.5f; color = Color.WHITE; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        val grid = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 0.6f; color = Color.parseColor("#CBD5E1") }

        fun newPage() {
            closePage()
            n++
            val p = pdf.startPage(PdfDocument.PageInfo.Builder(PW, PH, n).create())
            page = p
            c = p.canvas
            y = M
        }

        private fun closePage() {
            val p = page ?: return
            val f = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 8f; color = Color.parseColor("#64748B") }
            c.drawText(docTitle.take(70) + "   |   Page " + n, M, PH - 14f, f)
            pdf.finishPage(p)
            page = null
        }

        fun finish(): ByteArray {
            closePage()
            val out = ByteArrayOutputStream()
            pdf.writeTo(out)
            pdf.close()
            return out.toByteArray()
        }

        private fun lay(s: String, p: TextPaint, w: Int): StaticLayout {
            val t = if (s.isBlank()) "-" else s
            return StaticLayout.Builder.obtain(t, 0, t.length, p, maxOf(w, 20))
                .setMaxLines(40).setEllipsize(TextUtils.TruncateAt.END).setLineSpacing(1.5f, 1f).build()
        }

        private fun draw(l: StaticLayout, x: Float, top: Float) {
            c.save(); c.translate(x, top); l.draw(c); c.restore()
        }

        private fun tone(s: String): Pair<Int, Int>? {
            val v = s.lowercase(Locale.ROOT)
            return when {
                v.contains("issue") || v.contains("high") || v.contains("critical") ->
                    Pair(Color.parseColor("#FEE2E2"), Color.parseColor("#B91C1C"))
                v.contains("warn") || v.contains("medium") ->
                    Pair(Color.parseColor("#FEF3C7"), Color.parseColor("#B45309"))
                v.contains("good") || v.contains("low") || v.contains("pass") ->
                    Pair(Color.parseColor("#DCFCE7"), Color.parseColor("#15803D"))
                else -> null
            }
        }

        fun start(doc: PdfDoc) {
            newPage()
            fill.color = Color.parseColor("#1E3A8A")
            c.drawRect(0f, 0f, PW.toFloat(), 66f, fill)
            val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 20f; color = Color.WHITE; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            c.drawText(TextUtils.ellipsize(doc.title, tp, PW - 2 * M, TextUtils.TruncateAt.END).toString(), M, 31f, tp)
            val sp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 9.5f; color = Color.parseColor("#BFDBFE") }
            c.drawText(TextUtils.ellipsize(doc.subtitle, sp, PW - 2 * M, TextUtils.TruncateAt.END).toString(), M, 50f, sp)
            y = 82f
            if (doc.chips.isNotEmpty()) {
                var x = M
                val lp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 8.5f; color = Color.WHITE }
                val vp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                    textSize = 16f; color = Color.WHITE; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                }
                doc.chips.forEach { ch ->
                    fill.color = ch.color
                    c.drawRoundRect(RectF(x, y, x + 130f, y + 42f), 8f, 8f, fill)
                    c.drawText(ch.label, x + 10f, y + 15f, lp)
                    c.drawText(ch.value, x + 10f, y + 35f, vp)
                    x += 142f
                }
                y += 58f
            }
        }

        private fun header(t: SheetTable, cw: List<Float>) {
            val ls = t.headers.mapIndexed { ci, h -> lay(h, headP, (cw[ci] - 2 * PAD).toInt()) }
            val h = ls.maxOf { it.height } + 2 * PAD
            var x = M
            for (ci in t.headers.indices) {
                fill.color = Color.parseColor("#334155")
                c.drawRect(x, y, x + cw[ci], y + h, fill)
                c.drawRect(x, y, x + cw[ci], y + h, grid)
                draw(ls[ci], x + PAD, y + PAD)
                x += cw[ci]
            }
            y += h
        }

        fun table(t: SheetTable) {
            val total = PW - 2 * M
            val sum = t.widths.sum()
            val cw = t.widths.map { it / sum * total }
            val cols = t.headers.size
            if (y + 80f > PH - 30f) newPage()
            fill.color = Color.parseColor("#DBEAFE")
            c.drawRect(M, y, M + total, y + 22f, fill)
            val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 11f; color = Color.parseColor("#1E3A8A"); typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            c.drawText(t.title, M + 6f, y + 15f, tp)
            y += 22f
            header(t, cw)
            t.rows.forEachIndexed { i, r ->
                val tones = (0 until cols).map { ci -> if (ci in t.colorCols) tone(r.getOrElse(ci) { "" }) else null }
                val ls = (0 until cols).map { ci ->
                    val tn = tones[ci]
                    val p = if (tn != null) TextPaint(bold).apply { color = tn.second } else text
                    lay(r.getOrElse(ci) { "" }, p, (cw[ci] - 2 * PAD).toInt())
                }
                val h = ls.maxOf { it.height } + 2 * PAD
                if (y + h > PH - 30f) { newPage(); header(t, cw) }
                var x = M
                for (ci in 0 until cols) {
                    val tn = tones[ci]
                    fill.color = tn?.first ?: (if (i % 2 == 0) Color.WHITE else Color.parseColor("#F8FAFC"))
                    c.drawRect(x, y, x + cw[ci], y + h, fill)
                    c.drawRect(x, y, x + cw[ci], y + h, grid)
                    draw(ls[ci], x + PAD, y + PAD)
                    x += cw[ci]
                }
                y += h
            }
            y += 20f
        }
    }
}
