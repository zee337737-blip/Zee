package com.seohacker.browser

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class HistoryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_history)
        val list=findViewById<ListView>(R.id.historyList); val clear=findViewById<Button>(R.id.clearHistoryButton)
        fun refresh(){
            val items=HistoryStore.all(this)
            list.adapter=RowAdapter(this,items.map{it.title.ifBlank{it.url} to it.url})
            list.setOnItemClickListener{_,_,pos,_-> val u=items[pos].url; startActivity(Intent(this,MainActivity::class.java).apply{
                flags=Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP; data=android.net.Uri.parse(u)
            }); finish() }
        }
        clear.setOnClickListener{HistoryStore.clear(this);refresh()}; refresh()
    }
}
