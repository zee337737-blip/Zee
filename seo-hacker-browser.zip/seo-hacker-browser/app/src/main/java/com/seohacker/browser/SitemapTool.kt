package com.seohacker.browser

import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.GZIPInputStream

/** Readable sitemap / robots.txt / canonical reports (instead of dumping raw XML). */
object SitemapTool {
    private class Resp(val code: Int, val type: String, val text: String)

    private fun get(url: String): Resp {
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 10000; c.readTimeout = 15000; c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", Net.UA)
            c.setRequestProperty("Accept", "application/xml,text/xml,text/plain,*/*;q=0.8")
            val ck = android.webkit.CookieManager.getInstance().getCookie(url)
            if (!ck.isNullOrBlank()) c.setRequestProperty("Cookie", ck)
            val code = c.responseCode
            val type = (c.contentType ?: "").lowercase()
            val raw = if (code in 200..299) c.inputStream else c.errorStream
            val text = if (raw == null) "" else {
                val st = if (url.endsWith(".gz")) GZIPInputStream(raw) else raw
                st.bufferedReader().use { it.readText().take(3_000_000) }
            }
            Resp(code, type, text)
        } catch (e: Exception) { Resp(-1, "", e.message ?: "error") }
    }

    private fun origin(page: String): String { val u = URL(page); return u.protocol + "://" + u.host + (if (u.port > 0 && u.port != u.defaultPort) ":" + u.port else "") }
    private fun norm(u: String) = u.trim().trimEnd('/').lowercase().removePrefix("https://").removePrefix("http://").removePrefix("www.")
    private val loc = Regex("<loc>\\s*(?:<!\\[CDATA\\[)?\\s*(.*?)\\s*(?:]]>)?\\s*</loc>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
    private val block = { tag: String -> Regex("<$tag>(.*?)</$tag>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)) }
    private val lastmod = Regex("<lastmod>\\s*(.*?)\\s*</lastmod>", RegexOption.IGNORE_CASE)

    private class Parsed(val isIndex: Boolean, val entries: List<Pair<String, String>>)

    private fun parse(xml: String): Parsed? {
        val isIndex = xml.contains("<sitemapindex", true)
        if (!isIndex && !xml.contains("<urlset", true)) return null
        val tag = if (isIndex) "sitemap" else "url"
        val list = block(tag).findAll(xml).mapNotNull { m ->
            val u = loc.find(m.groupValues[1])?.groupValues?.get(1) ?: return@mapNotNull null
            u to (lastmod.find(m.groupValues[1])?.groupValues?.get(1) ?: "")
        }.toList()
        return Parsed(isIndex, list)
    }

    /** Full sitemap report for the site of pageUrl. canonical = the canonical found on the current page (may be blank). */
    fun sitemapReport(pageUrl: String, canonical: String): List<Section> {
        val base = origin(pageUrl)
        val out = mutableListOf<Section>()
        val robots = get("$base/robots.txt")
        val declared = if (robots.code == 200) Regex("(?im)^\\s*sitemap\\s*:\\s*(\\S+)").findAll(robots.text).map { it.groupValues[1] }.toList() else emptyList()
        val guesses = listOf("/sitemap.xml", "/sitemap_index.xml", "/wp-sitemap.xml", "/sitemap-index.xml", "/sitemaps.xml", "/post-sitemap.xml", "/page-sitemap.xml", "/sitemap.xml.gz")
            .map { base + it }.filter { g -> declared.none { norm(it) == norm(g) } }
        val found = mutableListOf<Triple<String, Parsed, Boolean>>() // url, parsed, declaredInRobots
        val tried = mutableListOf<Row>()
        for (u in declared) {
            val r = get(u); val p = if (r.code == 200) parse(r.text) else null
            if (p != null) found += Triple(u, p, true) else tried += Row(u, if (r.code == 200) "Opened but is not a valid sitemap" else "Not reachable (HTTP ${r.code})", Status.BAD)
        }
        if (found.isEmpty()) for (u in guesses) {
            val r = get(u); val p = if (r.code == 200) parse(r.text) else null
            if (p != null) { found += Triple(u, p, false); break }
        }

        // ---- which URL list belongs to the current page
        val pageKey = norm(pageUrl.substringBefore('#'))
        val canKey = if (canonical.isNotBlank()) norm(canonical) else ""
        var pageInSitemap: String? = null
        var totalUrls = 0
        val sections = mutableListOf<Section>()
        for ((u, p, dec) in found) {
            val rows = mutableListOf<Row>()
            rows += Row("Address", u, Status.INFO, true)
            rows += Row("Type", if (p.isIndex) "Sitemap INDEX (a list of other sitemaps)" else "URL sitemap (a list of pages)", Status.INFO)
            rows += Row("Declared in robots.txt", if (dec) "Yes" else "No (found at a standard location)", if (dec) Status.GOOD else Status.WARN)
            if (p.isIndex) {
                rows += Row("Child sitemaps", p.entries.size.toString(), Status.INFO)
                p.entries.take(40).forEach { (cu, lm) -> rows += Row(cu.substringAfterLast('/'), cu + (if (lm.isNotBlank()) "\nUpdated: $lm" else ""), Status.INFO, true) }
                sections += Section("Sitemap index", rows)
                // look inside the first few children
                for ((cu, _) in p.entries.take(4)) {
                    val r = get(cu); val cp = if (r.code == 200) parse(r.text) else null
                    if (cp == null) { sections += Section(cu.substringAfterLast('/'), listOf(Row("Address", cu, Status.INFO, true), Row("Status", "Could not be read (HTTP ${r.code})", Status.BAD))); continue }
                    totalUrls += cp.entries.size
                    if (cp.entries.any { norm(it.first) == pageKey || (canKey.isNotEmpty() && norm(it.first) == canKey) }) pageInSitemap = cu
                    sections += urlSection(cu.substringAfterLast('/'), cu, cp)
                }
                if (p.entries.size > 4) sections += Section("Note", listOf(Row("", "Only the first 4 child sitemaps were opened to keep this fast. Open the other child addresses above in a tab to inspect them.")))
            } else {
                totalUrls += p.entries.size
                if (p.entries.any { norm(it.first) == pageKey || (canKey.isNotEmpty() && norm(it.first) == canKey) }) pageInSitemap = u
                sections += urlSection("URL sitemap", u, p, rows)
            }
        }

        // ---- summary on top
        val sum = mutableListOf<Row>()
        sum += Row("Website", base, Status.INFO, true)
        sum += Row("robots.txt", if (robots.code == 200) "Found" else "Not found (HTTP ${robots.code})", if (robots.code == 200) Status.GOOD else Status.WARN)
        sum += Row("Sitemap in robots.txt", if (declared.isEmpty()) "No Sitemap: line" else declared.joinToString("\n"), if (declared.isEmpty()) Status.WARN else Status.GOOD, declared.isNotEmpty())
        sum += Row("Sitemap found", if (found.isEmpty()) "No valid sitemap found" else found.joinToString("\n") { it.first }, if (found.isEmpty()) Status.BAD else Status.GOOD, found.isNotEmpty())
        if (totalUrls > 0) sum += Row("URLs read", totalUrls.toString(), Status.INFO)
        sum += Row("Current page", pageUrl, Status.INFO, true)
        sum += when {
            found.isEmpty() -> Row("Current page in sitemap?", "Cannot check - no sitemap", Status.WARN)
            pageInSitemap != null -> Row("Current page in sitemap?", "Yes - listed in " + pageInSitemap.substringAfterLast('/'), Status.GOOD)
            else -> Row("Current page in sitemap?", "Not found in the sitemap parts that were opened", Status.WARN)
        }
        out += Section("Sitemap Summary", sum)
        out += canonicalSection(pageUrl, canonical)
        if (tried.isNotEmpty()) out += Section("Declared but failed", tried)
        out += sections
        return out
    }

    private fun urlSection(title: String, addr: String, p: Parsed, pre: List<Row> = emptyList()): Section {
        val rows = pre.toMutableList()
        if (pre.isEmpty()) rows += Row("Address", addr, Status.INFO, true)
        rows += Row("Total URLs", p.entries.size.toString(), if (p.entries.isEmpty()) Status.BAD else Status.GOOD)
        val withMod = p.entries.count { it.second.isNotBlank() }
        rows += Row("URLs with lastmod date", "$withMod of ${p.entries.size}", if (withMod == 0) Status.WARN else Status.GOOD)
        if (p.entries.size > 50000) rows += Row("Size", "Over 50,000 URLs - split this sitemap", Status.WARN)
        p.entries.take(15).forEachIndexed { i, (u, lm) -> rows += Row("${i + 1}.", u + (if (lm.isNotBlank()) "\nUpdated: $lm" else ""), Status.INFO, true) }
        if (p.entries.size > 15) rows += Row("", "... and ${p.entries.size - 15} more", Status.INFO)
        return Section(title, rows)
    }

    fun canonicalSection(pageUrl: String, canonical: String): Section {
        val rows = mutableListOf<Row>()
        rows += Row("Current URL", pageUrl, Status.INFO, true)
        if (canonical.isBlank()) {
            rows += Row("Canonical URL", "Not set on this page", Status.WARN)
            rows += Row("What to do", "Add <link rel=\"canonical\" href=\"...\"> in the <head> pointing to the preferred version of this page.")
        } else {
            rows += Row("Canonical URL", canonical, Status.GOOD, true)
            val same = norm(canonical) == norm(pageUrl.substringBefore('#').substringBefore('?')) || norm(canonical) == norm(pageUrl.substringBefore('#'))
            rows += Row("Matches current URL?", if (same) "Yes - this page is its own canonical (self-referencing)" else "No - this page tells Google that another URL is the main version", if (same) Status.GOOD else Status.WARN)
            if (canonical.startsWith("http://") && pageUrl.startsWith("https://")) rows += Row("Protocol", "Canonical uses http but page is https", Status.WARN)
        }
        return Section("Canonical", rows)
    }

    fun robotsReport(pageUrl: String): List<Section> {
        val base = origin(pageUrl)
        val r = get("$base/robots.txt")
        if (r.code != 200 || r.type.contains("html") && r.text.contains("<html", true)) {
            return listOf(Section("robots.txt", listOf(Row("Address", "$base/robots.txt", Status.INFO, true), Row("Status", "Not found (HTTP ${r.code})", Status.WARN),
                Row("Meaning", "Without robots.txt search engines crawl everything. It is recommended to add one."))))
        }
        class G(val agents: MutableList<String> = mutableListOf(), val dis: MutableList<String> = mutableListOf(), val alw: MutableList<String> = mutableListOf(), var delay: String = "")
        val groups = mutableListOf<G>(); val maps = mutableListOf<String>(); var cur: G? = null; var lastWasAgent = false
        for (raw in r.text.lines()) {
            val line = raw.substringBefore('#').trim(); if (line.isEmpty() || !line.contains(':')) continue
            val k = line.substringBefore(':').trim().lowercase(); val v = line.substringAfter(':').trim()
            when (k) {
                "user-agent" -> { if (!lastWasAgent || cur == null) { cur = G(); groups += cur }; cur!!.agents += v; lastWasAgent = true }
                "disallow" -> { cur?.dis?.add(v); lastWasAgent = false }
                "allow" -> { cur?.alw?.add(v); lastWasAgent = false }
                "crawl-delay" -> { cur?.delay = v; lastWasAgent = false }
                "sitemap" -> maps += v
            }
        }
        val out = mutableListOf<Section>()
        val blocksAll = groups.any { g -> g.agents.contains("*") && g.dis.contains("/") }
        out += Section("robots.txt Summary", listOf(
            Row("Address", "$base/robots.txt", Status.INFO, true),
            Row("Rule groups", groups.size.toString()),
            Row("Whole site blocked?", if (blocksAll) "YES - Disallow: / for all bots" else "No", if (blocksAll) Status.BAD else Status.GOOD),
            Row("Sitemap lines", if (maps.isEmpty()) "None - add a Sitemap: line" else maps.joinToString("\n"), if (maps.isEmpty()) Status.WARN else Status.GOOD, maps.isNotEmpty())))
        groups.forEach { g ->
            val rows = mutableListOf<Row>()
            if (g.dis.isNotEmpty()) rows += Row("Disallow (${g.dis.size})", g.dis.joinToString("\n") { it.ifEmpty { "(nothing blocked)" } }, Status.WARN, true)
            if (g.alw.isNotEmpty()) rows += Row("Allow (${g.alw.size})", g.alw.joinToString("\n"), Status.GOOD, true)
            if (g.delay.isNotBlank()) rows += Row("Crawl-delay", g.delay)
            if (rows.isEmpty()) rows += Row("", "No rules")
            out += Section("Bot: " + g.agents.joinToString(", "), rows)
        }
        return out
    }
}
