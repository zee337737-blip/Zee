package com.seohacker.browser

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class PlanningHubActivity : AppCompatActivity() {
    private lateinit var panel: SidePanel
    private lateinit var chatList: LinearLayout
    private lateinit var chatScroll: ScrollView
    private lateinit var chatInput: EditText
    private lateinit var sendButton: Button
    private lateinit var pages: List<View>
    private lateinit var tabs: List<TextView>
    private lateinit var reportList: ListView
    private lateinit var finalList: ListView
    private val exec = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("planning", MODE_PRIVATE) }
    private val pageText = HashMap<String, String>()
    private var msgs = mutableListOf<Msg>()
    private var chatId = ChatStore.newId()
    private var busy = false

    private val systemPrompt = "You are an expert SEO consultant inside an SEO browser app. " +
        "The user may write in Roman Urdu, Urdu or English: always reply in the same language and style the user writes in. " +
        "Analyse the user's saved SEO reports and page extracts below. Point out weak points, explain how to fix each one step by step, " +
        "and suggest a better strategy. Be concrete, prioritise by impact, and keep answers well structured with short headings and bullet points. " +
        "Never invent data that is not in the reports; if data is missing, tell the user which report to run in the browser. " +
        "Only suggest free methods and free tools."

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_planning)
        panel = SidePanel(findViewById(R.id.planningRoot))
        chatList = findViewById(R.id.chatList)
        chatScroll = findViewById(R.id.chatScroll)
        chatInput = findViewById(R.id.chatInput)
        sendButton = findViewById(R.id.sendButton)
        reportList = findViewById(R.id.reportList)
        finalList = findViewById(R.id.finalList)
        pages = listOf<View>(findViewById<View>(R.id.chatPage), findViewById<View>(R.id.reportsPage), findViewById<View>(R.id.finalPage))
        tabs = listOf<TextView>(findViewById<TextView>(R.id.tabChat), findViewById<TextView>(R.id.tabReports), findViewById<TextView>(R.id.tabFinal))
        tabs.forEachIndexed { i, t -> t.setOnClickListener { selectTab(i) } }
        findViewById<Button>(R.id.planningSettingsButton).setOnClickListener { settings() }
        findViewById<Button>(R.id.hubHistoryButton).setOnClickListener { history() }
        findViewById<Button>(R.id.hubNewButton).setOnClickListener { newChat() }
        findViewById<Button>(R.id.importCsvButton).setOnClickListener { importCsv() }
        findViewById<Button>(R.id.makeFinalButton).setOnClickListener { makeFinal() }
        sendButton.setOnClickListener { send(chatInput.text.toString()) }
        buildChips()
        selectTab(0)
        val last = ChatStore.latestId()
        if (last != null) loadChat(last) else greet()
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun toast(m: String?) = Toast.makeText(this, m ?: "Something went wrong.", Toast.LENGTH_LONG).show()
    private fun date(ts: Long) = SimpleDateFormat("dd MMM, HH:mm", Locale.US).format(Date(ts))

    // ---------- storage ----------
    private fun reports(): JSONArray = JSONArray(prefs.getString("reports", "[]"))
    private fun saveReports(a: JSONArray) { prefs.edit().putString("reports", a.toString()).apply() }
    private fun finals(): JSONArray = JSONArray(prefs.getString("finals", "[]"))
    private fun saveFinals(a: JSONArray) { prefs.edit().putString("finals", a.toString()).apply() }

    private fun removeAt(a: JSONArray, index: Int): JSONArray {
        val n = JSONArray()
        for (i in 0 until a.length()) if (i != index) n.put(a.get(i))
        return n
    }

    // ---------- tabs ----------
    private fun selectTab(i: Int) {
        pages.forEachIndexed { k, p -> p.visibility = if (k == i) View.VISIBLE else View.GONE }
        tabs.forEachIndexed { k, t ->
            t.setTextColor(getColor(if (k == i) R.color.accent else R.color.secondary))
            t.setTypeface(null, if (k == i) Typeface.BOLD else Typeface.NORMAL)
            if (k == i) t.setBackgroundResource(R.drawable.bg_tab_on) else t.setBackgroundResource(0)
        }
        if (i == 1) refreshReports()
        if (i == 2) refreshFinals()
    }

    // ---------- chat ----------
    private fun buildChips() {
        val box = findViewById<LinearLayout>(R.id.chipBox)
        val chips = listOf(
            "Analyse my reports" to "Analyse all my saved reports. Give a clear summary of what is good and what is weak.",
            "Find weak points" to "List every weak point you can find in my reports, one by one, with the exact fix for each.",
            "How to improve?" to "How can I improve this website's SEO further? Give a prioritised step-by-step plan.",
            "Keyword ideas" to "Suggest keyword opportunities based on my reports, grouped by search intent.",
            "Final PDF report" to "__FINAL__"
        )
        chips.forEach { (label, prompt) ->
            val tv = TextView(this)
            tv.text = label
            tv.textSize = 13f
            tv.setTextColor(getColor(R.color.text))
            tv.gravity = Gravity.CENTER
            tv.setBackgroundResource(R.drawable.bg_chip)
            tv.setPadding(dp(14), 0, dp(14), 0)
            tv.setOnClickListener { if (prompt == "__FINAL__") makeFinal() else send(prompt) }
            box.addView(tv, LinearLayout.LayoutParams(-2, dp(36)).apply { marginEnd = dp(8) })
        }
    }

    private fun greet() {
        val m = Msg("assistant", "Assalam o Alaikum! Main aapka SEO assistant hoon.\n\n" +
            "- **Reports** tab me jo reports aapne browser se bheji hain, main unka analysis kar sakta hoon.\n" +
            "- Mujhse weak points, unke hal, aur behtar strategy poochein. Baat kar ke hum plan ko aur behtar bana sakte hain.\n" +
            "- Jab tayyar ho to **Final PDF report** dabayein ya likhein \"pdf bana do\" - sheet jaisi report download ho jayegi.")
        chatList.addView(bubble(m, false))
    }

    private fun bubble(m: Msg, actions: Boolean = true): View {
        val user = m.role == "user"
        val wrap = LinearLayout(this)
        wrap.orientation = LinearLayout.VERTICAL
        wrap.gravity = if (user) Gravity.END else Gravity.START
        wrap.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
        val tv = TextView(this)
        tv.text = if (user) m.content else Md.render(m.content)
        tv.setTextColor(getColor(if (user) R.color.white else R.color.text))
        tv.textSize = 14.5f
        tv.setBackgroundResource(if (user) R.drawable.bg_bubble_user else R.drawable.bg_bubble_ai)
        tv.setPadding(dp(14), dp(10), dp(14), dp(10))
        tv.maxWidth = (resources.displayMetrics.widthPixels * 0.86f).toInt()
        tv.setTextIsSelectable(true)
        wrap.addView(tv, LinearLayout.LayoutParams(-2, -2))
        if (!user && actions) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            fun act(label: String, f: () -> Unit): TextView {
                val t = TextView(this)
                t.text = label
                t.textSize = 12.5f
                t.setTextColor(getColor(R.color.accent))
                t.setPadding(dp(6), dp(6), dp(14), dp(4))
                t.setOnClickListener { f() }
                return t
            }
            row.addView(act("Copy") { ReportBuilder.copy(this, "AI reply", m.content) })
            row.addView(act("Save PDF") { savePdf("AI_reply", ReportSheets.fromSections("AI answer", "", ReportBuilder.fromMarkdown(m.content))) })
            wrap.addView(row)
        }
        return wrap
    }

    private fun addBubble(m: Msg) {
        chatList.addView(bubble(m))
        scrollDown()
    }

    private fun scrollDown() { chatScroll.post { chatScroll.fullScroll(View.FOCUS_DOWN) } }

    private fun setBusy(b: Boolean) {
        busy = b
        sendButton.isEnabled = !b
        sendButton.alpha = if (b) 0.5f else 1f
    }

    private fun saveChat() { ChatStore.save(chatId, msgs) }

    private fun newChat() {
        if (busy) return
        panel.hide()
        chatId = ChatStore.newId()
        msgs = mutableListOf()
        chatList.removeAllViews()
        greet()
        selectTab(0)
    }

    private fun loadChat(id: String) {
        chatId = id
        msgs = ChatStore.load(id).toMutableList()
        chatList.removeAllViews()
        if (msgs.isEmpty()) greet() else msgs.forEach { chatList.addView(bubble(it)) }
        selectTab(0)
        scrollDown()
    }

    private fun trimHistory(list: List<Msg>, n: Int): List<Msg> = list.takeLast(n).dropWhile { it.role != "user" }

    private fun needKey(): Boolean {
        if (Prefs.cohereKey.isBlank()) {
            toast("Add your Cohere API key first.")
            settings()
            return true
        }
        return false
    }

    private fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || busy) return
        panel.hide()
        if (needKey()) return
        selectTab(0)
        val u = Msg("user", t)
        msgs.add(u)
        addBubble(u)
        chatInput.setText("")
        saveChat()
        val wantsPdf = Regex("pdf|final report", RegexOption.IGNORE_CASE).containsMatchIn(t)
        setBusy(true)
        val typing = TextView(this)
        typing.text = "AI is thinking..."
        typing.textSize = 13.5f
        typing.setTextColor(getColor(R.color.secondary))
        typing.setBackgroundResource(R.drawable.bg_bubble_ai)
        typing.setPadding(dp(14), dp(10), dp(14), dp(10))
        val typingWrap = LinearLayout(this)
        typingWrap.addView(typing, LinearLayout.LayoutParams(-2, -2))
        chatList.addView(typingWrap)
        scrollDown()
        val history = trimHistory(msgs, 20)
        exec.execute {
            val ctx = buildContext()
            val r = CohereClient.chat(Prefs.cohereKey, Prefs.cohereModel, listOf(Msg("system", systemPrompt + ctx)) + history)
            runOnUiThread {
                chatList.removeView(typingWrap)
                setBusy(false)
                r.onSuccess { txt ->
                    val a = Msg("assistant", txt)
                    msgs.add(a)
                    addBubble(a)
                    saveChat()
                    if (wantsPdf) makeFinal()
                }.onFailure { toast(it.message) }
            }
        }
    }

    /** Runs on the background thread: saved reports, page extracts and the latest final report draft. */
    private fun buildContext(): String {
        val a = reports()
        val sb = StringBuilder()
        if (a.length() == 0) {
            sb.append("\n\nNo reports have been sent to the Planning Hub yet. If you need data, ask the user to run a report in the browser and send it here.")
        } else {
            sb.append("\n\nSAVED SEO REPORTS (the user's data):\n")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val url = o.optString("url")
                sb.append("\n--- REPORT ").append(i + 1).append(": ").append(o.optString("title")).append(" | ").append(url).append("\n")
                sb.append(o.optString("report").take(5000)).append("\n")
                if (url.startsWith("http")) {
                    val pt = pageText.getOrPut(url) { runCatching { SeoAnalyzer.stripHtml(SeoAnalyzer.fetchText(url)) }.getOrDefault("") }
                    if (pt.isNotBlank()) sb.append("PAGE TEXT EXTRACT: ").append(pt.take(2500)).append("\n")
                }
            }
        }
        val f = finals()
        if (f.length() > 0) {
            runCatching {
                val o = JSONObject(f.getJSONObject(0).optString("data"))
                sb.append("\n\nLATEST FINAL REPORT DRAFT (the user may want to refine it):\n")
                sb.append(ReportBuilder.toText(FinalReport.title(o), FinalReport.toSections(o)).take(6000))
            }
        }
        return sb.toString().take(30000)
    }

    // ---------- history ----------
    private fun history() {
        val list = ChatStore.list()
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(10), dp(10), dp(10), dp(10))
        if (list.isEmpty()) {
            col.addView(TextView(this).apply {
                text = "No chats yet. Your AI conversations are saved here automatically."
                setTextColor(getColor(R.color.secondary)); textSize = 14f; setPadding(dp(6), dp(10), dp(6), dp(10))
            })
        }
        list.forEach { o ->
            val id = o.optString("id")
            val count = o.optJSONArray("m")?.length() ?: 0
            val card = LinearLayout(this)
            card.orientation = LinearLayout.HORIZONTAL
            card.gravity = Gravity.CENTER_VERTICAL
            card.setBackgroundResource(R.drawable.bg_card)
            card.setPadding(dp(14), dp(12), dp(8), dp(12))
            val left = LinearLayout(this)
            left.orientation = LinearLayout.VERTICAL
            left.addView(TextView(this).apply {
                text = o.optString("title").ifBlank { "Chat" }; textSize = 15f; setTextColor(getColor(R.color.text)); maxLines = 2
            })
            left.addView(TextView(this).apply {
                text = date(o.optLong("ts")) + "  |  " + count + " messages"; textSize = 12f; setTextColor(getColor(R.color.secondary))
            })
            left.setOnClickListener { panel.hide(); loadChat(id) }
            card.addView(left, LinearLayout.LayoutParams(0, -2, 1f))
            card.addView(TextView(this).apply {
                text = "Delete"; textSize = 12.5f; setTextColor(getColor(R.color.error)); setPadding(dp(12), dp(8), dp(10), dp(8))
                setOnClickListener {
                    ChatStore.delete(id)
                    if (id == chatId) newChat() else history()
                }
            })
            col.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
        panel.show("AI chat history", ScrollView(this).apply { addView(col) }, listOf(
            "New chat" to { newChat() },
            "Clear all" to { ChatStore.clear(); newChat() }
        ))
    }

    // ---------- reports tab ----------
    private fun refreshReports() {
        val a = reports()
        val rows = (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            o.optString("title") to o.optString("url")
        }
        reportList.adapter = RowAdapter(this, rows)
        reportList.setOnItemClickListener { _, _, p, _ -> showReport(a.getJSONObject(p)) }
        reportList.setOnItemLongClickListener { _, _, p, _ ->
            val f = FormDialog(this, "Remove report?", rows[p].first)
            f.button("Cancel")
            f.button("Remove", primary = true) { saveReports(removeAt(a, p)); refreshReports() }
            f.show()
            true
        }
    }

    private fun showReport(o: JSONObject) {
        val title = o.optString("title")
        val text = o.optString("report")
        val saved = o.optString("sections").takeIf { it.isNotBlank() }?.let { ReportBuilder.fromJson(it) }?.takeIf { it.isNotEmpty() }
        val sections = saved ?: ReportBuilder.fromMarkdown(text)
        val plain = ReportBuilder.toText(title, sections)
        panel.show(title, ReportBuilder.render(this, sections, saved == null), listOf(
            "Ask AI about this" to {
                panel.hide()
                send("Analyse this report in detail, list its weak points and tell me how to fix each one: $title")
            },
            "Save PDF" to { savePdf(title, ReportSheets.fromSections(title, o.optString("url"), sections)) },
            "Copy all" to { ReportBuilder.copy(this, title, plain) },
            "Save TXT" to { ReportUtil.txt(this, title.replace(" ", "_"), plain) }
        ))
    }

    private fun importCsv() {
        if (needKey()) return
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/csv", "text/comma-separated-values", "application/csv", "application/vnd.ms-excel", "text/plain"))
        }, 44)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 44 && resultCode == Activity.RESULT_OK && data?.data != null) {
            val content = runCatching { contentResolver.openInputStream(data.data!!)?.bufferedReader()?.use { it.readText() } }.getOrNull()
            if (content.isNullOrBlank()) { toast("Could not read that file."); return }
            val prompt = "Convert this keyword export into useful keyword planning. Identify themes, intent, useful keyword clusters and opportunities.\n\n" + content.take(30000)
            val wait = loading("Analysing keywords", "The AI is reading your keyword file...")
            exec.execute {
                val r = CohereClient.chat(Prefs.cohereKey, Prefs.cohereModel, prompt)
                runOnUiThread {
                    wait.dismiss()
                    r.onSuccess { txt ->
                        val o = JSONObject().put("title", "Imported Keyword Planning").put("url", "").put("report", txt)
                        val a = reports(); a.put(o); saveReports(a)
                        refreshReports(); showReport(o)
                    }.onFailure { toast(it.message) }
                }
            }
        }
    }

    // ---------- final report ----------
    private fun loading(title: String, msg: String): android.app.Dialog {
        val f = FormDialog(this, title, msg, cancelable = false)
        f.custom(ProgressBar(this))
        return f.show()
    }

    private fun makeFinal() {
        if (busy) return
        if (needKey()) return
        if (reports().length() == 0 && msgs.isEmpty()) {
            toast("Send a report from the browser to Planning Hub, or chat with the AI first.")
            return
        }
        setBusy(true)
        val wait = loading("Creating final report", "The AI is building your sheet-style report. This can take up to a minute.")
        val convo = trimHistory(msgs, 30)
        exec.execute {
            val ctx = buildContext()
            val r = CohereClient.chat(
                Prefs.cohereKey, Prefs.cohereModel,
                listOf(Msg("system", systemPrompt + ctx)) + convo + Msg("user", FinalReport.REQUEST)
            )
            runOnUiThread {
                wait.dismiss()
                setBusy(false)
                r.onSuccess { raw ->
                    val o = FinalReport.parse(raw)
                    if (o == null) {
                        toast("The AI did not return a valid report. Please try again.")
                    } else {
                        val e = JSONObject().put("title", FinalReport.title(o)).put("ts", System.currentTimeMillis()).put("data", o.toString())
                        val out = JSONArray()
                        out.put(e)
                        val old = finals()
                        for (i in 0 until minOf(old.length(), 29)) out.put(old.get(i))
                        saveFinals(out)
                        refreshFinals()
                        openFinal(o)
                    }
                }.onFailure { toast(it.message) }
            }
        }
    }

    private fun refreshFinals() {
        val a = finals()
        val rows = (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            o.optString("title") to date(o.optLong("ts"))
        }
        finalList.adapter = RowAdapter(this, rows)
        finalList.setOnItemClickListener { _, _, p, _ ->
            val o = runCatching { JSONObject(a.getJSONObject(p).optString("data")) }.getOrNull()
            if (o != null) openFinal(o) else toast("This report is damaged.")
        }
        finalList.setOnItemLongClickListener { _, _, p, _ ->
            val f = FormDialog(this, "Delete final report?", rows[p].first)
            f.button("Cancel")
            f.button("Delete", primary = true) { saveFinals(removeAt(a, p)); refreshFinals() }
            f.show()
            true
        }
    }

    private fun openFinal(o: JSONObject) {
        val title = FinalReport.title(o)
        val sections = FinalReport.toSections(o)
        panel.show(title, ReportBuilder.render(this, sections, true), listOf(
            "Download PDF" to { savePdf(title, FinalReport.toPdf(o)) },
            "Refine in chat" to {
                panel.hide()
                selectTab(0)
                chatInput.setText("Final report ko behtar karo: ")
                chatInput.setSelection(chatInput.text.length)
                chatInput.requestFocus()
            },
            "Copy text" to { ReportBuilder.copy(this, title, ReportBuilder.toText(title, sections)) }
        ))
    }

    private fun savePdf(name: String, doc: PdfDoc) { ReportUtil.pdf(this, name, doc) }

    // ---------- settings ----------
    private fun settings() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(14), dp(16), dp(8))
        fun label(t: String) = TextView(this).apply { text = t; setTextColor(getColor(R.color.secondary)); textSize = 13f; setPadding(0, dp(8), 0, dp(4)) }
        fun input(h: String) = EditText(this).apply {
            hint = h; setHintTextColor(getColor(R.color.secondary)); setTextColor(getColor(R.color.text))
            setBackgroundResource(R.drawable.bg_input); setPadding(dp(12), 0, dp(12), 0); setSingleLine(true)
        }
        val key = input("Paste Cohere API key").apply { inputType = 129; setText(Prefs.cohereKey) }
        val model = input("Model name").apply { setText(Prefs.cohereModel) }
        val toggle = TextView(this).apply {
            text = "Show key"; setTextColor(getColor(R.color.accent)); textSize = 13f; setPadding(0, dp(10), 0, dp(4))
            setOnClickListener {
                val show = text.toString() == "Show key"
                key.inputType = if (show) 145 else 129
                key.setSelection(key.text.length)
                text = if (show) "Hide key" else "Show key"
            }
        }
        box.addView(label("Cohere API key"))
        box.addView(key, LinearLayout.LayoutParams(-1, dp(52)))
        box.addView(toggle)
        box.addView(label("Model name"))
        box.addView(model, LinearLayout.LayoutParams(-1, dp(52)))
        panel.show("Planning Hub settings", ScrollView(this).apply { addView(box) }, listOf(
            "Save" to {
                Prefs.cohereKey = key.text.toString().trim()
                Prefs.cohereModel = model.text.toString().trim().ifBlank { "command-r-plus-08-2024" }
                Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
                panel.hide()
            },
            "Cancel" to { panel.hide() }
        ))
    }

    override fun onBackPressed() { if (panel.isShowing) panel.hide() else super.onBackPressed() }
}
