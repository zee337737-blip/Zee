package com.seohacker.browser

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

class PlanningHubActivity : AppCompatActivity() {
    private lateinit var list: ListView
    private lateinit var panel: SidePanel
    private val exec=Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("planning", MODE_PRIVATE) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState);setContentView(R.layout.activity_planning)
        panel=SidePanel(findViewById(R.id.planningRoot));list=findViewById(R.id.reportList)
        findViewById<Button>(R.id.planningSettingsButton).setOnClickListener{settings()}
        findViewById<Button>(R.id.importCsvButton).setOnClickListener{startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{
            type="*/*";addCategory(Intent.CATEGORY_OPENABLE)
            putExtra(Intent.EXTRA_MIME_TYPES,arrayOf("text/csv","text/comma-separated-values","application/csv","application/vnd.ms-excel","text/plain"))
        },44)}
        findViewById<Button>(R.id.generateStrategyButton).setOnClickListener{generate()}
        refresh()
    }
    private fun reports():JSONArray=JSONArray(prefs.getString("reports","[]"))
    private fun save(a:JSONArray){prefs.edit().putString("reports",a.toString()).apply()}
    private fun refresh(){
        val a=reports();val rows=MutableList(a.length()){i->a.getJSONObject(i).optString("title")}
        list.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,rows)
        list.setOnItemClickListener{_,_,p,_->val o=a.getJSONObject(p);showReport(o)}
        list.setOnItemLongClickListener{_,_,p,_->val b=androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Report").setItems(arrayOf("View","Remove")){_,w->
            if(w==0)showReport(a.getJSONObject(p))else{val n=JSONArray();for(i in 0 until a.length())if(i!=p)n.put(a.get(i));save(n);refresh()}
        }.setNegativeButton("Cancel",null).create();b.show();true}
    }
    private fun dp(n:Int)=(n*resources.displayMetrics.density).toInt()
    private fun settings(){
        val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;box.setPadding(dp(16),dp(14),dp(16),dp(8))
        fun label(t:String)=TextView(this).apply{text=t;setTextColor(getColor(R.color.secondary));textSize=13f;setPadding(0,dp(8),0,dp(4))}
        fun input(h:String)=EditText(this).apply{hint=h;setHintTextColor(getColor(R.color.secondary));setTextColor(getColor(R.color.text));setBackgroundResource(R.drawable.bg_input);setPadding(dp(12),0,dp(12),0);setSingleLine(true)}
        val key=input("Paste Cohere API key").apply{inputType=129;setText(Prefs.cohereKey)}
        val model=input("Model name").apply{setText(Prefs.cohereModel)}
        val toggle=TextView(this).apply{text="Show key";setTextColor(getColor(R.color.accent));textSize=13f;setPadding(0,dp(10),0,dp(4))
            setOnClickListener{val show=text=="Show key";key.inputType=if(show)145 else 129;key.setSelection(key.text.length);text=if(show)"Hide key" else "Show key"}}
        box.addView(label("Cohere API key"));box.addView(key,LinearLayout.LayoutParams(-1,dp(52)));box.addView(toggle)
        box.addView(label("Model name"));box.addView(model,LinearLayout.LayoutParams(-1,dp(52)))
        panel.show("Planning Hub settings",ScrollView(this).apply{addView(box)},listOf(
            "Save" to {Prefs.cohereKey=key.text.toString().trim();Prefs.cohereModel=model.text.toString().trim().ifBlank{"command-r-plus-08-2024"};Toast.makeText(this,"Saved",Toast.LENGTH_SHORT).show();panel.hide()},
            "Cancel" to {panel.hide()}))
    }
    private fun showReport(o:JSONObject){
        val title=o.optString("title");val text=o.optString("report")
        val saved=o.optString("sections").takeIf{it.isNotBlank()}?.let{ReportBuilder.fromJson(it)}?.takeIf{it.isNotEmpty()}
        val sections=saved?:ReportBuilder.fromMarkdown(text)
        val plain=ReportBuilder.toText(title,sections)
        panel.show(title,ReportBuilder.render(this,sections,saved==null),listOf(
            "Copy all" to {ReportBuilder.copy(this,title,plain)},
            "Save TXT" to {ReportUtil.txt(this,title.replace(" ","_"),plain)}))
    }
    private fun generate(){
        val a=reports();if(a.length()==0){Toast.makeText(this,"No reports have been sent to Planning Hub.",Toast.LENGTH_SHORT).show();return}
        if(Prefs.cohereKey.isBlank()){settings();return}
        val progress=ProgressBar(this);val wait=androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Generating strategy").setView(progress).setCancelable(false).create();wait.show()
        exec.execute{
            val prompt=StringBuilder("You are an SEO planning assistant. Analyze these reports and page extracts. Return four sections: problems found, action plan, better SEO strategy, keyword planning. Be concrete and prioritize by impact.\n\n")
            for(i in 0 until a.length()){
                val o=a.getJSONObject(i);prompt.append("REPORT ").append(i+1).append(": ").append(o.optString("title")).append(" | ").append(o.optString("url")).append("\n").append(o.optString("report")).append("\n")
                val url=o.optString("url");if(url.isNotBlank())runCatching{prompt.append("PAGE TEXT: ").append(SeoAnalyzer.stripHtml(SeoAnalyzer.fetchText(url))).append("\n")}
            }
            val result=CohereClient.chat(Prefs.cohereKey,Prefs.cohereModel,prompt.toString())
            runOnUiThread{
                wait.dismiss()
                result.onSuccess{txt->
                    val o=JSONObject().put("title","AI SEO Strategy").put("url","").put("report",txt)
                    val n=reports();n.put(o);save(n);refresh();showReport(o)
                }.onFailure{Toast.makeText(this,it.message?:"Strategy failed.",Toast.LENGTH_LONG).show()}
            }
        }
    }
    override fun onBackPressed(){if(panel.isShowing)panel.hide() else super.onBackPressed()}
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data);if(requestCode==44&&resultCode==Activity.RESULT_OK&&data?.data!=null){
            runCatching{contentResolver.openInputStream(data.data!!)?.bufferedReader()?.use{it.readText()}}.onSuccess{
                val prompt="Convert this keyword export into useful keyword planning. Identify themes, intent, useful keyword clusters and opportunities.\n\n${it?.take(30000)}"
                exec.execute{val r=CohereClient.chat(Prefs.cohereKey,Prefs.cohereModel,prompt);runOnUiThread{r.onSuccess{txt->val o=JSONObject().put("title","Imported Keyword Planning").put("report",txt);val a=reports();a.put(o);save(a);refresh();showReport(o)}.onFailure{Toast.makeText(this,it.message,Toast.LENGTH_LONG).show()}}}
            }
        }}
}
