package com.seohacker.browser

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject

enum class Status { GOOD, WARN, BAD, INFO }
data class Row(val label: String, val value: String, val status: Status = Status.INFO, val mono: Boolean = false, val emphasis: Boolean = false)
data class Section(val title: String, val rows: List<Row>)

object ReportBuilder {

    private fun list(o: JSONObject, key: String): List<String> {
        val a = o.optJSONArray(key) ?: return emptyList()
        return (0 until a.length()).map { a.optString(it) }.filter { it.isNotBlank() }
    }

    private fun present(v: String?, missing: String = "Missing") = if (v.isNullOrBlank()) missing else v

    private fun missingStatus(v: String?, bad: Boolean = false) =
        if (v.isNullOrBlank()) (if (bad) Status.BAD else Status.WARN) else Status.GOOD

    fun analysis(o: JSONObject): List<Section> {
        val title = o.optString("title")
        val tl = o.optInt("titleLength")
        val md = o.optString("metaDescription")
        val ml = o.optInt("metaDescriptionLength")
        val canonical = o.optString("canonical")
        val robots = o.optString("robots")
        val lang = o.optString("lang")
        val viewport = o.optString("viewport")
        val h1Count = o.optInt("h1Count")
        val h1 = list(o, "h1")
        val hreflang = list(o, "hreflang")
        val og = o.optJSONObject("openGraph") ?: JSONObject()
        val tw = o.optJSONObject("twitter") ?: JSONObject()
        val ld = list(o, "jsonLd")
        val noAlt = o.optInt("imagesWithoutAlt")
        val words = o.optInt("wordCount")
        val kws = list(o, "topKeywords")

        val titleRow = when {
            title.isBlank() -> Row("Title", "Missing", Status.BAD)
            tl < 30 -> Row("Title", "$title\n($tl characters - too short, aim for 30-60)", Status.WARN)
            tl > 60 -> Row("Title", "$title\n($tl characters - too long, aim for 30-60)", Status.WARN)
            else -> Row("Title", "$title\n($tl characters - good length)", Status.GOOD)
        }
        val descRow = when {
            md.isBlank() -> Row("Meta description", "Missing", Status.BAD)
            ml < 70 -> Row("Meta description", "$md\n($ml characters - too short, aim for 70-160)", Status.WARN)
            ml > 160 -> Row("Meta description", "$md\n($ml characters - too long, aim for 70-160)", Status.WARN)
            else -> Row("Meta description", "$md\n($ml characters - good length)", Status.GOOD)
        }
        val robotsRow = when {
            robots.isBlank() -> Row("Robots meta", "Not set (search engines index and follow by default)", Status.INFO)
            robots.contains("noindex", true) -> Row("Robots meta", "$robots\n(page is blocked from indexing!)", Status.BAD)
            else -> Row("Robots meta", robots, Status.GOOD)
        }
        val h1Row = when (h1Count) {
            0 -> Row("H1 tag", "No H1 found", Status.BAD)
            1 -> Row("H1 tag", "1 found (good)", Status.GOOD)
            else -> Row("H1 tag", "$h1Count found (use only one H1)", Status.WARN)
        }
        val ogRows = listOf("title", "description", "image", "url", "type").map {
            Row("og:$it", present(og.optString(it)), missingStatus(og.optString(it)))
        }
        val twRows = listOf("card", "title", "description", "image").map {
            Row("twitter:$it", present(tw.optString(it)), missingStatus(tw.optString(it)))
        }
        val ldTypes = ld.flatMap { Regex("\"@type\"\\s*:\\s*\"([^\"]+)\"").findAll(it).map { m -> m.groupValues[1] }.toList() }.distinct()

        val sections = mutableListOf<Section>()
        sections += Section("Page Overview", listOf(
            Row("URL", present(o.optString("url"))),
            Row("Language", present(lang, "Not set (add lang attribute to <html>)"), missingStatus(lang)),
            Row("Viewport", present(viewport, "Missing (page may not be mobile friendly)"), missingStatus(viewport))
        ))
        sections += Section("Title & Meta Description", listOf(titleRow, descRow))
        sections += Section("Indexing & Crawling", listOf(
            Row("Canonical URL", present(canonical, "Not set"), missingStatus(canonical)),
            robotsRow,
            Row("Hreflang tags", if (hreflang.isEmpty()) "None (only needed for multi-language sites)" else hreflang.joinToString("\n"), Status.INFO)
        ))
        val headingRows = mutableListOf(h1Row)
        if (h1.isNotEmpty()) headingRows += Row("H1 text", h1.joinToString("\n"))
        for (n in 2..6) headingRows += Row("H$n tags", o.optInt("h${n}Count").toString())
        sections += Section("Headings Structure", headingRows)
        sections += Section("Open Graph (Facebook / WhatsApp)", ogRows)
        sections += Section("Twitter Card", twRows)
        sections += Section("Structured Data (JSON-LD)", listOf(
            if (ld.isEmpty()) Row("Schema markup", "Not found", Status.WARN)
            else Row("Schema markup", "${ld.size} block(s) found" + if (ldTypes.isNotEmpty()) "\nTypes: " + ldTypes.joinToString(", ") else "", Status.GOOD)
        ))
        sections += Section("Content & Images", listOf(
            Row("Word count", if (words < 300) "$words (thin content, aim for 300+)" else "$words (good)", if (words < 300) Status.WARN else Status.GOOD),
            Row("Images without alt text", if (noAlt == 0) "0 (good)" else "$noAlt (add alt text to every image)", if (noAlt == 0) Status.GOOD else Status.WARN)
        ))
        sections += Section("Top Keywords", if (kws.isEmpty()) listOf(Row("Keywords", "No text found")) else
            kws.take(15).mapIndexed { i, k -> val p = k.split(": "); Row("${i + 1}. ${p.first()}", p.getOrElse(1) { "" } + " times") })
        sections += Section("Links", listOf(
            Row("Internal links", o.optInt("internalLinks").toString()),
            Row("External links", o.optInt("externalLinks").toString()),
            Row("Nofollow links", o.optInt("nofollowLinks").toString())
        ))

        val all = sections.flatMap { it.rows }
        val good = all.count { it.status == Status.GOOD }
        val warn = all.count { it.status == Status.WARN }
        val bad = all.count { it.status == Status.BAD }
        sections.add(0, Section("Summary", listOf(
            Row("Passed", good.toString(), Status.GOOD),
            Row("Warnings", warn.toString(), if (warn > 0) Status.WARN else Status.INFO),
            Row("Issues", bad.toString(), if (bad > 0) Status.BAD else Status.INFO)
        )))
        return sections
    }

    private fun clean(s: String) = s.replace("**", "").replace("`", "").replace("__", "").trim()

    /** Turns AI markdown output (## headings, **bold**, numbered points) into report sections. */
    fun fromMarkdown(md: String): List<Section> {
        val sections = mutableListOf<Section>()
        var title = "Report"
        var rows = mutableListOf<Row>()
        fun flush() { if (rows.isNotEmpty()) sections += Section(title, rows.toList()); rows = mutableListOf() }
        val boldLine = Regex("^(?:\\d+[.)]|[-*\u2022])?\\s*\\*\\*(.+?)\\*\\*:?\\s*(.*)$")
        val listPrefix = Regex("^(\\d+[.)]|[-*\\u2022])\\s+")
        md.lines().forEach { raw ->
            val line = raw.trim()
            if (line.isEmpty() || line.matches(Regex("^[-=_*]{3,}$"))) return@forEach
            if (line.startsWith("#")) { flush(); title = clean(line.trimStart('#')).trimEnd(':').trim(); return@forEach }
            val m = boldLine.find(line)
            if (m != null) {
                val label = clean(m.groupValues[1]).trimEnd(':').trim()
                val rest = clean(m.groupValues[2]).trimStart(':', ' ')
                val isItem = listPrefix.containsMatchIn(line)
                if (rest.isEmpty() && !isItem) { flush(); title = label } else rows += Row(label, rest, Status.INFO, false, true)
            } else {
                val t = clean(line)
                rows += Row("", if (listPrefix.containsMatchIn(t) && !t.first().isDigit()) "\u2022 " + t.replace(listPrefix, "") else t)
            }
        }
        flush()
        return if (sections.isEmpty()) listOf(Section("Report", listOf(Row("", "(empty)")))) else sections
    }

    fun toJson(sections: List<Section>): String {
        val arr = JSONArray()
        sections.forEach { s ->
            val ra = JSONArray()
            s.rows.forEach { r -> ra.put(JSONObject().put("l", r.label).put("v", r.value).put("s", r.status.name).put("m", r.mono).put("e", r.emphasis)) }
            arr.put(JSONObject().put("t", s.title).put("r", ra))
        }
        return arr.toString()
    }

    fun fromJson(js: String): List<Section> = runCatching {
        val arr = JSONArray(js)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i); val ra = o.getJSONArray("r")
            Section(o.getString("t"), (0 until ra.length()).map { j ->
                val r = ra.getJSONObject(j)
                Row(r.getString("l"), r.getString("v"), Status.valueOf(r.getString("s")), r.optBoolean("m"), r.optBoolean("e"))
            })
        }
    }.getOrDefault(emptyList())

    private val pretty = mapOf(
        "url" to "URL", "source" to "Page Source", "chain" to "Redirect Chain", "headers" to "Response Headers",
        "content" to "File Content", "results" to "Link Check Results", "time_ms" to "Load time (ms)",
        "size_bytes" to "Size (bytes)", "size_kb" to "Size (KB)"
    )

    fun generic(fields: Map<String, String>): List<Section> {
        val short = mutableListOf<Row>()
        val long = mutableListOf<Section>()
        fields.forEach { (k, v) ->
            val name = pretty[k] ?: k.replace("_", " ").replaceFirstChar { it.uppercase() }
            if (v.length <= 80 && !v.contains('\n')) short += Row(name, v)
            else long += Section(name, listOf(Row("", v.ifBlank { "(empty)" }, Status.INFO, true)))
        }
        return (if (short.isNotEmpty()) listOf(Section("Overview", short)) else emptyList()) + long
    }

    private fun mark(s: Status) = when (s) { Status.GOOD -> "[OK]"; Status.WARN -> "[WARNING]"; Status.BAD -> "[ISSUE]"; Status.INFO -> "" }

    fun toText(title: String, sections: List<Section>): String = buildString {
        append(title.uppercase()).append(" REPORT\n").append("=".repeat(32)).append("\n\n")
        sections.forEachIndexed { i, s ->
            append("${i + 1}. ${s.title.uppercase()}\n").append("-".repeat(32)).append('\n')
            s.rows.forEach { r ->
                val m = mark(r.status)
                if (r.label.isBlank()) append(r.value).append('\n')
                else append(r.label).append(": ").append(r.value).append(if (m.isEmpty()) "" else " $m").append('\n')
            }
            append('\n')
        }
    }

    fun toFields(sections: List<Section>): Map<String, String> {
        val m = linkedMapOf<String, String>()
        sections.forEach { s -> s.rows.forEach { r ->
            val key = if (r.label.isBlank()) s.title else "${s.title} - ${r.label}"
            m[key] = r.value + (mark(r.status).let { if (it.isEmpty()) "" else " $it" })
        } }
        return m
    }

    fun render(ctx: Context, sections: List<Section>): View {
        val d = ctx.resources.displayMetrics.density
        fun dp(n: Int) = (n * d).toInt()
        val colText = ctx.getColor(R.color.text)
        val colSec = ctx.getColor(R.color.secondary)
        val colAccent = ctx.getColor(R.color.accent)
        val colBorder = ctx.getColor(R.color.border)
        val colCard = ctx.getColor(R.color.card)
        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(8), dp(14), dp(8)) }
        sections.forEach { s ->
            val card = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL; setBackgroundColor(colCard); setPadding(dp(12), dp(10), dp(12), dp(10))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }
            }
            card.addView(TextView(ctx).apply { text = s.title; setTextColor(colAccent); textSize = 16f; setTypeface(typeface, Typeface.BOLD) })
            card.addView(View(ctx).apply { setBackgroundColor(colBorder); layoutParams = LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(6); bottomMargin = dp(6) } })
            s.rows.forEach { r ->
                val color = when (r.status) {
                    Status.GOOD -> Color.parseColor("#22C55E"); Status.WARN -> Color.parseColor("#F59E0B")
                    Status.BAD -> Color.parseColor("#EF4444"); Status.INFO -> colText
                }
                val icon = when (r.status) { Status.GOOD -> "\u2714 "; Status.WARN -> "\u26A0 "; Status.BAD -> "\u2716 "; Status.INFO -> "" }
                if (r.label.isNotBlank()) card.addView(TextView(ctx).apply {
                    text = r.label
                    if (r.emphasis) { setTextColor(colText); textSize = 14f; setTypeface(typeface, Typeface.BOLD) } else { setTextColor(colSec); textSize = 12f }
                    layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) }
                })
                if (r.value.isNotBlank() || r.label.isBlank()) card.addView(TextView(ctx).apply {
                    text = icon + r.value; setTextColor(color); textSize = if (r.mono) 12f else 14f
                    if (r.mono) typeface = Typeface.MONOSPACE
                    setTextIsSelectable(true)
                })
            }
            root.addView(card)
        }
        return ScrollView(ctx).apply {
            isVerticalScrollBarEnabled = true; isScrollbarFadingEnabled = false
            scrollBarStyle = View.SCROLLBARS_INSIDE_OVERLAY
            addView(root, ViewGroup.LayoutParams(-1, -2))
        }
    }
}
