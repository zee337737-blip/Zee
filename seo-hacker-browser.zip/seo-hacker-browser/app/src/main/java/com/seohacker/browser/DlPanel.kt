package com.seohacker.browser

import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Live list of video downloads (progress, open, retry, cancel). */
object DlPanel {
    private class Holder(val status: TextView, val bar: ProgressBar)

    private fun statusText(t: DlTask): String = when (t.state) {
        "queued" -> "Waiting..."
        "downloading" -> {
            if (t.kind == "hls") {
                if (t.total > 0L) t.percent().toString() + "%  -  part " + t.done + " of " + t.total + "  -  " + Fmt.size(t.bytes)
                else t.message.ifBlank { "Starting..." }
            } else {
                if (t.total > 0L) t.percent().toString() + "%  -  " + Fmt.size(t.done) + " of " + Fmt.size(t.total)
                else Fmt.size(t.done).let { if (t.done > 0L) it else t.message.ifBlank { "Starting..." } }
            }
        }
        "merging" -> t.message.ifBlank { "Converting to MP4..." }
        "done" -> "Saved  -  " + Fmt.size(t.bytes) + "  -  " + t.fileName + (if (t.note.isNotBlank()) "\n" + t.note else "")
        "canceled" -> "Canceled"
        else -> "Failed: " + t.message
    }

    private fun mimeOf(name: String) = if (name.endsWith(".ts")) "video/mp2t" else if (name.endsWith(".webm")) "video/webm" else "video/mp4"

    fun build(ctx: Context): View {
        val d = ctx.resources.displayMetrics.density
        fun dp(n: Int) = (n * d).toInt()
        val root = LinearLayout(ctx)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(10), dp(10), dp(10), dp(10))
        val summary = TextView(ctx)
        summary.textSize = 13f
        summary.setTextColor(ctx.getColor(R.color.secondary))
        summary.setPadding(dp(4), 0, dp(4), dp(10))
        val list = LinearLayout(ctx)
        list.orientation = LinearLayout.VERTICAL
        root.addView(summary)
        root.addView(list)
        val sv = ScrollView(ctx)
        sv.addView(root)

        val holders = HashMap<String, Holder>()
        var lastKey = ""
        val h = Handler(Looper.getMainLooper())

        fun action(label: String, red: Boolean, f: () -> Unit): TextView {
            val t = TextView(ctx)
            t.text = label
            t.textSize = 13f
            t.setTypeface(t.typeface, Typeface.BOLD)
            t.setTextColor(ctx.getColor(if (red) R.color.error else R.color.accent))
            t.setPadding(0, dp(8), dp(18), dp(4))
            t.setOnClickListener { f() }
            return t
        }

        fun rebuild(ts: List<DlTask>) {
            list.removeAllViews()
            holders.clear()
            if (ts.isEmpty()) {
                val e = TextView(ctx)
                e.text = "No video downloads yet.\nPlay a video and tap the blue download button."
                e.textSize = 14f
                e.setTextColor(ctx.getColor(R.color.secondary))
                e.setPadding(dp(6), dp(16), dp(6), dp(16))
                list.addView(e)
                return
            }
            for (t in ts) {
                val card = LinearLayout(ctx)
                card.orientation = LinearLayout.VERTICAL
                card.setBackgroundResource(R.drawable.bg_card)
                card.setPadding(dp(14), dp(12), dp(14), dp(10))
                val title = TextView(ctx)
                title.text = t.title.ifBlank { "Video" } + (if (t.quality.isNotBlank()) "  (" + t.quality + ")" else "")
                title.textSize = 15f
                title.maxLines = 2
                title.setTextColor(ctx.getColor(R.color.text))
                card.addView(title)
                val bar = ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal)
                bar.max = 100
                bar.visibility = if (t.active()) View.VISIBLE else View.GONE
                card.addView(bar, LinearLayout.LayoutParams(-1, dp(8)).apply { topMargin = dp(8) })
                val st = TextView(ctx)
                st.textSize = 12.5f
                st.setTextColor(ctx.getColor(if (t.state == "failed") R.color.error else R.color.secondary))
                st.setPadding(0, dp(6), 0, 0)
                card.addView(st)
                val row = LinearLayout(ctx)
                row.orientation = LinearLayout.HORIZONTAL
                if (t.active()) {
                    row.addView(action("Cancel", true) { DlManager.cancel(t) })
                } else {
                    if (t.state == "done") row.addView(action("Open", false) {
                        try {
                            val i = Intent(Intent.ACTION_VIEW)
                            i.setDataAndType(Uri.parse(t.uri), mimeOf(t.fileName))
                            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                            ctx.startActivity(i)
                        } catch (e: Exception) {
                            Toast.makeText(ctx, "No app can play this file. Install VLC or MX Player.", Toast.LENGTH_LONG).show()
                        }
                    })
                    else row.addView(action("Retry", false) { DlManager.retry(ctx, t) })
                    row.addView(action("Remove", true) { DlManager.remove(t) })
                }
                card.addView(row)
                list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
                holders[t.id] = Holder(st, bar)
            }
        }

        fun refresh() {
            val ts = DlManager.tasks.toList()
            val key = ts.joinToString(",") { it.id + ":" + it.state }
            if (key != lastKey) {
                lastKey = key
                rebuild(ts)
            }
            val act = ts.count { it.active() }
            val done = ts.count { it.state == "done" }
            summary.text = ts.size.toString() + " videos  -  " + act + " downloading  -  " + done + " finished"
            for (t in ts) {
                val ho = holders[t.id] ?: continue
                ho.status.text = statusText(t)
                if (t.active()) {
                    ho.bar.isIndeterminate = t.total <= 0L && t.state != "merging"
                    ho.bar.progress = t.percent()
                }
            }
        }

        refresh()
        val tick = object : Runnable {
            override fun run() {
                if (!sv.isShown) return
                refresh()
                h.postDelayed(this, 500)
            }
        }
        h.postDelayed(tick, 500)
        return sv
    }
}
