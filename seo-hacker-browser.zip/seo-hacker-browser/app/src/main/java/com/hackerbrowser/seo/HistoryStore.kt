package com.hackerbrowser.seo

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object HistoryStore {
    data class Item(val title: String, val url: String, val time: Long)
    fun list(c: Context): MutableList<Item> {
        val out = mutableListOf<Item>()
        try {
            val arr = JSONArray(Prefs.getHistory(c))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Item(o.optString("title"), o.optString("url"), o.optLong("time")))
            }
        } catch (_: Exception) {}
        return out
    }
    fun add(c: Context, title: String, url: String) {
        if (url.isEmpty() || url.startsWith("file:///android_asset")) return
        val list = list(c)
        list.removeAll { it.url == url }
        list.add(0, Item(title, url, System.currentTimeMillis()))
        while (list.size > 500) list.removeAt(list.size - 1)
        save(c, list)
    }
    fun clear(c: Context) { Prefs.setHistory(c, "[]") }
    private fun save(c: Context, list: List<Item>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("title", it.title).put("url", it.url).put("time", it.time)) }
        Prefs.setHistory(c, arr.toString())
    }
}
