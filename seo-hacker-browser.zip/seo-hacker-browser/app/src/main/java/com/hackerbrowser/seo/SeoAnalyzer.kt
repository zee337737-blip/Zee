package com.hackerbrowser.seo

import android.webkit.WebView
import org.json.JSONObject

object SeoAnalyzer {
    private val JS = """
(function(){try{
  function meta(attr,name){var x=document.querySelector('meta['+attr+'="'+name+'"]');return x?(x.content||''):'';}
  var t=document.title||'', d=meta('name','description');
  var canEl=document.querySelector('link[rel="canonical"]');
  var can=canEl?canEl.href:'';
  var rob=meta('name','robots');
  var heads={};for(var i=1;i<=6;i++){heads['h'+i]=document.querySelectorAll('h'+i).length;}
  var h1t=[];document.querySelectorAll('h1').forEach(function(h){h1t.push((h.innerText||'').trim().substring(0,80));});
  var imgT=0,imgN=0;
  document.querySelectorAll('img').forEach(function(im){imgT++;if(!im.alt||!im.alt.trim())imgN++;});
  var txt=document.body?document.body.innerText:'';
  var w=txt.trim().split(/\s+/).filter(function(x){return x.length>1;});
  var inl=0,ext=0,nf=0,orig=location.origin;
  document.querySelectorAll('a[href]').forEach(function(a){
    var h=a.href;if(!h)return;
    if(a.rel&&a.rel.toLowerCase().indexOf('nofollow')>=0)nf++;
    if(h.indexOf(orig)===0)inl++;else if(h.indexOf('http')===0)ext++;
  });
  var og=document.querySelectorAll('meta[property^="og:"]').length;
  var tw=document.querySelectorAll('meta[name^="twitter:"]').length;
  var hl=document.querySelectorAll('link[rel="alternate"][hreflang]').length;
  var ld=document.querySelectorAll('script[type="application/ld+json"]').length;
  var lang=document.documentElement.lang||'';
  var vp=meta('name','viewport');
  return JSON.stringify({url:location.href,title:t,titleLen:t.length,desc:d,descLen:d.length,
    canonical:can,robots:rob,heads:heads,h1:h1t,imgT:imgT,imgN:imgN,wc:w.length,
    inl:inl,ext:ext,nf:nf,og:og,tw:tw,hreflang:hl,ldjson:ld,lang:lang,viewport:vp});
}catch(e){return JSON.stringify({error:String(e)});}})();
"""

    fun run(w: WebView, cb: (JSONObject?) -> Unit) {
        w.evaluateJavascript(JS) { v ->
            val s = unq(v)
            cb(try { JSONObject(s) } catch (_: Exception) { null })
        }
    }
    fun fmt(o: JSONObject): String {
        val sb = StringBuilder()
        sb.append("=== SEO REPORT ===\n")
        sb.append("URL: ").append(o.optString("url")).append("\n\n")
        sb.append("TITLE: ").append(o.optString("title")).append("\n")
        sb.append("TITLE LEN: ").append(o.optInt("titleLen")).append(" chars ")
        sb.append(if (o.optInt("titleLen") in 30..65) "[OK]" else "[WARN]").append("\n\n")
        sb.append("META DESC: ").append(o.optString("desc")).append("\n")
        sb.append("DESC LEN: ").append(o.optInt("descLen")).append(" chars ")
        sb.append(if (o.optInt("descLen") in 70..165) "[OK]" else "[WARN]").append("\n\n")
        sb.append("CANONICAL: ").append(o.optString("canonical").ifEmpty { "(none)" }).append("\n")
        sb.append("ROBOTS: ").append(o.optString("robots").ifEmpty { "(none)" }).append("\n\n")
        val h = o.optJSONObject("heads")
        if (h != null) { for (i in 1..6) sb.append("H").append(i).append(": ").append(h.optInt("h" + i)).append("\n") }
        sb.append("\nIMAGES: ").append(o.optInt("imgT")).append(" total, ").append(o.optInt("imgN")).append(" without alt\n")
        sb.append("WORDS: ").append(o.optInt("wc")).append("\n")
        sb.append("INTERNAL LINKS: ").append(o.optInt("inl")).append("\n")
        sb.append("EXTERNAL LINKS: ").append(o.optInt("ext")).append("\n")
        sb.append("NOFOLLOW: ").append(o.optInt("nf")).append("\n\n")
        sb.append("OPEN GRAPH TAGS: ").append(o.optInt("og")).append("\n")
        sb.append("TWITTER TAGS: ").append(o.optInt("tw")).append("\n")
        sb.append("HREFLANG: ").append(o.optInt("hreflang")).append("\n")
        sb.append("JSON-LD SCHEMA BLOCKS: ").append(o.optInt("ldjson")).append("\n")
        sb.append("HTML LANG: ").append(o.optString("lang").ifEmpty { "(none)" }).append("\n")
        sb.append("VIEWPORT: ").append(o.optString("viewport").ifEmpty { "(none)" }).append("\n")
        val h1 = o.optJSONArray("h1")
        if (h1 != null) for (i in 0 until h1.length()) sb.append("H1 TEXT: ").append(h1.optString(i)).append("\n")
        return sb.toString()
    }
    fun unq(v: String?): String {
        if (v == null || v == "null") return ""
        return try {
            val x = org.json.JSONTokener(v).nextValue()
            if (x is String) x else v
        } catch (_: Exception) { v }
    }
}
