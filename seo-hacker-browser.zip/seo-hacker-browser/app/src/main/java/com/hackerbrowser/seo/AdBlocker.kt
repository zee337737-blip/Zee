package com.hackerbrowser.seo

import android.content.Context
import java.util.concurrent.atomic.AtomicInteger

object AdBlocker {
    private val domains = HashSet<String>()
    @Volatile private var loaded = false
    val blockedCount = AtomicInteger(0)
    fun load(context: Context) {
        if (loaded) return
        try {
            context.assets.open("blocklist.txt").bufferedReader().useLines { lines ->
                lines.forEach { val d = it.trim().lowercase(); if (d.isNotEmpty()) domains.add(d) }
            }
            loaded = true
        } catch (_: Exception) {}
    }
    fun isBlocked(host: String?): Boolean {
        if (host == null) return false
        val h = host.lowercase()
        if (domains.contains(h)) return true
        var i = h.indexOf('.')
        while (i in 0 until h.length - 1) {
            if (domains.contains(h.substring(i + 1))) return true
            i = h.indexOf('.', i + 1)
        }
        return false
    }
    fun resetCount() { blockedCount.set(0) }
    const val HIDE_ADS_CSS = "(function(){if(document.getElementById('_sc'))return;var s=document.createElement('style');s.id='_sc';s.appendChild(document.createTextNode('ins.adsbygoogle,[class*=adsbygoogle],[id*=taboola],[class*=outbrain],[class*=advertisement]{display:none!important}'));document.head.appendChild(s)})();"
}
