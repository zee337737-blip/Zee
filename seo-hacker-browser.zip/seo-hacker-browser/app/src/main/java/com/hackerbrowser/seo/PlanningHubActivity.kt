package com.hackerbrowser.seo

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import kotlin.concurrent.thread

class PlanningHubActivity : AppCompatActivity() {
    private lateinit var etKey: EditText
    private lateinit var etModel: EditText
    private lateinit var container: LinearLayout
    private lateinit var tvOut: TextView
    private var csvCb: ((String) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_planning_hub)
        etKey = findViewById(R.id.etKey)
        etModel = findViewById(R.id.etModel)
        container = findViewById(R.id.reportsContainer)
        tvOut = findViewById(R.id.tvResult)
        etKey.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        etKey.setText(Prefs.getCohereKey(this))
        etModel.setText(Prefs.getCohereModel(this))

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            Prefs.setCohereKey(this, etKey.text.toString().trim())
            Prefs.setCohereModel(this, etModel.text.toString().trim().ifEmpty { "command-r-plus-08-2024" })
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnClear).setOnClickListener { Prefs.setReports(this, "[]"); refresh() }
        findViewById<Button>(R.id.btnImport).setOnClickListener {
            csvCb = { t ->
                if (t.isBlank()) Toast.makeText(this, "Read failed", Toast.LENGTH_SHORT).show()
                else {
                    ReportUtil.addReportToHub(this, "CSV import " + t.length + " chars", t.take(50000))
                    refresh()
                    Toast.makeText(this, "Imported", Toast.LENGTH_SHORT).show()
                }
            }
            @Suppress("DEPRECATION")
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
            }, 9001)
        }
        findViewById<Button>(R.id.btnGenerate).setOnClickListener { gen() }
        refresh()
    }

    override fun onResume() { super.onResume(); refresh() }

    @Deprecated("Deprecated")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 9001) {
            val cb = csvCb
            csvCb = null
            if (res != Activity.RESULT_OK || data?.data == null) { cb?.invoke(""); return }
            try {
                cb?.invoke(contentResolver.openInputStream(data.data!!)?.bufferedReader()?.use { it.readText() } ?: "")
            } catch (_: Exception) { cb?.invoke("") }
        }
    }

    private fun refresh() {
        container.removeAllViews()
        val arr = try { JSONArray(Prefs.getReports(this)) } catch (_: Exception) { JSONArray() }
        if (arr.length() == 0) {
            val t = TextView(this)
            t.text = "(no reports yet - use SEND TO HUB from the browser)"
            t.setTextColor(0xFF007A4B.toInt())
            t.textSize = 11f
            container.addView(t)
            return
        }
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val row = LinearLayout(this)
            row.orientation = LinearLayout.VERTICAL
            val tt = TextView(this)
            tt.text = "[" + (i + 1) + "] " + o.optString("title")
            tt.setTextColor(0xFF00FF9C.toInt())
            tt.textSize = 12f
            row.addView(tt)
            val btns = LinearLayout(this)
            val view = Button(this)
            view.text = "VIEW"
            view.background = null
            view.setTextColor(0xFF00FF9C.toInt())
            view.textSize = 10f
            view.setOnClickListener { ReportUtil.showReport(this, o.optString("title"), o.optString("content")) }
            btns.addView(view)
            val del = Button(this)
            del.text = "REMOVE"
            del.background = null
            del.setTextColor(0xFFFF3B3B.toInt())
            del.textSize = 10f
            del.setOnClickListener { rm(i); refresh() }
            btns.addView(del)
            row.addView(btns)
            container.addView(row)
            val d = View(this)
            d.layoutParams = LinearLayout.LayoutParams(-1, 1)
            d.setBackgroundColor(0xFF007A4B.toInt())
            container.addView(d)
        }
    }

    private fun rm(i: Int) {
        try {
            val a = JSONArray(Prefs.getReports(this))
            val o = JSONArray()
            for (j in 0 until a.length()) if (j != i) o.put(a.get(j))
            Prefs.setReports(this, o.toString())
        } catch (_: Exception) {}
    }

    private fun gen() {
        val k = Prefs.getCohereKey(this).trim()
        val m = Prefs.getCohereModel(this).trim().ifEmpty { "command-r-plus-08-2024" }
        if (k.isBlank()) { tvOut.text = "[!] No Cohere API key. Save one above."; return }
        val arr = try { JSONArray(Prefs.getReports(this)) } catch (_: Exception) { JSONArray() }
        if (arr.length() == 0) { tvOut.text = "[!] No reports queued."; return }
        val sb = StringBuilder()
        val pages = mutableListOf<String>()
        sb.append("You are an SEO strategist. Analyze these reports. Provide: 1) PROBLEMS, 2) ACTION PLAN, 3) STRATEGY + keyword planning.\n\n")
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            sb.append("=== ").append(o.optString("title")).append(" ===\n")
            val content = o.optString("content")
            sb.append(content.take(8000)).append("\n\n")
            val m = Regex("URL: (https?://\\S+)").find(content)
            if (m != null && !pages.contains(m.groupValues[1])) pages.add(m.groupValues[1])
        }
        tvOut.text = "[*] Asking AI..."
        thread {
            try {
                pages.take(3).forEach { u ->
                    val txt = fetchPageText(u)
                    if (txt.isNotBlank()) sb.append("=== WEBSITE CONTENT: ").append(u).append(" ===\n").append(txt).append("\n\n")
                }
                val r = CohereClient(k, m).chat(sb.toString())
                runOnUiThread { tvOut.text = r; ReportUtil.addReportToHub(this, "AI strategy", r); refresh() }
            } catch (e: Exception) {
                runOnUiThread {
                    val msg = e.message ?: ""
                    tvOut.text = when {
                        msg.contains("No Cohere") -> "[!] No API key."
                        msg.contains("401") -> "[!] Invalid key (401)."
                        msg.contains("429") -> "[!] Rate limit."
                        msg.contains("UnknownHost") -> "[!] No internet."
                        else -> "[!] " + msg
                    }
                }
            }
        }
    }

    private fun fetchPageText(u: String): String {
        return try {
            val c = java.net.URL(u).openConnection() as java.net.HttpURLConnection
            c.connectTimeout = 15000
            c.readTimeout = 15000
            c.setRequestProperty("User-Agent", MainActivity.MOBILE_UA)
            val html = c.inputStream.bufferedReader().use { it.readText() }.take(300000)
            c.disconnect()
            html.replace(Regex("(?is)<(script|style)[^>]*>.*?</\\1>"), " ")
                .replace(Regex("(?s)<[^>]+>"), " ")
                .replace(Regex("\\s+"), " ")
                .trim().take(6000)
        } catch (_: Exception) { "" }
    }
}
