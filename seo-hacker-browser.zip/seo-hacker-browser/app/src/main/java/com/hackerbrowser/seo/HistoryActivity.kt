package com.hackerbrowser.seo

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)
        val lv = findViewById<ListView>(R.id.historyList)
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        fun refresh() {
            lv.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,
                HistoryStore.list(this).map { fmt.format(Date(it.time)) + "\n" + it.title + "\n" + it.url })
        }
        refresh()
        lv.setOnItemClickListener { _, _, p, _ ->
            val l = HistoryStore.list(this)
            if (p in l.indices) {
                val i = Intent(this, MainActivity::class.java)
                i.putExtra("history_url", l[p].url)
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                startActivity(i)
                finish()
            }
        }
        findViewById<Button>(R.id.btnClearHistory).setOnClickListener { HistoryStore.clear(this); refresh() }
    }
}
