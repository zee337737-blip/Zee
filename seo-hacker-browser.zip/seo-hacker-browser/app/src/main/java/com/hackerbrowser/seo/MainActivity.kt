package com.hackerbrowser.seo

import android.annotation.SuppressLint
import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.drawerlayout.widget.DrawerLayout
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private lateinit var drawer: DrawerLayout
    private lateinit var omnibox: EditText
    private lateinit var progress: ProgressBar
    private lateinit var webContainer: FrameLayout
    private lateinit var bookmarksList: ListView
    private val tabs = mutableListOf<WebView>()
    private var currentTab = -1
    private var desktopMode = false
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private val FILE_REQ = 1001

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        drawer = findViewById(R.id.drawer)
        omnibox = findViewById(R.id.omnibox)
        progress = findViewById(R.id.progress)
        webContainer = findViewById(R.id.webContainer)
        bookmarksList = findViewById(R.id.bookmarksList)
        desktopMode = Prefs.getDesktopMode(this)
        AdBlocker.load(this)

        val tools = listOf(
            "\u25B6 ANALYZE PAGE", "\u25B6 VIEW SOURCE", "\u25B6 REDIRECT CHAIN",
            "\u25B6 RESPONSE HEADERS", "\u25B6 ROBOTS.TXT", "\u25B6 SITEMAP.XML",
            "\u25B6 PAGE SPEED", "\u25B6 USER-AGENT", "\u25B6 SEARCH ENGINE",
            "\u25B6 TOGGLE AD-BLOCK", "\u25B6 HISTORY", "\u25B6 PLANNING HUB",
            "\u25B6 NEW TAB", "\u25B6 CLOSE TAB", "\u25B6 TABS",
            "\u25B6 FIND IN PAGE", "\u25B6 DESKTOP MODE"
        )
        val tc = findViewById<LinearLayout>(R.id.toolsContainer)
        tools.forEach { label ->
            val b = Button(this)
            b.text = label
            b.setTextColor(0xFF00FF9C.toInt())
            b.background = null
            b.textSize = 12f
            b.gravity = Gravity.START
            b.isAllCaps = false
            b.setOnClickListener { onTool(label) }
            tc.addView(b)
        }

        findViewById<Button>(R.id.btnMenu).setOnClickListener { drawer.openDrawer(Gravity.START) }
        findViewById<Button>(R.id.btnBack).setOnClickListener { current()?.goBack() }
        findViewById<Button>(R.id.btnForward).setOnClickListener { current()?.goForward() }
        findViewById<Button>(R.id.btnReload).setOnClickListener {
            val w = current() ?: return@setOnClickListener
            if (w.progress < 100) w.stopLoading() else w.reload()
        }
        findViewById<Button>(R.id.btnBookmark).setOnClickListener {
            val w = current() ?: return@setOnClickListener
            val u = w.url ?: return@setOnClickListener
            BookmarkStore.add(this, w.title ?: u, u)
            refreshBookmarks()
            Toast.makeText(this, "Bookmarked", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnMore).setOnClickListener { showOverflow(it) }

        omnibox.setOnEditorActionListener { _, a, _ ->
            if (a == EditorInfo.IME_ACTION_GO) { loadQuery(omnibox.text.toString()); hideKb(); true } else false
        }
        bookmarksList.setOnItemClickListener { _, _, p, _ ->
            val l = BookmarkStore.list(this)
            if (p in l.indices) { current()?.loadUrl(l[p].url); drawer.closeDrawer(Gravity.END) }
        }
        val hu = intent?.getStringExtra("history_url")
        if (hu != null) newTab(hu) else newTab("file:///android_asset/index.html")
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        intent?.getStringExtra("history_url")?.let { newTab(it) }
    }

    private fun onTool(l: String) {
        drawer.closeDrawer(Gravity.START)
        when (l) {
            "\u25B6 ANALYZE PAGE" -> analyze()
            "\u25B6 VIEW SOURCE" -> viewSource()
            "\u25B6 REDIRECT CHAIN" -> net("Redirects") { chain(it) }
            "\u25B6 RESPONSE HEADERS" -> net("Headers") { headers(it) }
            "\u25B6 ROBOTS.TXT" -> net("robots.txt") { txt(it, "/robots.txt") }
            "\u25B6 SITEMAP.XML" -> net("sitemap.xml") { txt(it, "/sitemap.xml") }
            "\u25B6 PAGE SPEED" -> net("Page speed") { speed(it) }
            "\u25B6 USER-AGENT" -> ua()
            "\u25B6 SEARCH ENGINE" -> se()
            "\u25B6 TOGGLE AD-BLOCK" -> {
                val on = !Prefs.getAdBlock(this); Prefs.setAdBlock(this, on)
                Toast.makeText(this, if (on) "Ad-block ON" else "OFF", Toast.LENGTH_SHORT).show()
                current()?.reload()
            }
            "\u25B6 HISTORY" -> startActivity(Intent(this, HistoryActivity::class.java))
            "\u25B6 PLANNING HUB" -> startActivity(Intent(this, PlanningHubActivity::class.java))
            "\u25B6 NEW TAB" -> newTab("file:///android_asset/index.html")
            "\u25B6 CLOSE TAB" -> closeTab(currentTab)
            "\u25B6 TABS" -> showTabs()
            "\u25B6 FIND IN PAGE" -> findInPage()
            "\u25B6 DESKTOP MODE" -> {
                desktopMode = !desktopMode
                Prefs.setDesktopMode(this, desktopMode)
                tabs.forEach {
                    it.settings.userAgentString = if (desktopMode) DESKTOP_UA else MOBILE_UA
                    it.reload()
                }
            }
        }
    }

    private fun showOverflow(a: View) {
        val p = PopupMenu(this, a)
        listOf("New tab", "Close tab", "Tabs", "Find", "History", "Bookmarks", "Planning Hub").forEach { p.menu.add(it) }
        p.setOnMenuItemClickListener { i ->
            when (i.title.toString()) {
                "New tab" -> newTab("file:///android_asset/index.html")
                "Close tab" -> closeTab(currentTab)
                "Tabs" -> showTabs()
                "Find" -> findInPage()
                "History" -> startActivity(Intent(this, HistoryActivity::class.java))
                "Bookmarks" -> drawer.openDrawer(Gravity.END)
                "Planning Hub" -> startActivity(Intent(this, PlanningHubActivity::class.java))
            }
            true
        }
        p.show()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun create(): WebView {
        val w = WebView(this)
        w.layoutParams = FrameLayout.LayoutParams(-1, -1)
        val s = w.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.loadWithOverviewMode = true
        s.useWideViewPort = true
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.allowFileAccess = true
        s.userAgentString = if (desktopMode) DESKTOP_UA else MOBILE_UA

        w.addJavascriptInterface(object {
            @JavascriptInterface fun search(q: String) { runOnUiThread { loadQuery(q) } }
        }, "Android")

        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView?, r: WebResourceRequest?): WebResourceResponse? {
                if (r != null && Prefs.getAdBlock(this@MainActivity) && AdBlocker.isBlocked(r.url.host)) {
                    AdBlocker.blockedCount.incrementAndGet()
                    return WebResourceResponse("text/plain", "utf-8",
                        java.io.ByteArrayInputStream(ByteArray(0)))
                }
                return null
            }
            override fun onPageStarted(v: WebView?, u: String?, f: android.graphics.Bitmap?) {
                progress.visibility = View.VISIBLE; progress.progress = 5; omnibox.setText(u ?: "")
            }
            override fun onPageFinished(v: WebView?, u: String?) {
                progress.visibility = View.GONE
                if (u != null) {
                    omnibox.setText(u)
                    HistoryStore.add(this@MainActivity, v?.title ?: u, u)
                }
                if (Prefs.getAdBlock(this@MainActivity)) v?.evaluateJavascript(AdBlocker.HIDE_ADS_CSS, null)
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView?, p: Int) {
                progress.progress = p
                if (p >= 100) progress.visibility = View.GONE
            }
            override fun onShowFileChooser(wv: WebView?, cb: ValueCallback<Array<Uri>>?, p: FileChooserParams?): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                try {
                    val mimes = (p?.acceptTypes ?: emptyArray())
                        .filter { it.contains("/") }.toTypedArray()
                        .ifEmpty { arrayOf("*/*") }
                    val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                        putExtra(Intent.EXTRA_MIME_TYPES, mimes)
                        putExtra(Intent.EXTRA_ALLOW_MULTIPLE, p?.mode == FileChooserParams.MODE_OPEN_MULTIPLE)
                    }
                    startActivityForResult(i, FILE_REQ)
                } catch (_: Exception) { fileCb?.onReceiveValue(null); fileCb = null; return false }
                return true
            }
        }
        w.setDownloadListener { url, ua, cd, mt, _ ->
            try {
                val f = URLUtil.guessFileName(url, cd, mt)
                val r = DownloadManager.Request(Uri.parse(url))
                r.setMimeType(mt)
                r.addRequestHeader("User-Agent", ua)
                r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, f)
                (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(r)
                Toast.makeText(this, "Downloading: " + f, Toast.LENGTH_SHORT).show()
            } catch (_: Exception) {}
        }
        return w
    }

    private fun newTab(url: String) {
        val w = create()
        tabs.add(w)
        webContainer.addView(w)
        select(tabs.size - 1)
        w.loadUrl(url)
    }
    private fun select(i: Int) {
        if (i !in tabs.indices) return
        currentTab = i
        tabs.forEachIndexed { idx, w -> w.visibility = if (idx == i) View.VISIBLE else View.GONE }
    }
    private fun closeTab(i: Int) {
        if (i !in tabs.indices) return
        val w = tabs.removeAt(i)
        webContainer.removeView(w)
        w.destroy()
        if (tabs.isEmpty()) newTab("file:///android_asset/index.html")
        else select(i.coerceAtMost(tabs.size - 1))
    }
    private fun current(): WebView? = if (currentTab in tabs.indices) tabs[currentTab] else null

    private fun showTabs() {
        val labels = tabs.mapIndexed { i, w -> i.toString() + ". " + (w.title ?: w.url ?: "tab") }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Tabs").setItems(labels) { _, w -> select(w) }
            .setPositiveButton("New") { _, _ -> newTab("file:///android_asset/index.html") }
            .setNegativeButton("Close current") { _, _ -> closeTab(currentTab) }.show()
    }
    private fun findInPage() {
        val e = EditText(this); e.hint = "Find"
        AlertDialog.Builder(this).setTitle("Find in page").setView(e)
            .setPositiveButton("Find") { _, _ -> current()?.findAllAsync(e.text.toString()) }
            .setNeutralButton("Clear") { _, _ -> current()?.clearMatches() }
            .setNegativeButton("Close", null).show()
    }
    private fun refreshBookmarks() {
        bookmarksList.adapter = ArrayAdapter(
            this, android.R.layout.simple_list_item_1,
            BookmarkStore.list(this).map { it.title + "\n" + it.url }
        )
    }
    override fun onResume() { super.onResume(); refreshBookmarks() }
    private fun hideKb() {
        try {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                .hideSoftInputFromWindow(omnibox.windowToken, 0)
            omnibox.clearFocus()
        } catch (_: Exception) {}
    }

    private fun isUrl(t: String): Boolean {
        val x = t.trim()
        if (x.isEmpty()) return false
        if (x.startsWith("http://") || x.startsWith("https://")) return true
        if (x.contains(" ")) return false
        return x.contains(".")
    }
    private fun loadQuery(t: String) {
        val x = t.trim()
        if (x.isEmpty()) return
        val enc = java.net.URLEncoder.encode(x, "UTF-8")
        val u = if (isUrl(x)) {
            if (x.startsWith("http")) x else "https://" + x
        } else when (Prefs.getSearchEngine(this)) {
            "bing" -> "https://www.bing.com/search?q=" + enc
            "duckduckgo" -> "https://duckduckgo.com/?q=" + enc
            else -> "https://www.google.com/search?q=" + enc
        }
        current()?.loadUrl(u) ?: newTab(u)
    }

    private fun analyze() {
        val w = current() ?: return
        SeoAnalyzer.run(w) { o -> if (o != null) ReportUtil.showReport(this, "SEO Report", SeoAnalyzer.fmt(o)) }
    }
    private fun viewSource() {
        val w = current() ?: return
        w.evaluateJavascript("(function(){try{return document.documentElement.outerHTML}catch(e){return ''}})()") { v ->
            ReportUtil.showReport(this, "Source", SeoAnalyzer.unq(v).take(150000))
        }
    }
    private fun net(title: String, block: (StringBuilder) -> Unit) {
        thread {
            val sb = StringBuilder()
            try { block(sb) } catch (e: Exception) { sb.append("\n[ERR] ").append(e.message) }
            runOnUiThread { ReportUtil.showReport(this, title, sb.toString()) }
        }
    }
    private fun chain(sb: StringBuilder) {
        var cur = current()?.url ?: return
        var h = 0
        sb.append("start: ").append(cur).append("\n")
        while (h < 10) {
            val c = java.net.URL(cur).openConnection() as java.net.HttpURLConnection
            c.instanceFollowRedirects = false
            c.requestMethod = "GET"
            c.setRequestProperty("User-Agent", MOBILE_UA)
            val code = c.responseCode
            val loc = c.getHeaderField("Location")
            sb.append("[").append(h).append("] ").append(code).append("  ").append(cur).append("\n")
            if (loc != null && code in 300..399) {
                cur = if (loc.startsWith("http")) loc else java.net.URL(java.net.URL(cur), loc).toString()
                h++
            } else break
            c.disconnect()
        }
    }
    private fun headers(sb: StringBuilder) {
        val u = current()?.url ?: return
        val c = java.net.URL(u).openConnection() as java.net.HttpURLConnection
        c.requestMethod = "GET"
        c.setRequestProperty("User-Agent", MOBILE_UA)
        c.instanceFollowRedirects = false
        sb.append("HTTP ").append(c.responseCode).append(" ").append(c.responseMessage).append("\n\n")
        c.headerFields.forEach { (k, v) -> if (k != null) sb.append(k).append(": ").append(v.joinToString(", ")).append("\n") }
        c.disconnect()
    }
    private fun txt(sb: StringBuilder, path: String) {
        val u = current()?.url ?: return
        val base = java.net.URL(u)
        val url = base.protocol + "://" + base.host + path
        val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
        c.setRequestProperty("User-Agent", MOBILE_UA)
        sb.append("HTTP ").append(c.responseCode).append("\n\n")
        if (c.responseCode in 200..299) sb.append(c.inputStream.bufferedReader().readText().take(100000))
        c.disconnect()
    }
    private fun speed(sb: StringBuilder) {
        val u = current()?.url ?: return
        val t0 = System.currentTimeMillis()
        val c = java.net.URL(u).openConnection() as java.net.HttpURLConnection
        c.setRequestProperty("User-Agent", MOBILE_UA)
        var n = 0L
        val buf = ByteArray(8192)
        val s = c.inputStream
        while (true) {
            val r = s.read(buf)
            if (r <= 0) break
            n += r
        }
        sb.append("Time: ").append(System.currentTimeMillis() - t0).append(" ms\n")
        sb.append("Size: ").append(n).append(" bytes (").append(String.format("%.2f", n / 1024.0)).append(" KB)\n")
        c.disconnect()
    }
    private fun ua() {
        AlertDialog.Builder(this).setTitle("User-Agent")
            .setItems(arrayOf("Mobile", "Desktop", "Googlebot")) { _, w ->
                current()?.settings?.userAgentString = when (w) {
                    1 -> DESKTOP_UA
                    2 -> "Googlebot/2.1"
                    else -> MOBILE_UA
                }
                current()?.reload()
            }.show()
    }
    private fun se() {
        AlertDialog.Builder(this).setTitle("Search engine")
            .setItems(arrayOf("Google", "Bing", "DuckDuckGo")) { _, w ->
                Prefs.setSearchEngine(this, when (w) { 1 -> "bing"; 2 -> "duckduckgo"; else -> "google" })
            }.show()
    }

    override fun onBackPressed() {
        if (drawer.isDrawerOpen(Gravity.START)) { drawer.closeDrawer(Gravity.START); return }
        if (drawer.isDrawerOpen(Gravity.END)) { drawer.closeDrawer(Gravity.END); return }
        val w = current()
        if (w != null && w.canGoBack()) w.goBack() else super.onBackPressed()
    }

    @Deprecated("Deprecated")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == FILE_REQ) {
            val cb = fileCb ?: return
            fileCb = null
            if (res != Activity.RESULT_OK) { cb.onReceiveValue(null); return }
            val r = mutableListOf<Uri>()
            val clip = data?.clipData
            if (clip != null) { for (i in 0 until clip.itemCount) r.add(clip.getItemAt(i).uri) }
            else data?.data?.let { r.add(it) }
            cb.onReceiveValue(if (r.isEmpty()) null else r.toTypedArray())
        }
    }

    companion object {
        const val MOBILE_UA = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36"
        const val DESKTOP_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36"
    }
}
