package com.hackerbrowser.seo

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.view.LayoutInflater
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object ReportUtil {
    fun saveToDownloads(ctx: Context, filename: String, content: String): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, filename)
                    put(MediaStore.Downloads.MIME_TYPE, if (filename.endsWith(".csv")) "text/csv" else "text/plain")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return false
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(content.toByteArray()) }
            } else {
                val d = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (!d.exists()) d.mkdirs()
                File(d, filename).writeText(content)
            }
            true
        } catch (_: Exception) { false }
    }
    fun toCsv(content: String): String {
        val sb = StringBuilder("field,value\n")
        content.lines().forEach { line ->
            val t = line.trim()
            if (t.isEmpty() || t.startsWith("===")) return@forEach
            val i = t.indexOf(": ")
            val k = if (i > 0) t.substring(0, i) else ""
            val v = if (i > 0) t.substring(i + 2) else t
            sb.append("\"").append(k.replace("\"", "\"\"")).append("\",\"")
                .append(v.replace("\"", "\"\"")).append("\"\n")
        }
        return sb.toString()
    }
    fun addReportToHub(ctx: Context, title: String, content: String) {
        try {
            val arr = JSONArray(Prefs.getReports(ctx))
            arr.put(JSONObject().put("title", title).put("content", content).put("time", System.currentTimeMillis()))
            Prefs.setReports(ctx, arr.toString())
        } catch (_: Exception) {}
    }
    fun showReport(a: Activity, title: String, content: String) {
        val v = LayoutInflater.from(a).inflate(R.layout.dialog_report, null)
        v.findViewById<TextView>(R.id.reportText).text = content
        val d = AlertDialog.Builder(a).setTitle(title).setView(v).create()
        v.findViewById<Button>(R.id.btnCsv).setOnClickListener {
            val s = title.replace(Regex("[^A-Za-z0-9._-]"), "_")
            Toast.makeText(a, if (saveToDownloads(a, s + ".csv", toCsv(content))) "Saved" else "Fail", Toast.LENGTH_SHORT).show()
        }
        v.findViewById<Button>(R.id.btnTxt).setOnClickListener {
            val s = title.replace(Regex("[^A-Za-z0-9._-]"), "_")
            Toast.makeText(a, if (saveToDownloads(a, s + ".txt", content)) "Saved" else "Fail", Toast.LENGTH_SHORT).show()
        }
        v.findViewById<Button>(R.id.btnSend).setOnClickListener {
            AlertDialog.Builder(a).setTitle("Send to Planning Hub?")
                .setPositiveButton("Yes") { _, _ ->
                    addReportToHub(a, title, content)
                    Toast.makeText(a, "Sent", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("No", null).show()
        }
        v.findViewById<Button>(R.id.btnClose).setOnClickListener { d.dismiss() }
        d.show()
    }
}
