package com.hackerbrowser.seo

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class CohereClient(private val apiKey: String, private val model: String) {
    fun chat(prompt: String): String {
        if (apiKey.isBlank()) throw IllegalStateException("No Cohere API key")
        val conn = URL("https://api.cohere.com/v2/chat").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 30000
        conn.readTimeout = 60000
        conn.setRequestProperty("Authorization", "Bearer " + apiKey)
        conn.setRequestProperty("Content-Type", "application/json")
        conn.doOutput = true
        val body = JSONObject().apply {
            put("model", model)
            val m = JSONArray()
            m.put(JSONObject().put("role", "user").put("content", prompt))
            put("messages", m)
            put("temperature", 0.4)
        }
        try {
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw RuntimeException("HTTP " + code + ": " + text)
            val json = JSONObject(text)
            val content = json.optJSONObject("message")?.optJSONArray("content")
            val sb = StringBuilder()
            if (content != null) for (i in 0 until content.length()) {
                val p = content.optJSONObject(i) ?: continue
                if (p.optString("type") == "text") sb.append(p.optString("text"))
            }
            if (sb.isEmpty()) return json.optString("text", "")
            return sb.toString()
        } finally { conn.disconnect() }
    }
}
