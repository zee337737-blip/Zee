package com.hackerbrowser.seo

import android.content.Context

object Prefs {
    private const val NAME = "seo_hacker_prefs"
    private fun sp(c: Context) = c.getSharedPreferences(NAME, Context.MODE_PRIVATE)
    fun getSearchEngine(c: Context) = sp(c).getString("se", "google") ?: "google"
    fun setSearchEngine(c: Context, v: String) { sp(c).edit().putString("se", v).apply() }
    fun getDesktopMode(c: Context) = sp(c).getBoolean("dt", false)
    fun setDesktopMode(c: Context, v: Boolean) { sp(c).edit().putBoolean("dt", v).apply() }
    fun getAdBlock(c: Context) = sp(c).getBoolean("ab", true)
    fun setAdBlock(c: Context, v: Boolean) { sp(c).edit().putBoolean("ab", v).apply() }
    fun getCohereKey(c: Context) = sp(c).getString("ck", "") ?: ""
    fun setCohereKey(c: Context, v: String) { sp(c).edit().putString("ck", v).apply() }
    fun getCohereModel(c: Context) = sp(c).getString("cm", "command-r-plus-08-2024") ?: "command-r-plus-08-2024"
    fun setCohereModel(c: Context, v: String) { sp(c).edit().putString("cm", v).apply() }
    fun getReports(c: Context) = sp(c).getString("rp", "[]") ?: "[]"
    fun setReports(c: Context, v: String) { sp(c).edit().putString("rp", v).apply() }
    fun getBookmarks(c: Context) = sp(c).getString("bm", "[]") ?: "[]"
    fun setBookmarks(c: Context, v: String) { sp(c).edit().putString("bm", v).apply() }
    fun getHistory(c: Context) = sp(c).getString("hs", "[]") ?: "[]"
    fun setHistory(c: Context, v: String) { sp(c).edit().putString("hs", v).apply() }
}
